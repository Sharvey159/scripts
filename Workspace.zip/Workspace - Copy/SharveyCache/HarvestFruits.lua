-- ============================================================================
-- Mutant Harvester v3 (Floating Icon Version)
-- ============================================================================
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- ============================================================================
-- ALLOWED FRUITS WHITELIST
-- ============================================================================
local AllowedToProcess = {
	["Moon Bloom"] = true,
	-- Add more fruits here
}

local function IsFruitAllowed(fruitName)
	if not fruitName then return false end
	return AllowedToProcess[fruitName] == true
end
-- ============================================================================

local FruitVisualizerController = require(player:WaitForChild("PlayerScripts"):WaitForChild("Controllers"):WaitForChild("FruitVisualizerController"))
local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))

local myPlot
for _, plot in ipairs(workspace.Gardens:GetChildren()) do
    if plot:GetAttribute("OwnerUserId") == player.UserId then
        myPlot = plot
        break
    end
end

if not myPlot then
    warn("Couldn't find your plot!")
    return
end

-- UI Setup
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "MutantHarvesterIconUI"
screenGui.ResetOnSpawn = false
screenGui.Parent = playerGui

-- Shadow Frame for Drop Shadow effect
local shadow = Instance.new("Frame")
shadow.Size = UDim2.fromOffset(48, 48)
-- Position: Bottom-Right, 16px padding = -16px offset
shadow.Position = UDim2.new(1, -14, 1, -118)
shadow.AnchorPoint = Vector2.new(1, 1)
shadow.BackgroundColor3 = Color3.new(0, 0, 0)
shadow.BackgroundTransparency = 0.7
shadow.BorderSizePixel = 0
shadow.Parent = screenGui
Instance.new("UICorner", shadow).CornerRadius = UDim.new(0, 12)

-- Main Button
local harvestBtn = Instance.new("TextButton")
harvestBtn.Size = UDim2.fromOffset(48, 48)
harvestBtn.Position = UDim2.new(1, -16, 1, -120)
harvestBtn.AnchorPoint = Vector2.new(1, 1)
harvestBtn.BackgroundColor3 = Color3.fromHex("#22C55E") -- Green
harvestBtn.BackgroundTransparency = 0.15
harvestBtn.BorderSizePixel = 0
harvestBtn.Text = "🌾"
harvestBtn.TextSize = 24
harvestBtn.Font = Enum.Font.Gotham
harvestBtn.Parent = screenGui
Instance.new("UICorner", harvestBtn).CornerRadius = UDim.new(0, 12)

---------------------------------------------------
-- Animations
---------------------------------------------------
local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local baseColor = Color3.fromHex("#22C55E")
local hoverColor = Color3.fromHex("#4ADE80") -- Brighter green

harvestBtn.MouseEnter:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = hoverColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

harvestBtn.MouseLeave:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = baseColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)

harvestBtn.MouseButton1Down:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)

harvestBtn.MouseButton1Up:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

---------------------------------------------------
-- Core Harvesting Logic
---------------------------------------------------
local isHarvesting = false

local function harvestMutants()
    if isHarvesting then return end
    isHarvesting = true
    
    local targets = {}
    print("Harvester: Scanning for mutants...")
    
    -- Scan Phase
    for _, plant in ipairs(myPlot.Plants:GetChildren()) do
        local fruits = plant:FindFirstChild("Fruits")
        if fruits then
            local plantId = plant:GetAttribute("PlantId") or plant.Name
            if plantId then
                for _, fruit in ipairs(fruits:GetChildren()) do
                    local name = fruit:GetAttribute("CorePartName")
                    
                    if not IsFruitAllowed(name) then continue end
                    
                    local id = fruit:GetAttribute("FruitId")
                    if not id or not name then continue end

                    local mutation = fruit:GetAttribute("Mutation")
                    if not mutation or mutation == "" then mutation = "None" end

                    local weight = FruitVisualizerController:CalculateFruitWeight(fruit)
                    if not weight and FruitVisualizerController.CalculatePlantWeight then
                        weight = FruitVisualizerController:CalculatePlantWeight(fruit)
                    end
                    weight = tonumber(weight) or 0

                    if mutation ~= "None" and weight > 30 then
                        table.insert(targets, {PlantId = plantId, FruitId = id, Instance = fruit})
                    end
                end
            end
        end
    end

    -- Harvest Phase
    local total = #targets
    if total == 0 then
        print("Harvester: No valid mutants found.")
        task.wait(2)
        isHarvesting = false
        return
    end

    local processed = 0
    for _, target in ipairs(targets) do
        if target.Instance and target.Instance:IsDescendantOf(workspace) then
            processed += 1
            print(("Harvester: Harvesting... %d/%d"):format(processed, total))
            
            pcall(function()
                Networking.Garden.CollectFruit:Fire(target.PlantId, target.FruitId)
            end)
            
            task.wait(0.1) 
        end
    end

    print("Harvester: Finished! Harvested: " .. processed)
    task.wait(2)
    isHarvesting = false
end

harvestBtn.MouseButton1Click:Connect(function()
    task.spawn(harvestMutants)
end)