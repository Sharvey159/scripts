-- ============================================================================
-- Fruit Summary v3 (Floating Icon Version)
-- ============================================================================
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local TweenService = game:GetService("TweenService")
local player = Players.LocalPlayer
local lp = player

-- ============================================================================
-- ALLOWED FRUITS WHITELIST
-- ============================================================================
local AllowedToProcess = {
	["Moon Bloom"] = true,
	-- Add more fruits here
}

local function IsFruitAllowed(fruitName)
	if not fruitName then return false end
	return AllowedToProcess[fruitName] == true
end
-- ============================================================================

local FruitVisualizerController = require(lp.PlayerScripts.Controllers.FruitVisualizerController)

-- UI Setup
local gui = Instance.new("ScreenGui")
gui.Name = "FruitSummaryIconUI"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

-- Shadow Frame for Drop Shadow effect
local shadow = Instance.new("Frame")
shadow.Size = UDim2.fromOffset(48, 48)
-- Position: Bottom-Right, 16px padding + 48px Harvest btn + 8px gap = -72px offset
shadow.Position = UDim2.new(1, -70, 1, -118) -- Offset slightly for shadow
shadow.AnchorPoint = Vector2.new(1, 1)
shadow.BackgroundColor3 = Color3.new(0, 0, 0)
shadow.BackgroundTransparency = 0.7
shadow.BorderSizePixel = 0
shadow.Parent = gui
Instance.new("UICorner", shadow).CornerRadius = UDim.new(0, 12)

-- Main Button
local btn = Instance.new("TextButton")
btn.Size = UDim2.fromOffset(48, 48)
btn.Position = UDim2.new(1, -72, 1, -120)
btn.AnchorPoint = Vector2.new(1, 1)
btn.BackgroundColor3 = Color3.fromHex("#3B82F6") -- Blue
btn.BackgroundTransparency = 0.15
btn.BorderSizePixel = 0
btn.Text = "📊"
btn.TextSize = 24
btn.Font = Enum.Font.Gotham
btn.Parent = gui
Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 12)

---------------------------------------------------
-- Animations
---------------------------------------------------
local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local baseColor = Color3.fromHex("#3B82F6")
local hoverColor = Color3.fromHex("#60A5FA") -- Brighter blue

btn.MouseEnter:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = hoverColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

btn.MouseLeave:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = baseColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)

btn.MouseButton1Down:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)

btn.MouseButton1Up:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

---------------------------------------------------
-- Webhook & Caching Logic
---------------------------------------------------
local WEBHOOK_URL = "https://discord.com/api/webhooks/1520269449251262494/kIdsK1mVMEVqvZblghzbB7NSIMF4KF9NB13phNN0eAqYFsoeymHaYIkWEoJFKTOiVjBj"
local CACHE_FILE = "FruitSummaryCache.json"

local function loadCache()
	if isfile and isfile(CACHE_FILE) then
		local success, data = pcall(function()
			return HttpService:JSONDecode(readfile(CACHE_FILE))
		end)
		if success and type(data) == "table" then
			return data
		end
	end
	return {}
end

local function saveCache(data)
	if writefile then
		writefile(CACHE_FILE, HttpService:JSONEncode(data))
	end
end

local function sendWebhook(title, body, color)
	task.spawn(function()
		local cache = loadCache()
		local playerName = lp.Name
		
		local messageId = nil
		if cache[playerName] and cache[playerName].messageId then
			messageId = cache[playerName].messageId
		end

		local currentTime = os.date("%Y-%m-%d %H:%M:%S")
		local isoTime = os.date("!%Y-%m-%dT%H:%M:%SZ")

		local payload = {
			embeds = {
				{
					title = title,
					description = body,
					color = color or 3447003,
					timestamp = isoTime,
					footer = {
						text = string.format("%s • Last Updated: %s", playerName, currentTime)
					}
				}
			}
		}

		local jsonPayload = HttpService:JSONEncode(payload)

		if messageId then
			local patchUrl = WEBHOOK_URL .. "/messages/" .. messageId
			local response = request({
				Url = patchUrl,
				Method = "PATCH",
				Headers = { ["Content-Type"] = "application/json" },
				Body = jsonPayload,
			})

			if response.StatusCode == 200 then
				print("Fruit Summary: Successfully updated existing dashboard.")
				return
			elseif response.StatusCode == 404 then
				messageId = nil 
			else
				warn("Fruit Summary: Failed to patch webhook:", response.StatusCode, response.Body)
				return
			end
		end

		if not messageId then
			local postUrl = WEBHOOK_URL .. "?wait=true" 
			local response = request({
				Url = postUrl,
				Method = "POST",
				Headers = { ["Content-Type"] = "application/json" },
				Body = jsonPayload,
			})

			if response.StatusCode == 200 or response.StatusCode == 201 then
				local success, responseData = pcall(function()
					return HttpService:JSONDecode(response.Body)
				end)

				if success and responseData.id then
					cache[playerName] = { messageId = responseData.id }
					saveCache(cache)
					print("Fruit Summary: Successfully created new dashboard.")
				end
			else
				warn("Fruit Summary: Failed to post webhook:", response.StatusCode, response.Body)
			end
		end
	end)
end

---------------------------------------------------
-- Core Logic
---------------------------------------------------
local function AnalyzeMyFruits()
	local myPlot

	for _, plot in ipairs(workspace.Gardens:GetChildren()) do
		if plot:GetAttribute("OwnerUserId") == lp.UserId then
			myPlot = plot
			break
		end
	end

	if not myPlot then
		warn("Couldn't find your plot!")
		return "⚠️ Couldn't find your plot!"
	end

	local mutationCounts = {}
	local weightRanges = {}
	local allFruits = {}

	for _, plant in ipairs(myPlot.Plants:GetChildren()) do
		local fruits = plant:FindFirstChild("Fruits")

		if fruits then
			for _, fruit in ipairs(fruits:GetChildren()) do
				local name = fruit:GetAttribute("CorePartName") or "Unknown"
				
				if not IsFruitAllowed(name) then continue end

				local mutation = fruit:GetAttribute("Mutation")
				if not mutation or mutation == "" then
					mutation = "None"
				end

				local weight = FruitVisualizerController:CalculateFruitWeight(fruit)

				if not weight and FruitVisualizerController.CalculatePlantWeight then
					weight = FruitVisualizerController:CalculatePlantWeight(fruit)
				end

				weight = tonumber(weight) or 0

				mutationCounts[mutation] = (mutationCounts[mutation] or 0) + 1

				local bucket = math.floor(weight / 10) * 10
				weightRanges[bucket] = (weightRanges[bucket] or 0) + 1

				table.insert(allFruits, {
					Name = name,
					Weight = weight,
					Mutation = mutation,
				})
			end
		end
	end

	table.sort(allFruits, function(a, b)
		return a.Weight > b.Weight
	end)

	local text = ""

	text ..= "🧬 MUTATION SUMMARY\n"
	text ..= "━━━━━━━━━━━━━━━━━━\n"

	local mutations = {}
	for mutation, count in pairs(mutationCounts) do
		table.insert(mutations, { Name = mutation, Count = count })
	end

	table.sort(mutations, function(a, b)
		return a.Count > b.Count
	end)

	for _, info in ipairs(mutations) do
		text ..= string.format("%-15s %dx\n", info.Name, info.Count)
	end

	text ..= "\n⚖️ WEIGHT DISTRIBUTION\n"
	text ..= "━━━━━━━━━━━━━━━━━━━━━━\n"

	local buckets = {}
	for bucket in pairs(weightRanges) do
		table.insert(buckets, bucket)
	end

	table.sort(buckets)

	for _, bucket in ipairs(buckets) do
		text ..= string.format("%d-%dkg : %dx\n", bucket, bucket + 10, weightRanges[bucket])
	end

	text ..= "\n🏆 FRUITS SORTED BY WEIGHT\n"
	text ..= "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"

	local MAX_FRUITS = 50

	for i = 1, math.min(#allFruits, MAX_FRUITS) do
		local fruit = allFruits[i]
		text ..= string.format("%2d. %-16s - %-7.2fkg - %-10s\n", i, fruit.Name, fruit.Weight, fruit.Mutation)
	end

	if #allFruits > MAX_FRUITS then
		text ..= string.format("\n...and %d more fruits.", #allFruits - MAX_FRUITS)
	end

	return text
end

btn.MouseButton1Click:Connect(function()
	print("Fruit Summary: Gathering data...")
	local text = AnalyzeMyFruits()
	sendWebhook("Fruit Summary", text, 3447003)
end)