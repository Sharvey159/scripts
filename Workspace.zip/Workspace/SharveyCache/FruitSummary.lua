-- ============================================================================
-- Fruit Summary v6 (Floating Icon Version)
-- ============================================================================
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local TweenService = game:GetService("TweenService")
local player = Players.LocalPlayer
local lp = player

if player:WaitForChild("PlayerGui"):FindFirstChild("FruitSummaryIconUI") then
    player.PlayerGui.FruitSummaryIconUI:Destroy()
end

-- ============================================================================
-- CENTRALIZED FAB STACK MANAGER SETUP
-- ============================================================================
local FABManager = _G.FABManager
if not FABManager then
    FABManager = {
        Buttons = {},
        PriorityMap = {
            SharveyManager = 1,
            FruitDropper = 2,
            AutoMail = 3,
            FruitSummary = 4,
            HarvestFruits = 5
        }
    }
    _G.FABManager = FABManager
    
    function FABManager.Update()
        local TweenSvc = game:GetService("TweenService")
        -- Self-heal: Clean up destroyed buttons
        local i = 1
        while i <= #FABManager.Buttons do
            local btnData = FABManager.Buttons[i]
            if not btnData.Button or not btnData.Button.Parent then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, i)
            else
                i = i + 1
            end
        end

        local activeButtons = {}
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Visible then
                table.insert(activeButtons, btnData)
            end
        end
        
        local count = #activeButtons
        if count == 0 then return end
        
        local buttonSize = 48
        local spacing = 12
        local totalHeight = (count * buttonSize) + ((count - 1) * spacing)
        local startYOffset = -totalHeight / 2
        
        for idx, btnData in ipairs(activeButtons) do
            local targetYOffset = startYOffset + ((idx - 1) * (buttonSize + spacing)) + (buttonSize / 2)
            local targetPos = UDim2.new(1, -16, 0.5, targetYOffset)
            local targetShadowPos = UDim2.new(1, -14, 0.5, targetYOffset + 2)
            
            local tInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
            
            if btnData.Button and btnData.Button.Parent then
                TweenSvc:Create(btnData.Button, tInfo, {Position = targetPos}):Play()
            end
            if btnData.Shadow and btnData.Shadow.Parent then
                TweenSvc:Create(btnData.Shadow, tInfo, {Position = targetShadowPos}):Play()
            end
        end
    end
    
    function FABManager.Register(id, button, shadow, onClick)
        FABManager.Unregister(id)
        
        local btnData = {
            Id = id,
            Button = button,
            Shadow = shadow,
            Visible = true,
            OnClick = onClick
        }
        
        table.insert(FABManager.Buttons, btnData)
        
        table.sort(FABManager.Buttons, function(a, b)
            local pA = FABManager.PriorityMap[a.Id] or 99
            local pB = FABManager.PriorityMap[b.Id] or 99
            return pA < pB
        end)
        
        if onClick then
            btnData.Connection = button.MouseButton1Click:Connect(onClick)
        end
        
        FABManager.Update()
        return btnData
    end
    
    function FABManager.Unregister(id)
        for idx, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, idx)
                FABManager.Update()
                break
            end
        end
    end
    
    function FABManager.SetVisible(id, visible)
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                btnData.Visible = visible
                if btnData.Button and btnData.Button.Parent then
                    btnData.Button.Visible = visible
                end
                if btnData.Shadow and btnData.Shadow.Parent then
                    btnData.Shadow.Visible = visible
                end
                FABManager.Update()
                break
            end
        end
    end
end

-- ============================================================================
-- CONFIGURATION
-- ============================================================================
local MAX_NEW_MUTATED_FRUITS = 5

local AllowedToProcess = {
	["Moon Bloom"] = true,
	-- Add more fruits here
}

local function IsFruitAllowed(fruitName)
	if not fruitName then return false end
	return AllowedToProcess[fruitName] == true
end
-- ============================================================================

local FruitVisualizerController = require(lp.PlayerScripts.Controllers.FruitVisualizerController)

-- UI Setup
local gui = Instance.new("ScreenGui")
gui.Name = "FruitSummaryIconUI"
gui.ResetOnSpawn = false
gui.Parent = player.PlayerGui

-- Shadow Frame for Drop Shadow effect
local shadow = Instance.new("Frame")
shadow.Size = UDim2.fromOffset(48, 48)
shadow.AnchorPoint = Vector2.new(1, 0.5)
shadow.BackgroundColor3 = Color3.new(0, 0, 0)
shadow.BackgroundTransparency = 0.7
shadow.BorderSizePixel = 0
shadow.Parent = gui
Instance.new("UICorner", shadow).CornerRadius = UDim.new(0, 12)

-- Main Button
local btn = Instance.new("TextButton")
btn.Size = UDim2.fromOffset(48, 48)
btn.AnchorPoint = Vector2.new(1, 0.5)
btn.BackgroundColor3 = Color3.fromHex("#3B82F6") -- Blue
btn.BackgroundTransparency = 0.15
btn.BorderSizePixel = 0
btn.Text = "📊"
btn.TextSize = 24
btn.Font = Enum.Font.Gotham
btn.Parent = gui
Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 12)

---------------------------------------------------
-- Animations
---------------------------------------------------
local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local baseColor = Color3.fromHex("#3B82F6")
local hoverColor = Color3.fromHex("#60A5FA") -- Brighter blue

btn.MouseEnter:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = hoverColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

btn.MouseLeave:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = baseColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)

btn.MouseButton1Down:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)

btn.MouseButton1Up:Connect(function()
	TweenService:Create(btn, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

---------------------------------------------------
-- Webhook & Message Caching Logic
---------------------------------------------------
local WEBHOOK_URL = "https://discord.com/api/webhooks/1520269449251262494/kIdsK1mVMEVqvZblghzbB7NSIMF4KF9NB13phNN0eAqYFsoeymHaYIkWEoJFKTOiVjBj"
local WEBHOOK_CACHE_FILE = "FruitSummaryCache.json"

local function loadWebhookCache()
	if isfile and isfile(WEBHOOK_CACHE_FILE) then
		local success, data = pcall(function()
			return HttpService:JSONDecode(readfile(WEBHOOK_CACHE_FILE))
		end)
		if success and type(data) == "table" then
			return data
		end
	end
	return {}
end

local function saveWebhookCache(data)
	if writefile then
		writefile(WEBHOOK_CACHE_FILE, HttpService:JSONEncode(data))
	end
end

---------------------------------------------------
-- Fruit Tracker Caching Logic
---------------------------------------------------
local FRUIT_CACHE_FILE = "FruitTrackerCache.json"

local function loadFruitCache()
	if isfile and isfile(FRUIT_CACHE_FILE) then
		local success, data = pcall(function()
			return HttpService:JSONDecode(readfile(FRUIT_CACHE_FILE))
		end)
		if success and type(data) == "table" then
			return data
		end
	end
	return {}
end

local function saveFruitCache(data)
	if writefile then
		writefile(FRUIT_CACHE_FILE, HttpService:JSONEncode(data))
	end
end

---------------------------------------------------
-- Webhook Sender
---------------------------------------------------
local function sendWebhook(title, body, color)
	task.spawn(function()
		local cache = loadWebhookCache()
		local playerName = lp.Name
		
		local messageId = nil
		if cache[playerName] and cache[playerName].messageId then
			messageId = cache[playerName].messageId
		end

		local currentTime = os.date("%Y-%m-%d %H:%M:%S")
		local isoTime = os.date("!%Y-%m-%dT%H:%M:%SZ")

		local payload = {
			embeds = {
				{
					title = title,
					description = body,
					color = color or 3447003,
					timestamp = isoTime,
					footer = {
						text = string.format("%s • Last Updated: %s", playerName, currentTime)
					}
				}
			}
		}

		local jsonPayload = HttpService:JSONEncode(payload)

		if messageId then
			local patchUrl = WEBHOOK_URL .. "/messages/" .. messageId
			local response = request({
				Url = patchUrl,
				Method = "PATCH",
				Headers = { ["Content-Type"] = "application/json" },
				Body = jsonPayload,
			})

			if response.StatusCode == 200 then
				print("Fruit Summary: Successfully updated existing dashboard.")
				return
			elseif response.StatusCode == 404 then
				messageId = nil 
			else
				warn("Fruit Summary: Failed to patch webhook:", response.StatusCode, response.Body)
				return
			end
		end

		if not messageId then
			local postUrl = WEBHOOK_URL .. "?wait=true" 
			local response = request({
				Url = postUrl,
				Method = "POST",
				Headers = { ["Content-Type"] = "application/json" },
				Body = jsonPayload,
			})

			if response.StatusCode == 200 or response.StatusCode == 201 then
				local success, responseData = pcall(function()
					return HttpService:JSONDecode(response.Body)
				end)

				if success and responseData.id then
					cache[playerName] = { messageId = responseData.id }
					saveWebhookCache(cache)
					print("Fruit Summary: Successfully created new dashboard.")
				end
			else
				warn("Fruit Summary: Failed to post webhook:", response.StatusCode, response.Body)
			end
		end
	end)
end

---------------------------------------------------
-- Core Logic
---------------------------------------------------
local function AnalyzeMyFruits()
	local myPlot

	for _, plot in ipairs(workspace.Gardens:GetChildren()) do
		if plot:GetAttribute("OwnerUserId") == lp.UserId then
			myPlot = plot
			break
		end
	end

	if not myPlot then
		warn("Couldn't find your plot!")
		return "⚠️ Couldn't find your plot!"
	end

	local fruitCache = loadFruitCache()
	local currentScanIds = {}
	local newDetectedFruits = {}
	
	local mutationCounts = {}
	local weightRanges = {}

	-- 1. Scan all current fruits
	for _, plant in ipairs(myPlot.Plants:GetChildren()) do
		local fruits = plant:FindFirstChild("Fruits")

		if fruits then
			for _, fruit in ipairs(fruits:GetChildren()) do
				local name = fruit:GetAttribute("CorePartName") or "Unknown"
				
				if not IsFruitAllowed(name) then continue end
				
				-- Ensure we have a valid unique ID (Fallback to debug ID/Name if property missing, but prefers FruitId)
				local rawFruitId = fruit:GetAttribute("FruitId") or fruit:GetDebugId()
				local fruitId = tostring(rawFruitId)
				
				currentScanIds[fruitId] = true

				local mutation = fruit:GetAttribute("Mutation")
				if not mutation or mutation == "" then
					mutation = "None"
				end

				local weight = FruitVisualizerController:CalculateFruitWeight(fruit)
				if not weight and FruitVisualizerController.CalculatePlantWeight then
					weight = FruitVisualizerController:CalculatePlantWeight(fruit)
				end
				weight = tonumber(weight) or 0

				-- Tally general stats
				mutationCounts[mutation] = (mutationCounts[mutation] or 0) + 1
				local bucket = math.floor(weight / 10) * 10
				weightRanges[bucket] = (weightRanges[bucket] or 0) + 1

				-- 2 & 3. Compare with cache using ONLY FruitId
				if not fruitCache[fruitId] then
					-- Treat as a new fruit
					table.insert(newDetectedFruits, {
						Name = name,
						Mutation = mutation,
						Weight = weight
					})
					
					-- Save to cache
					fruitCache[fruitId] = {
						FruitId = fruitId,
						Name = name,
						Mutation = mutation,
						Weight = weight,
						Timestamp = os.time()
					}
				end
			end
		end
	end

	-- 4. Purge missing fruits from cache
	for cachedId, _ in pairs(fruitCache) do
		if not currentScanIds[cachedId] then
			fruitCache[cachedId] = nil
		end
	end

	-- Synchronize cache
	saveFruitCache(fruitCache)

	-----------------------------
	-- Building the Output String
	-----------------------------
	local text = ""

	text ..= "🧬 MUTATION SUMMARY\n"
	text ..= "━━━━━━━━━━━━━━━━━━\n"

	local mutations = {}
	for mutation, count in pairs(mutationCounts) do
		table.insert(mutations, { Name = mutation, Count = count })
	end
	table.sort(mutations, function(a, b) return a.Count > b.Count end)

	for _, info in ipairs(mutations) do
		text ..= string.format("%-15s %dx\n", info.Name, info.Count)
	end

	text ..= "\n⚖️ WEIGHT DISTRIBUTION\n"
	text ..= "━━━━━━━━━━━━━━━━━━━━━━\n"

	local buckets = {}
	for bucket in pairs(weightRanges) do
		table.insert(buckets, bucket)
	end
	table.sort(buckets)

	for _, bucket in ipairs(buckets) do
		text ..= string.format("%d-%dkg : %dx\n", bucket, bucket + 10, weightRanges[bucket])
	end

	-- NEW MUTATED FRUITS SECTION
	text ..= "\n🆕 NEW MUTATED FRUITS\n"
	text ..= "━━━━━━━━━━━━━━━━━━━━\n"

	if #newDetectedFruits == 0 then
		text ..= "No new mutated fruits detected.\n"
	else
		local displayCount = math.min(#newDetectedFruits, MAX_NEW_MUTATED_FRUITS)
		for i = 1, displayCount do
			local fruit = newDetectedFruits[i]
			text ..= string.format("• %s | %s | %.2fkg\n", fruit.Name, fruit.Mutation, fruit.Weight)
		end
		
		if #newDetectedFruits > MAX_NEW_MUTATED_FRUITS then
			text ..= string.format("\n...and %d more new fruits.\n", #newDetectedFruits - MAX_NEW_MUTATED_FRUITS)
		end
	end

	return text
end

local function onSummaryClick()
	print("Fruit Summary: Gathering data...")
	local text = AnalyzeMyFruits()
	sendWebhook("Fruit Summary", text, 3447003)
end

FABManager.Register("FruitSummary", btn, shadow, onSummaryClick)