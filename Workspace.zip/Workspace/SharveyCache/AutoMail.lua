-- ============================================================
-- GAG2 Alt Picker v2 (FAB Integrated Edition)
-- - Auto pickup loop
-- - Batch backpack scan with live bid prices
-- - Delivery / Locked split view
-- - Batch lock / unlock
-- - Drop by Value
-- - Webhook send
-- ============================================================
if game:GetService("CoreGui"):FindFirstChild("GAG_AutoMail") then
    game:GetService("CoreGui").GAG_AutoMail:Destroy()
end

local Players      = game:GetService("Players")
local Workspace    = game:GetService("Workspace")
local CoreGui      = game:GetService("CoreGui")
local RS           = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local lp           = Players.LocalPlayer
local Networking   = require(RS.SharedModules.Networking)

-- ============================================================================
-- CENTRALIZED FAB STACK MANAGER SETUP
-- ============================================================================
local FABManager = _G.FABManager
if not FABManager then
    FABManager = {
        Buttons = {},
        PriorityMap = {
            SharveyManager = 1,
            FruitDropper = 2,
            AutoMail = 3,
            FruitSummary = 4,
            HarvestFruits = 5
        }
    }
    _G.FABManager = FABManager
    
    function FABManager.Update()
        local TweenSvc = game:GetService("TweenService")
        -- Self-heal: Clean up destroyed buttons
        local i = 1
        while i <= #FABManager.Buttons do
            local btnData = FABManager.Buttons[i]
            if not btnData.Button or not btnData.Button.Parent then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, i)
            else
                i = i + 1
            end
        end

        local activeButtons = {}
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Visible then
                table.insert(activeButtons, btnData)
            end
        end
        
        local count = #activeButtons
        if count == 0 then return end
        
        local buttonSize = 48
        local spacing = 12
        local totalHeight = (count * buttonSize) + ((count - 1) * spacing)
        local startYOffset = -totalHeight / 2
        
        for idx, btnData in ipairs(activeButtons) do
            local targetYOffset = startYOffset + ((idx - 1) * (buttonSize + spacing)) + (buttonSize / 2)
            local targetPos = UDim2.new(1, -16, 0.5, targetYOffset)
            local targetShadowPos = UDim2.new(1, -14, 0.5, targetYOffset + 2)
            
            local tInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
            
            if btnData.Button and btnData.Button.Parent then
                TweenSvc:Create(btnData.Button, tInfo, {Position = targetPos}):Play()
            end
            if btnData.Shadow and btnData.Shadow.Parent then
                TweenSvc:Create(btnData.Shadow, tInfo, {Position = targetShadowPos}):Play()
            end
        end
    end
    
    function FABManager.Register(id, button, shadow, onClick)
        FABManager.Unregister(id)
        
        local btnData = {
            Id = id,
            Button = button,
            Shadow = shadow,
            Visible = true,
            OnClick = onClick
        }
        
        table.insert(FABManager.Buttons, btnData)
        
        table.sort(FABManager.Buttons, function(a, b)
            local pA = FABManager.PriorityMap[a.Id] or 99
            local pB = FABManager.PriorityMap[b.Id] or 99
            return pA < pB
        end)
        
        if onClick then
            btnData.Connection = button.MouseButton1Click:Connect(onClick)
        end
        
        FABManager.Update()
        return btnData
    end
    
    function FABManager.Unregister(id)
        for idx, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, idx)
                FABManager.Update()
                break
            end
        end
    end
    
    function FABManager.SetVisible(id, visible)
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                btnData.Visible = visible
                if btnData.Button and btnData.Button.Parent then
                    btnData.Button.Visible = visible
                end
                if btnData.Shadow and btnData.Shadow.Parent then
                    btnData.Shadow.Visible = visible
                end
                FABManager.Update()
                break
            end
        end
    end
end

-- =====================
-- WEBHOOK
-- =====================
local WEBHOOK_URL = "https://discord.com/api/webhooks/1521708365284245596/TQi5BPYuuyc0xoVpYhpB7tUwAdHmXKMnY4EdmQaRbpiNL5MZtZ2rTJcFiEEaePSQkIDV"

local function sendWebhook(title, body, color)
    task.spawn(function()
        pcall(function()
            request({
                Url = WEBHOOK_URL,
                Method = "POST",
                Headers = { ["Content-Type"] = "application/json" },
                Body = game:GetService("HttpService"):JSONEncode({
                    embeds = {{
                        title = title,
                        description = body,
                        color = color or 3447003,
                        timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
                    }}
                })
            })
        end)
    end)
end

-- =====================
-- COLORS
-- =====================
local C = {
    bg        = Color3.fromRGB(14,14,20),
    panel     = Color3.fromRGB(20,20,28),
    border    = Color3.fromRGB(42,42,58),
    accent    = Color3.fromRGB(90,210,130),
    accentDim = Color3.fromRGB(30,65,45),
    text      = Color3.fromRGB(215,215,228),
    muted     = Color3.fromRGB(100,100,120),
    header    = Color3.fromRGB(18,18,26),
    danger    = Color3.fromRGB(220,80,80),
    dangerDim = Color3.fromRGB(70,25,25),
    gold      = Color3.fromRGB(255,195,55),
    locked    = Color3.fromRGB(255,165,0),
    lockedDim = Color3.fromRGB(70,45,0),
}

local TIERS = {
    {label="1-3M",   min=1,   max=3  },
    {label="3-5M",   min=3,   max=5  },
    {label="5-10M",  min=5,   max=10 },
    {label="10-15M", min=10,  max=15 },
    {label="15-20M", min=15,  max=20 },
    {label="20M+",   min=20,  max=9999},
}
local TIER_COLORS = {
    Color3.fromRGB(160,160,170),
    Color3.fromRGB(100,200,100),
    Color3.fromRGB(80,140,255),
    Color3.fromRGB(255,180,40),
    Color3.fromRGB(180,100,255),
    Color3.fromRGB(255,60,60),
}
local MUT_COLORS = {
    Electric   = Color3.fromRGB(255,230,80),
    Gold       = Color3.fromRGB(255,200,40),
    Rainbow    = Color3.fromRGB(255,120,220),
    Frozen     = Color3.fromRGB(120,200,255),
    Bloodlit   = Color3.fromRGB(200,40,60),
    Starstruck = Color3.fromRGB(180,180,240),
    Aurora     = Color3.fromRGB(130,220,255),
}

local function fmtVal(m)
    if m >= 1000 then return string.format("%.1fB", math.floor(m/100)/10)
    elseif m >= 1 then return string.format("%dM", math.floor(m))
    elseif m >= 0.001 then return string.format("%dK", math.floor(m*1000))
    else return "0M" end
end

local function getTierIndex(val)
    for i, t in ipairs(TIERS) do
        if val >= t.min and val < t.max then return i end
    end
    return nil
end

-- =====================
-- UI HELPERS
-- =====================
local function mkFrame(parent, size, pos, color, radius)
    local f = Instance.new("Frame", parent)
    f.Size=size; f.Position=pos
    f.BackgroundColor3=color or C.panel
    f.BorderSizePixel=0
    if radius then Instance.new("UICorner",f).CornerRadius=UDim.new(0,radius) end
    return f
end

local function mkLabel(parent, text, size, pos, color, fs, bold)
    local l = Instance.new("TextLabel", parent)
    l.BackgroundTransparency=1
    l.Size=size; l.Position=pos
    l.Text=text; l.TextColor3=color or C.text
    l.TextSize=fs or 10
    l.Font=bold and Enum.Font.GothamBold or Enum.Font.GothamMedium
    l.TextXAlignment=Enum.TextXAlignment.Left
    l.TextTruncate=Enum.TextTruncate.AtEnd
    return l
end

local function mkBtn(parent, text, size, pos, bg, fg, cb)
    local b = Instance.new("TextButton", parent)
    b.Size=size; b.Position=pos
    b.BackgroundColor3=bg; b.BorderSizePixel=0
    b.Text=text; b.TextColor3=fg
    b.TextSize=10; b.Font=Enum.Font.GothamBold
    b.AutoButtonColor=false
    Instance.new("UICorner",b).CornerRadius=UDim.new(0,4)
    if cb then b.MouseButton1Click:Connect(cb) end
    return b
end

-- =====================
-- MAIN WINDOW
-- =====================
local WIN_W, WIN_H = 340, 620

local gui = Instance.new("ScreenGui")
gui.Name = "GAG_AutoMail"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = CoreGui

local main = mkFrame(gui, UDim2.new(0,WIN_W,0,WIN_H), UDim2.new(1,-360,0.5,-290), C.bg, 10)
main.Active = true; main.Draggable = true; main.ClipsDescendants = true
Instance.new("UIStroke",main).Color = C.border

-- Header
local hdr = mkFrame(main, UDim2.new(1,0,0,32), UDim2.new(0,0,0,0), C.header, 10)
mkLabel(hdr, "🎒 ALT PICKER v2", UDim2.new(1,-60,1,0), UDim2.new(0,12,0,0), C.accent, 12, true)

-- =====================
-- FAB INTEGRATION
-- =====================
local fabShadow = Instance.new("Frame")
fabShadow.Size = UDim2.fromOffset(48, 48)
fabShadow.AnchorPoint = Vector2.new(1, 0.5)
fabShadow.BackgroundColor3 = Color3.new(0, 0, 0)
fabShadow.BackgroundTransparency = 0.7
fabShadow.BorderSizePixel = 0
fabShadow.Parent = gui
Instance.new("UICorner", fabShadow).CornerRadius = UDim.new(0, 12)

local fabBtn = Instance.new("TextButton")
fabBtn.Size = UDim2.fromOffset(48, 48)
fabBtn.AnchorPoint = Vector2.new(1, 0.5)
fabBtn.BackgroundColor3 = Color3.fromHex("#3B82F6") -- Mail Blue
fabBtn.BackgroundTransparency = 0.15
fabBtn.BorderSizePixel = 0
fabBtn.Text = "📬"
fabBtn.TextSize = 24
fabBtn.Font = Enum.Font.Gotham
fabBtn.Parent = gui
Instance.new("UICorner", fabBtn).CornerRadius = UDim.new(0, 12)

local fabTweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local fabBaseColor = Color3.fromHex("#3B82F6")
local fabHoverColor = Color3.fromHex("#60A5FA")

fabBtn.MouseEnter:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = fabHoverColor}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)
fabBtn.MouseLeave:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = fabBaseColor}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)
fabBtn.MouseButton1Down:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)
fabBtn.MouseButton1Up:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

-- Window API
local windowAPI = { Minimized = false }

function windowAPI:Minimize()
    if self.Minimized then return end
    self.Minimized = true
    main.Visible = false
    FABManager.SetVisible("AutoMail", true)
end

function windowAPI:Restore()
    if not self.Minimized then return end
    self.Minimized = false
    main.Visible = true
    FABManager.SetVisible("AutoMail", false)
end

-- Header Buttons
mkBtn(hdr, "—", UDim2.new(0,24,0,20), UDim2.new(1,-54,0.5,-10), C.border, C.muted, function()
    windowAPI:Minimize()
end)

mkBtn(hdr, "✕", UDim2.new(0,24,0,20), UDim2.new(1,-28,0.5,-10), C.dangerDim, C.danger, function()
    FABManager.Unregister("AutoMail")
    gui:Destroy()
end)

-- Register FAB globally
FABManager.Register("AutoMail", fabBtn, fabShadow, function() windowAPI:Restore() end)

-- Enforce starting Minimized
windowAPI.Minimized = true
main.Visible = false
FABManager.SetVisible("AutoMail", true)

-- Status bar
local statusLbl = mkLabel(main, "Pickup: OFF", UDim2.new(1,-16,0,13), UDim2.new(0,8,0,36), C.muted, 9)

-- Row 1: pickup
local pickupBtn = mkBtn(main, "▶ Start Pickup",
    UDim2.new(1,-16,0,20), UDim2.new(0,8,0,52), C.accentDim, C.accent)

-- Row 2: scan delivery | scan locked
local scanDeliveryBtn = mkBtn(main, "🔍 Scan Delivery",
    UDim2.new(0.5,-4,0,20), UDim2.new(0,8,0,76), C.panel, C.muted)
local scanLockedBtn = mkBtn(main, "🔒 Scan Locked",
    UDim2.new(0.5,-4,0,20), UDim2.new(0.5,4,0,76), C.lockedDim, C.locked)

-- Row 3: lock/unlock
local lockThreshF = mkFrame(main, UDim2.new(0.35,-4,0,20), UDim2.new(0,8,0,100), C.panel, 4)
Instance.new("UIStroke",lockThreshF).Color = C.border
mkLabel(lockThreshF, "Lock>M:", UDim2.new(0,30,1,0), UDim2.new(0,2,0,0), C.muted, 8)
local lockThreshInput = Instance.new("TextBox", lockThreshF)
lockThreshInput.Size = UDim2.new(1,-34,1,0); lockThreshInput.Position = UDim2.new(0,32,0,0)
lockThreshInput.BackgroundTransparency = 1; lockThreshInput.Text = "5"
lockThreshInput.TextColor3 = C.locked; lockThreshInput.TextSize = 9
lockThreshInput.Font = Enum.Font.GothamBold; lockThreshInput.ClearTextOnFocus = false
lockThreshInput.PlaceholderColor3 = C.muted

local lockBtn   = mkBtn(main, "🔒 Lock",      UDim2.new(0.33,-4,0,20), UDim2.new(0.35,4,0,100), C.lockedDim, C.locked)
local unlockBtn = mkBtn(main, "🔓 Unlock All", UDim2.new(0.32,-4,0,20), UDim2.new(0.68,4,0,100), C.dangerDim, C.danger)

-- Row 4: webhook
local webhookBtn = mkBtn(main, "📤 Send to Discord",
    UDim2.new(0.5,-4,0,20), UDim2.new(0,8,0,124), Color3.fromRGB(60,40,100), C.accent)
local mailBtn = mkBtn(main, "📬 Mail",
    UDim2.new(0.5,-4,0,20), UDim2.new(0.5,4,0,124), Color3.fromRGB(20,40,70), Color3.fromRGB(80,160,255))

-- Row 5: Drop by Value
local dropValFrame = mkFrame(main, UDim2.new(0.35,-4,0,20), UDim2.new(0,8,0,172), C.panel, 4)
Instance.new("UIStroke",dropValFrame).Color = C.border
mkLabel(dropValFrame, "Target M:", UDim2.new(0,36,1,0), UDim2.new(0,2,0,0), C.muted, 8)
local dropValInput = Instance.new("TextBox", dropValFrame)
dropValInput.Size = UDim2.new(1,-40,1,0); dropValInput.Position = UDim2.new(0,38,0,0)
dropValInput.BackgroundTransparency = 1; dropValInput.Text = "300"
dropValInput.TextColor3 = C.gold; dropValInput.TextSize = 9
dropValInput.Font = Enum.Font.GothamBold; dropValInput.ClearTextOnFocus = false
dropValInput.PlaceholderColor3 = C.muted

local dropValBtn = mkBtn(main, "🎯 Drop by Value",
    UDim2.new(0.65,-8,0,20), UDim2.new(0.35,4,0,172), Color3.fromRGB(60,35,90), Color3.fromRGB(180,120,255))

local dropValStatusLbl = mkLabel(main, "", UDim2.new(1,-16,0,12), UDim2.new(0,8,0,196), C.muted, 9)

-- Summary
local summaryLbl = mkLabel(main, "", UDim2.new(1,-16,0,13), UDim2.new(0,8,0,211), C.muted, 9)

-- Scroll
local scroll = Instance.new("ScrollingFrame", main)
scroll.Size = UDim2.new(1,-16,0, WIN_H - 228)
scroll.Position = UDim2.new(0,8,0,226)
scroll.BackgroundColor3 = C.panel
scroll.BorderSizePixel = 0
scroll.ScrollBarThickness = 4
scroll.ScrollBarImageColor3 = C.border
scroll.CanvasSize = UDim2.new(0,0,0,0)
scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
Instance.new("UICorner",scroll).CornerRadius=UDim.new(0,6)
local lay = Instance.new("UIListLayout",scroll)
lay.Padding=UDim.new(0,2); lay.SortOrder=Enum.SortOrder.LayoutOrder
local sPad = Instance.new("UIPadding",scroll)
sPad.PaddingLeft=UDim.new(0,4); sPad.PaddingRight=UDim.new(0,4)
sPad.PaddingTop=UDim.new(0,4); sPad.PaddingBottom=UDim.new(0,4)

-- =====================
-- STATE
-- =====================
local backpackFruits  = {}
local currentScanMode = "delivery"
local picking         = false

-- =====================
-- BATCH SCAN
-- =====================
local SCAN_BATCH = 10

local function scanBackpackWithBid(favouriteFilter, onProgress)
    local bp   = lp:FindFirstChildOfClass("Backpack")
    local char = lp.Character
    local fruits = {}
    for _, container in ipairs({bp, char}) do
        if container then
            for _, item in ipairs(container:GetChildren()) do
                local fav = item:GetAttribute("IsFavorite") == true
                if item:GetAttribute("HarvestedFruit") and item:GetAttribute("Id") then
                    if fav == favouriteFilter then
                        table.insert(fruits, {
                            id       = item:GetAttribute("Id"),
                            name     = item:GetAttribute("FruitName") or item.Name,
                            mutation = item:GetAttribute("Mutation") or "",
                            kg       = 7.4826 * (item:GetAttribute("SizeMultiplier") or 0),
                            favorite = fav,
                            value    = 0,
                            tierIdx  = nil,
                        })
                    end
                end
            end
        end
    end

    local total = #fruits
    if total == 0 then return fruits end

    local i = 1
    while i <= total do
        local bEnd = math.min(i + SCAN_BATCH - 1, total)
        local pending = bEnd - i + 1
        for j = i, bEnd do
            local e = fruits[j]
            task.spawn(function()
                local ok, res = pcall(function()
                    return Networking.NPCS.GetFruitBid:Fire(e.id)
                end)
                if ok and res then
                    e.value = (res.CurrentSellValue or res.CurrentOffer or res.BidPrice or 0) / 1000000
                end
                e.tierIdx = getTierIndex(e.value)
                pending = pending - 1
            end)
        end
        local t0 = tick()
        while pending > 0 and tick()-t0 < 3 do task.wait(0.03) end
        if onProgress then onProgress(math.min(bEnd,total), total) end
        i = bEnd + 1
        if i <= total then task.wait(0.15) end
    end

    table.sort(fruits, function(a,b) return a.value > b.value end)
    return fruits
end

-- =====================
-- BATCH FAVOURITE
-- =====================
local function batchFavourite(entries, state, onDone)
    local BATCH = 10
    local i = 1
    local total = #entries
    while i <= total do
        local bEnd = math.min(i + BATCH - 1, total)
        local pending = bEnd - i + 1
        for j = i, bEnd do
            local entry = entries[j]
            task.spawn(function()
                pcall(function()
                    Networking.Backpack.SetFruitFavorite:Fire(entry.id, state)
                end)
                entry.favorite = state
                pending = pending - 1
            end)
        end
        local t0 = tick()
        while pending > 0 and tick()-t0 < 3 do task.wait(0.03) end
        i = bEnd + 1
        if i <= total then task.wait(0.1) end
    end
    if onDone then onDone(total) end
end

-- =====================
-- SCROLL / ROW
-- =====================
local function clearScroll()
    for _, c in ipairs(scroll:GetChildren()) do
        if c:IsA("Frame") or c:IsA("TextLabel") or c:IsA("TextButton") then c:Destroy() end
    end
end

local function renderList()
    clearScroll()
    local totalVal = 0
    for _, e in ipairs(backpackFruits) do totalVal = totalVal + e.value end
    local modeLabel = currentScanMode == "locked" and "Locked" or "Delivery"
    summaryLbl.Text = string.format("%s: %d fruits  %s  tap to equip", modeLabel, #backpackFruits, fmtVal(totalVal))
    for i, entry in ipairs(backpackFruits) do
        local baseBg = Color3.fromRGB(24,24,34)
        local row = Instance.new("TextButton", scroll)
        row.Size = UDim2.new(1,0,0,28); row.BackgroundColor3 = baseBg
        row.BorderSizePixel = 0; row.Text = ""; row.AutoButtonColor = false
        row.LayoutOrder = i
        Instance.new("UICorner",row).CornerRadius=UDim.new(0,4)

        if entry.favorite then
            mkLabel(row, "★", UDim2.new(0,12,1,0), UDim2.new(0,2,0,0), C.gold, 9, true)
        end

        local wb = mkFrame(row, UDim2.new(0,46,0,18), UDim2.new(0,16,0.5,-9), Color3.fromRGB(28,28,40), 3)
        local wl = mkLabel(wb, string.format("%.0fkg", entry.kg), UDim2.new(1,0,1,0), UDim2.new(0,0,0,0), C.gold, 9, true)
        wl.TextXAlignment = Enum.TextXAlignment.Center

        mkLabel(row, entry.name, UDim2.new(0,100,1,0), UDim2.new(0,66,0,0), C.text, 9)

        if entry.mutation ~= "" then
            local mc = MUT_COLORS[entry.mutation] or C.muted
            local mb = mkFrame(row, UDim2.new(0,64,0,16), UDim2.new(1,-150,0.5,-8), Color3.fromRGB(20,20,28), 3)
            Instance.new("UIStroke",mb).Color = mc
            local ml = mkLabel(mb, entry.mutation, UDim2.new(1,0,1,0), UDim2.new(0,0,0,0), mc, 8, true)
            ml.TextXAlignment = Enum.TextXAlignment.Center
        end

        local tc = entry.tierIdx and TIER_COLORS[entry.tierIdx] or C.muted
        local vl = mkLabel(row, fmtVal(entry.value), UDim2.new(0,76,1,0), UDim2.new(1,-80,0,0), tc, 9, true)
        vl.TextXAlignment = Enum.TextXAlignment.Right

        local clicking = false
        row.MouseButton1Click:Connect(function()
            if clicking then return end
            clicking = true
            row.BackgroundColor3 = Color3.fromRGB(200,160,60)
            local bp = lp:FindFirstChildOfClass("Backpack")
            Networking.Backpack.PromoteFruit:Fire(entry.id)
            local tool = nil
            local t0 = tick()
            while tick()-t0 < 3 do
                task.wait(0.05)
                if bp then
                    for _, item in ipairs(bp:GetChildren()) do
                        if item:IsA("Tool") and item:GetAttribute("Id") == entry.id
                        and not item:GetAttribute("FruitProxy") then
                            tool = item; break
                        end
                    end
                end
                if tool then break end
            end
            if tool then
                local hum = lp.Character and lp.Character:FindFirstChildOfClass("Humanoid")
                if hum then hum:EquipTool(tool) end
                row.BackgroundColor3 = Color3.fromRGB(40,120,60)
            else
                row.BackgroundColor3 = Color3.fromRGB(120,40,40)
            end
            task.wait(0.4)
            row.BackgroundColor3 = baseBg
            clicking = false
        end)
    end
    if #backpackFruits == 0 then
        local el = Instance.new("TextLabel", scroll)
        el.BackgroundTransparency=1; el.Size=UDim2.new(1,0,0,30)
        el.Text="Nothing here"; el.TextColor3=C.muted; el.TextSize=9
        el.Font=Enum.Font.GothamMedium; el.TextXAlignment=Enum.TextXAlignment.Center
    end
end

-- =====================
-- PICKUP LOOP
-- =====================
pickupBtn.MouseButton1Click:Connect(function()
    picking = not picking
    if picking then
        pickupBtn.Text = "⛔ Stop Pickup"
        pickupBtn.BackgroundColor3 = C.dangerDim
        pickupBtn.TextColor3 = C.danger
        statusLbl.Text = "Pickup: ON"
        statusLbl.TextColor3 = C.accent
        task.spawn(function()
            local DroppedItems = workspace:WaitForChild("DroppedItems")
            while picking do
                for _, item in ipairs(DroppedItems:GetChildren()) do
                    if not picking then break end
                    local anchor = item:FindFirstChild("PromptAnchor")
                    if anchor and item:GetAttribute("ItemCategory") == "HarvestedFruits" then
                        local prompt = anchor:FindFirstChild("PickupPrompt")
                        if prompt and prompt:IsA("ProximityPrompt") then
                            local hrp = lp.Character and lp.Character:FindFirstChild("HumanoidRootPart")
                            if hrp then
                                if item:IsA("Model") and item.PrimaryPart then
                                    hrp.CFrame = item.PrimaryPart.CFrame + Vector3.new(0,3,0)
                                else
                                    for _, part in ipairs(item:GetDescendants()) do
                                        if part:IsA("BasePart") then
                                            hrp.CFrame = part.CFrame + Vector3.new(0,3,0); break
                                        end
                                    end
                                end
                            end
                            task.wait(0.1)
                            pcall(function() fireproximityprompt(prompt) end)
                            task.wait(0.3)
                        end
                    end
                end
                task.wait(0.5)
            end
        end)
    else
        picking = false
        pickupBtn.Text = "▶ Start Pickup"
        pickupBtn.BackgroundColor3 = C.accentDim
        pickupBtn.TextColor3 = C.accent
        statusLbl.Text = "Pickup: OFF"
        statusLbl.TextColor3 = C.muted
    end
end)

-- =====================
-- SCAN BUTTONS
-- =====================
local function doScan(favouriteFilter, btn, label, labelColor)
    btn.Active = false
    btn.Text = "Scanning..."
    btn.TextColor3 = C.muted
    task.spawn(function()
        backpackFruits = scanBackpackWithBid(favouriteFilter, function(done, total)
            btn.Text = string.format("Scanning %d/%d...", done, total)
        end)
        currentScanMode = favouriteFilter and "locked" or "delivery"
        btn.Text = label
        btn.TextColor3 = labelColor
        btn.Active = true
        renderList()
    end)
end

scanDeliveryBtn.MouseButton1Click:Connect(function()
    doScan(false, scanDeliveryBtn, "🔍 Scan Delivery", C.muted)
end)

scanLockedBtn.MouseButton1Click:Connect(function()
    doScan(true, scanLockedBtn, "🔒 Scan Locked", C.locked)
end)

-- =====================
-- LOCK / UNLOCK
-- =====================
lockBtn.MouseButton1Click:Connect(function()
    if #backpackFruits == 0 then
        lockBtn.Text = "Scan first"
        task.wait(2); lockBtn.Text = "🔒 Lock"; return
    end
    local threshold = tonumber(lockThreshInput.Text) or 5
    lockBtn.Active = false
    lockBtn.Text = "Locking..."
    local queue = {}
    for _, entry in ipairs(backpackFruits) do
        if entry.value >= threshold then table.insert(queue, entry) end
    end
    task.spawn(function()
        batchFavourite(queue, true, function(count)
            lockBtn.Text = string.format("✓ %d locked", count)
            task.wait(2); lockBtn.Text = "🔒 Lock"
            lockBtn.Active = true
            renderList()
        end)
    end)
end)

unlockBtn.MouseButton1Click:Connect(function()
    unlockBtn.Active = false
    unlockBtn.Text = "Unlocking..."
    local bp   = lp:FindFirstChildOfClass("Backpack")
    local char = lp.Character
    local queue = {}
    for _, container in ipairs({bp, char}) do
        if container then
            for _, item in ipairs(container:GetChildren()) do
                if item:GetAttribute("HarvestedFruit") then
                    local id = item:GetAttribute("Id")
                    if id then table.insert(queue, {id=id}) end
                end
            end
        end
    end
    task.spawn(function()
        batchFavourite(queue, false, function(count)
            for _, e in ipairs(backpackFruits) do e.favorite = false end
            unlockBtn.Text = string.format("✓ %d unlocked", count)
            task.wait(2); unlockBtn.Text = "🔓 Unlock All"
            unlockBtn.Active = true
            renderList()
        end)
    end)
end)

-- =====================
-- DROP BY VALUE
-- =====================
local droppingByVal = false

dropValBtn.MouseButton1Click:Connect(function()
    if currentScanMode == "locked" then
        dropValStatusLbl.Text = "Switch to Delivery scan first"
        return
    end
    if droppingByVal then
        droppingByVal = false
        dropValBtn.Text = "🎯 Drop by Value"
        dropValBtn.BackgroundColor3 = Color3.fromRGB(60,35,90)
        dropValBtn.TextColor3 = Color3.fromRGB(180,120,255)
        dropValStatusLbl.Text = "Cancelled"
        return
    end
    if #backpackFruits == 0 then
        dropValStatusLbl.Text = "Scan delivery first"
        return
    end

    local target = tonumber(dropValInput.Text) or 300
    local sorted = {}
    for _, e in ipairs(backpackFruits) do
        if not e.favorite then table.insert(sorted, e) end
    end
    table.sort(sorted, function(a,b) return a.value > b.value end)

    local queue, total = {}, 0
    for _, e in ipairs(sorted) do
        if total >= target then break end
        table.insert(queue, e); total = total + e.value
    end

    if total < target then
        dropValStatusLbl.Text = string.format("Only %s available", fmtVal(total))
        return
    end

    dropValStatusLbl.Text = string.format("Dropping %d fruits  %s", #queue, fmtVal(total))
    dropValBtn.Text = "⛔ Cancel"
    dropValBtn.BackgroundColor3 = C.dangerDim
    dropValBtn.TextColor3 = C.danger
    droppingByVal = true

    task.spawn(function()
        local bp = lp:FindFirstChildOfClass("Backpack")
        local dropped = 0
        local batchCount = 0
        local BATCH_SIZE = 10

        local function removeFromList(id)
            for i, e in ipairs(backpackFruits) do
                if e.id == id then table.remove(backpackFruits, i); break end
            end
            renderList()
        end

        local function promoteFruit(id)
            Networking.Backpack.PromoteFruit:Fire(id)
            local t0 = tick()
            while tick()-t0 < 3 do
                task.wait(0.05)
                if bp then
                    for _, item in ipairs(bp:GetChildren()) do
                        if item:IsA("Tool") and item:GetAttribute("Id") == id
                        and not item:GetAttribute("FruitProxy") then return item end
                    end
                end
            end
            return nil
        end

        for _, entry in ipairs(queue) do
            if not droppingByVal then break end
            dropValStatusLbl.Text = string.format("Dropping %d/%d  %s", dropped+1, #queue, fmtVal(total))
            local tool = promoteFruit(entry.id)
            if tool then
                local hum = lp.Character and lp.Character:FindFirstChildOfClass("Humanoid")
                if hum then hum:EquipTool(tool) end
                task.wait(0.5)
                Networking.DroppedItem.RequestDrop:Fire("HarvestedFruits", entry.id)
                dropped = dropped + 1
                batchCount = batchCount + 1
                removeFromList(entry.id)
                task.wait(0.3)
                if batchCount >= BATCH_SIZE then
                    dropValStatusLbl.Text = "Waiting for pickup..."
                    local ws = tick()
                    while droppingByVal and tick()-ws < 60 do
                        local di = Workspace:FindFirstChild("DroppedItems")
                        if di and #di:GetChildren() == 0 then break end
                        task.wait(1)
                    end
                    batchCount = 0
                end
            else
                task.wait(0.3)
            end
        end

        droppingByVal = false
        dropValBtn.Text = "🎯 Drop by Value"
        dropValBtn.BackgroundColor3 = Color3.fromRGB(60,35,90)
        dropValBtn.TextColor3 = Color3.fromRGB(180,120,255)
        dropValStatusLbl.Text = string.format("Done  %d fruits  %s", dropped, fmtVal(total))
    end)
end)

-- =====================
-- WEBHOOK
-- =====================
webhookBtn.MouseButton1Click:Connect(function()
    if #backpackFruits == 0 then
        webhookBtn.Text = "Scan first"
        task.wait(2); webhookBtn.Text = "📤 Send to Discord"; return
    end
    webhookBtn.Text = "Sending..."
    local lines, total = {}, 0
    local tierTotals, tierCounts = {}, {}
    for _, e in ipairs(backpackFruits) do
        total = total + e.value
        local tl = e.tierIdx and TIERS[e.tierIdx].label or "?"
        tierTotals[tl] = (tierTotals[tl] or 0) + e.value
        tierCounts[tl] = (tierCounts[tl] or 0) + 1
        local fav = e.favorite and "★ " or ""
        table.insert(lines, string.format("%s%s [%s] %.0fkg  %s",
            fav, e.name, e.mutation ~= "" and e.mutation or "None", e.kg, fmtVal(e.value)))
    end
    local breakdown = {}
    for _, t in ipairs(TIERS) do
        if tierCounts[t.label] then
            table.insert(breakdown, string.format("%s: %dx  %s",
                t.label, tierCounts[t.label], fmtVal(tierTotals[t.label])))
        end
    end
    local modeTag = currentScanMode == "locked" and "Locked" or "Delivery"
    local footer = string.format("\n\nAlt %s: %d fruits  %s\n%s",
        modeTag, #backpackFruits, fmtVal(total), table.concat(breakdown, "  "))
    local CHUNK, chunk, part = 3800, "", 1
    for _, line in ipairs(lines) do
        if #chunk + #line + 1 > CHUNK then
            sendWebhook(string.format("Alt %s (%d)", modeTag, part), chunk, 3447003)
            chunk = ""; part = part + 1; task.wait(0.5)
        end
        chunk = chunk .. line .. "\n"
    end
    sendWebhook(string.format("Alt %s (%d)", modeTag, part), chunk..footer, 3447003)
    webhookBtn.Text = "✓ Sent"
    task.wait(2); webhookBtn.Text = "📤 Send to Discord"
end)

-- =====================
-- MANUAL MAIL POPUP
-- =====================
local manualMailGui = nil

local function buildManualMailPopup()
    if manualMailGui and manualMailGui.Parent then manualMailGui:Destroy() end

    if #backpackFruits == 0 then
        mailBtn.Text = "Scan first"
        task.wait(2); mailBtn.Text = "📬 Mail"; return
    end

    local mmGui = Instance.new("ScreenGui")
    mmGui.Name = "GAG_AltMail"
    mmGui.ResetOnSpawn = false
    mmGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    mmGui.Parent = CoreGui
    manualMailGui = mmGui

    local MW, MH = 360, 420
    local mmMain = Instance.new("Frame", mmGui)
    mmMain.Size = UDim2.new(0,MW,0,MH)
    mmMain.Position = UDim2.new(0.5,-MW/2,0.5,-MH/2)
    mmMain.BackgroundColor3 = Color3.fromRGB(12,12,18)
    mmMain.BorderSizePixel = 0
    mmMain.Active = true; mmMain.Draggable = true; mmMain.ClipsDescendants = true
    Instance.new("UICorner",mmMain).CornerRadius = UDim.new(0,10)
    local mms = Instance.new("UIStroke",mmMain)
    mms.Color = Color3.fromRGB(80,140,255); mms.Thickness = 1

    local mmHdr = mkFrame(mmMain, UDim2.new(1,0,0,28), UDim2.new(0,0,0,0),
        Color3.fromRGB(10,20,40), 10)
    mkLabel(mmHdr, "📬 Manual Mail", UDim2.new(1,-40,1,0), UDim2.new(0,10,0,0),
        Color3.fromRGB(80,140,255), 12, true)
    mkBtn(mmHdr, "✕", UDim2.new(0,24,0,20), UDim2.new(1,-28,0.5,-10),
        C.dangerDim, C.danger, function()
            mmGui:Destroy(); manualMailGui = nil
        end)

    -- Recipient
    mkLabel(mmMain, "Recipient:", UDim2.new(0,70,0,18), UDim2.new(0,10,0,36), C.muted, 9)
    local recipF = mkFrame(mmMain, UDim2.new(1,-90,0,22), UDim2.new(0,80,0,34), C.panel, 4)
    Instance.new("UIStroke",recipF).Color = C.border
    local recipInput = Instance.new("TextBox", recipF)
    recipInput.Size = UDim2.new(1,-8,1,0); recipInput.Position = UDim2.new(0,4,0,0)
    recipInput.BackgroundTransparency = 1; recipInput.Text = ""
    recipInput.TextColor3 = Color3.fromRGB(80,140,255); recipInput.TextSize = 10
    recipInput.Font = Enum.Font.GothamBold; recipInput.ClearTextOnFocus = false
    recipInput.PlaceholderText = "username"; recipInput.PlaceholderColor3 = C.muted

    -- Total value target
    mkLabel(mmMain, "Total to send (M):", UDim2.new(0,110,0,18), UDim2.new(0,10,0,64), C.muted, 9)
    local totalF = mkFrame(mmMain, UDim2.new(1,-130,0,22), UDim2.new(0,120,0,62), C.panel, 4)
    Instance.new("UIStroke",totalF).Color = C.border
    local totalInput = Instance.new("TextBox", totalF)
    totalInput.Size = UDim2.new(1,-8,1,0); totalInput.Position = UDim2.new(0,4,0,0)
    totalInput.BackgroundTransparency = 1; totalInput.Text = ""
    totalInput.TextColor3 = C.gold; totalInput.TextSize = 10
    totalInput.Font = Enum.Font.GothamBold; totalInput.ClearTextOnFocus = false
    totalInput.PlaceholderText = "e.g. 500"; totalInput.PlaceholderColor3 = C.muted

    local mmStatus = mkLabel(mmMain, "", UDim2.new(1,-16,0,16),
        UDim2.new(0,8,0,92), C.muted, 9, false, Enum.TextXAlignment.Center)

    local previewBtn = mkBtn(mmMain, "Preview Plan", UDim2.new(0.5,-4,0,24),
        UDim2.new(0,8,0,112), Color3.fromRGB(25,35,65), Color3.fromRGB(80,140,255))

    local confirmBtn = mkBtn(mmMain, "Confirm + Send",
        UDim2.new(0.5,-4,0,24), UDim2.new(0.5,4,0,112),
        Color3.fromRGB(20,20,30), Color3.fromRGB(50,50,70))
    confirmBtn.Active = false

    -- Plan scroll
    local planScroll = Instance.new("ScrollingFrame", mmMain)
    planScroll.Size = UDim2.new(1,-16,0,170)
    planScroll.Position = UDim2.new(0,8,0,142)
    planScroll.BackgroundTransparency = 1
    planScroll.BorderSizePixel = 0
    planScroll.ScrollBarThickness = 3
    planScroll.ScrollBarImageColor3 = C.border
    planScroll.CanvasSize = UDim2.new(0,0,0,0)
    planScroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    local pll = Instance.new("UIListLayout",planScroll); pll.Padding = UDim.new(0,1)
    local plp = Instance.new("UIPadding",planScroll)
    plp.PaddingLeft = UDim.new(0,4); plp.PaddingTop = UDim.new(0,4)

    local lineCount = 0
    local function planLog(msg, color)
        lineCount = lineCount + 1
        local line = Instance.new("TextLabel", planScroll)
        line.BackgroundTransparency = 1; line.Size = UDim2.new(1,-4,0,13)
        line.Text = msg; line.TextColor3 = color or C.text
        line.TextSize = 9; line.Font = Enum.Font.GothamMedium
        line.TextXAlignment = Enum.TextXAlignment.Left
        line.TextWrapped = true; line.AutomaticSize = Enum.AutomaticSize.Y
        line.LayoutOrder = lineCount
        task.defer(function()
            if planScroll and planScroll.Parent then
                planScroll.CanvasPosition = Vector2.new(0, planScroll.AbsoluteCanvasSize.Y)
            end
        end)
    end

    local function clearPlan()
        for _, c in ipairs(planScroll:GetChildren()) do
            if c:IsA("TextLabel") then c:Destroy() end
        end
        lineCount = 0
    end

    local function setConfirm(enabled)
        confirmBtn.Active = enabled
        confirmBtn.BackgroundColor3 = enabled and Color3.fromRGB(25,40,70) or Color3.fromRGB(20,20,30)
        confirmBtn.TextColor3 = enabled and Color3.fromRGB(80,160,255) or Color3.fromRGB(50,50,70)
    end

    local mmPlan = nil
    local mmRecipientId = nil

    previewBtn.MouseButton1Click:Connect(function()
        local username = recipInput.Text:match("^%s*(.-)%s*$")
        local targetM  = tonumber(totalInput.Text) or 0

        if username == "" then
            mmStatus.Text = "Enter a recipient username"
            mmStatus.TextColor3 = C.danger; return
        end
        if targetM <= 0 then
            mmStatus.Text = "Enter a total value in M"
            mmStatus.TextColor3 = C.danger; return
        end

        previewBtn.Active = false
        previewBtn.Text = "Resolving..."
        mmStatus.Text = "Looking up " .. username .. "..."
        mmStatus.TextColor3 = C.muted
        setConfirm(false); clearPlan()
        mmPlan = nil; mmRecipientId = nil

        task.spawn(function()
            local ok, rid = pcall(function()
                return Players:GetUserIdFromNameAsync(username)
            end)
            if not ok or not rid then
                mmStatus.Text = "Username not found"
                mmStatus.TextColor3 = C.danger
                previewBtn.Active = true; previewBtn.Text = "Preview Plan"; return
            end
            mmRecipientId = rid
            mmStatus.Text = "Resolved: " .. username .. " (ID " .. tostring(rid) .. ")"
            mmStatus.TextColor3 = Color3.fromRGB(90,210,130)

            -- Sort by value, build queue to target
            local sorted = {}
            for _, e in ipairs(backpackFruits) do table.insert(sorted, e) end
            table.sort(sorted, function(a,b) return a.value > b.value end)

            local queue, runningTotal = {}, 0
            for _, e in ipairs(sorted) do
                if runningTotal >= targetM then break end
                table.insert(queue, e)
                runningTotal = runningTotal + e.value
            end

            if runningTotal < targetM then
                clearPlan()
                planLog(string.format("Not enough — only %s available (need %sM)",
                    fmtVal(runningTotal), tostring(targetM)), C.danger)
                mmStatus.Text = "Insufficient value"
                mmStatus.TextColor3 = C.danger
                previewBtn.Active = true; previewBtn.Text = "Preview Plan"; return
            end

            -- Build batches of 20
            local batches = {}
            for i = 1, #queue, 20 do
                local b, bVal = {}, 0
                for j = i, math.min(i+19, #queue) do
                    table.insert(b, queue[j])
                    bVal = bVal + queue[j].value
                end
                table.insert(batches, {fruits=b, value=bVal})
            end

            clearPlan()
            planLog(string.format("To: %s   Target: %sM   Actual: %s",
                username, tostring(targetM), fmtVal(runningTotal)),
                Color3.fromRGB(80,140,255))
            planLog(string.format("Batches: %d   Total fruits: %d", #batches, #queue), C.muted)
            planLog("---", C.border)
            for i, batch in ipairs(batches) do
                planLog(string.format("Batch %d: %d fruits  %s",
                    i, #batch.fruits, fmtVal(batch.value)), C.accent)
            end

            mmPlan = batches
            setConfirm(true)
            previewBtn.Active = true; previewBtn.Text = "Preview Plan"
            mmStatus.Text = "Plan ready — confirm to send"
            mmStatus.TextColor3 = Color3.fromRGB(90,210,130)
        end)
    end)

    confirmBtn.MouseButton1Click:Connect(function()
        if not mmPlan or not mmRecipientId then return end
        setConfirm(false); previewBtn.Active = false

        task.spawn(function()
            local totalSent, totalVal = 0, 0
            for i, batch in ipairs(mmPlan) do
                mmStatus.Text = string.format("Sending batch %d/%d...", i, #mmPlan)
                mmStatus.TextColor3 = C.gold

                local items = {}
                for j, fruit in ipairs(batch.fruits) do
                    items[j] = {Category="HarvestedFruits", ItemKey=fruit.id, Count=1}
                end
                local note = fmtVal(batch.value)

                local ok, err = pcall(function()
                    Networking.Mailbox.SendBatch:Fire(mmRecipientId, items, note)
                end)

                if ok then
                    totalSent = totalSent + #batch.fruits
                    totalVal  = totalVal  + batch.value
                    for _, fruit in ipairs(batch.fruits) do
                        for k = #backpackFruits, 1, -1 do
                            if backpackFruits[k].id == fruit.id then
                                table.remove(backpackFruits, k); break
                            end
                        end
                    end
                else
                    mmStatus.Text = "Batch " .. i .. " failed: " .. tostring(err):sub(1,40)
                    mmStatus.TextColor3 = C.danger; break
                end

                if i < #mmPlan then
                    for countdown = 10, 1, -1 do
                        mmStatus.Text = string.format("Cooldown %ds...", countdown)
                        task.wait(1)
                    end
                end
            end

            mmStatus.Text = string.format("Done: %d fruits  %s to %s",
                totalSent, fmtVal(totalVal), recipInput.Text)
            mmStatus.TextColor3 = Color3.fromRGB(90,210,130)
            sendWebhook(
                string.format("Alt Manual Mail — %s", lp.Name),
                string.format("Account: %s\nTo: %s\nTotal value: %s\nFruits: %d",
                    lp.Name, recipInput.Text, fmtVal(totalVal), totalSent)
            )
            mmPlan = nil
            renderList()
        end)
    end)
end

mailBtn.MouseButton1Click:Connect(function()
    buildManualMailPopup()
end)

print("[GAG2 Alt Picker v2] Loaded.")