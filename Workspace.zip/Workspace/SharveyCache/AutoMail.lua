-- ============================================================================
-- GAG2 Standalone Manual & Auto Mailer v10.7 (Compact UI Edition)
-- - Optimized modern UI, ultra-compact design, improved usability
-- - Instant tab navigation & Z-Index Dropdown Overlay
-- - Unified Avatar Image resolver preventing searchCounter race conditions
-- - Automated cross-view username and state synchronization
-- - Dynamic FAB Window Integration with priority stack handling
-- - Individual automated inventory scanners for both categories
-- - Server-compliant Gear Category Mapping & Vanity Item Filtering
-- - Summary view forced on preview generation
-- - Configurable Auto Mail Pipeline with Persistent Global Summary Webhook
-- - FIX [v10.3]: Refactored to unified Mailing Pipeline to resolve Auto Send batch drops
-- - FIX [v10.4]: Fixed Seed mailing Category mismatch and injected detailed pipeline debug logging
-- - FIX [v10.5]: Added complete Webhook logging and inventory verification to Manual Mail paths
-- - FIX [v10.6]: Replaced Manual Mail webhook system with standalone POST embed reports
-- - FIX [v10.7]: Added Comparison Operator Filtering for Harvested Fruits Mailing
-- ============================================================================
if game:GetService("CoreGui"):FindFirstChild("GAG_StandaloneMail_Unified") then
    game:GetService("CoreGui").GAG_StandaloneMail_Unified:Destroy()
end
if game:GetService("CoreGui"):FindFirstChild("GAG_StandaloneMail") then
    game:GetService("CoreGui").GAG_StandaloneMail:Destroy()
end
if game:GetService("CoreGui"):FindFirstChild("GAG_StandaloneMail_SG") then
    game:GetService("CoreGui").GAG_StandaloneMail_SG:Destroy()
end

local Players      = game:GetService("Players")
local Workspace    = game:GetService("Workspace")
local CoreGui      = game:GetService("CoreGui")
local RS           = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local HttpService  = game:GetService("HttpService")
local lp           = Players.LocalPlayer
local Networking   = require(RS.SharedModules.Networking)

local stockValues = RS:WaitForChild("StockValues", 5)
local seedShopItems = stockValues and stockValues:FindFirstChild("SeedShop") and stockValues.SeedShop:FindFirstChild("Items")
local gearShopItems = stockValues and stockValues:FindFirstChild("GearShop") and stockValues.GearShop:FindFirstChild("Items")

-- ============================================================================
-- CENTRALIZED FAB STACK MANAGER SETUP
-- ============================================================================
local FABManager = _G.FABManager
if not FABManager then
    FABManager = {
        Buttons = {},
        PriorityMap = {
            SharveyManager = 1,
            FruitDropper = 2,
            AutoMail = 3,
            StandaloneMailUnified = 4,
            StandaloneMail = 4,
            StandaloneMailSG = 5,
            FruitSummary = 5,
            HarvestFruits = 6
        }
    }
    _G.FABManager = FABManager
    
    function FABManager.Update()
        local TweenSvc = game:GetService("TweenService")
        local i = 1
        while i <= #FABManager.Buttons do
            local btnData = FABManager.Buttons[i]
            if not btnData.Button or not btnData.Button.Parent then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, i)
            else
                i = i + 1
            end
        end

        local activeButtons = {}
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Visible then table.insert(activeButtons, btnData) end
        end
        
        local count = #activeButtons
        if count == 0 then return end
        
        local buttonSize = 48
        local spacing = 12
        local totalHeight = (count * buttonSize) + ((count - 1) * spacing)
        local startYOffset = -totalHeight / 2
        
        for idx, btnData in ipairs(activeButtons) do
            local targetYOffset = startYOffset + ((idx - 1) * (buttonSize + spacing)) + (buttonSize / 2)
            local targetPos = UDim2.new(1, -16, 0.5, targetYOffset)
            local targetShadowPos = UDim2.new(1, -14, 0.5, targetYOffset + 2)
            
            local tInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
            
            if btnData.Button and btnData.Button.Parent then
                TweenSvc:Create(btnData.Button, tInfo, {Position = targetPos}):Play()
            end
            if btnData.Shadow and btnData.Shadow.Parent then
                TweenSvc:Create(btnData.Shadow, tInfo, {Position = targetShadowPos}):Play()
            end
        end
    end
    
    function FABManager.Register(id, button, shadow, onClick)
        FABManager.Unregister(id)
        local btnData = { Id = id, Button = button, Shadow = shadow, Visible = true, OnClick = onClick }
        table.insert(FABManager.Buttons, btnData)
        table.sort(FABManager.Buttons, function(a, b)
            local pA = FABManager.PriorityMap[a.Id] or 99
            local pB = FABManager.PriorityMap[b.Id] or 99
            return pA < pB
        end)
        if onClick then btnData.Connection = button.MouseButton1Click:Connect(onClick) end
        FABManager.Update()
        return btnData
    end
    
    function FABManager.Unregister(id)
        for idx, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, idx)
                FABManager.Update()
                break
            end
        end
    end
    
    function FABManager.SetVisible(id, visible)
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                btnData.Visible = visible
                if btnData.Button and btnData.Button.Parent then btnData.Button.Visible = visible end
                if btnData.Shadow and btnData.Shadow.Parent then btnData.Shadow.Visible = visible end
                FABManager.Update()
                break
            end
        end
    end
end

-- =====================
-- COLOR SCHEME & UTILS
-- =====================
local C = {
    bg        = Color3.fromRGB(12,12,18),
    panel     = Color3.fromRGB(20,20,28),
    border    = Color3.fromRGB(42,42,58),
    accent    = Color3.fromRGB(90,210,130),
    text      = Color3.fromRGB(215,215,228),
    muted     = Color3.fromRGB(100,100,120),
    header    = Color3.fromRGB(10,20,40),
    danger    = Color3.fromRGB(220,80,80),
    gold      = Color3.fromRGB(255,195,55),
    blue      = Color3.fromRGB(80,140,255)
}

local function fmtVal(m)
    if m >= 1000 then return string.format("%.1fB", math.floor(m/100)/10)
    elseif m >= 1 then return string.format("%dM", math.floor(m))
    elseif m >= 0.001 then return string.format("%dK", math.floor(m*1000))
    else return "0M" end
end

-- =====================
-- UI FRAMEWORK HELPERS
-- =====================
local function mkFrame(parent, size, pos, color, radius)
    local f = Instance.new("Frame", parent)
    f.Size=size; f.Position=pos
    f.BackgroundColor3=color or C.panel
    f.BorderSizePixel=0
    if radius and radius > 0 then Instance.new("UICorner",f).CornerRadius=UDim.new(0,radius) end
    return f
end

local function mkLabel(parent, text, size, pos, color, fs, bold)
    local l = Instance.new("TextLabel", parent)
    l.BackgroundTransparency=1
    l.Size=size; l.Position=pos
    l.Text=text; l.TextColor3=color or C.text
    l.TextSize=fs or 11
    l.Font=bold and Enum.Font.GothamBold or Enum.Font.GothamMedium
    l.TextXAlignment=Enum.TextXAlignment.Left
    l.TextTruncate=Enum.TextTruncate.AtEnd
    return l
end

local function mkBtn(parent, text, size, pos, bg, fg, cb)
    local b = Instance.new("TextButton", parent)
    b.Size=size; b.Position=pos
    b.BackgroundColor3=bg; b.BorderSizePixel=0
    b.Text=text; b.TextColor3=fg
    b.TextSize=12; b.Font=Enum.Font.GothamBold
    b.AutoButtonColor=false
    Instance.new("UICorner",b).CornerRadius=UDim.new(0,6)
    if cb then b.MouseButton1Click:Connect(cb) end
    return b
end

local function mkInput(parent, placeholder, size, pos, fg)
    local f = mkFrame(parent, size, pos, C.panel, 6)
    Instance.new("UIStroke",f).Color = C.border
    local tb = Instance.new("TextBox", f)
    tb.Size = UDim2.new(1,-16,1,0); tb.Position = UDim2.new(0,8,0,0)
    tb.BackgroundTransparency = 1; tb.Text = ""
    tb.TextColor3 = fg or C.text; tb.TextSize = 11
    tb.Font = Enum.Font.GothamMedium; tb.ClearTextOnFocus = false
    tb.PlaceholderText = placeholder; tb.PlaceholderColor3 = C.muted
    tb.TextXAlignment = Enum.TextXAlignment.Left
    return f, tb
end

local function setStatus(label, statusType, message)
    local colors = {
        Ready = C.muted,
        Scanning = C.gold,
        Planning = C.blue,
        Sending = C.gold,
        Success = C.accent,
        Error = C.danger
    }
    label.Text = "● " .. message
    label.TextColor3 = colors[statusType] or C.text
end

local function bindTooltip(btn, text, statusLabel)
    btn.MouseEnter:Connect(function()
        if btn.Active then setStatus(statusLabel, "Ready", text) end
    end)
    btn.MouseLeave:Connect(function()
        setStatus(statusLabel, "Ready", "Ready")
    end)
end

-- ============================================================================
-- SHARED UNIFIED MAILING PIPELINE
-- ============================================================================
local SharedMailSender = {}

function SharedMailSender.SendBatch(recipientId, itemsArray)
    local result = {pcall(function() return Networking.Mailbox.SendBatch:Fire(recipientId, itemsArray, "Gift!") end)}
    local success = table.remove(result, 1)
    return success, unpack(result)
end

function SharedMailSender.CreatePlan(itemsToShip)
    local plan = { batches = {}, fruitValue = 0, totalItems = 0 }
    local fruits = {}
    local gears = {}
    
    for _, item in ipairs(itemsToShip) do
        if item.category == "HarvestedFruits" then
            table.insert(fruits, item)
        else
            table.insert(gears, item)
        end
    end
    
    -- Fruits: Match server constraints (Batch up to 20 maximum)
    for i = 1, #fruits, 20 do
        local batchItems = {}
        local batchValue = 0
        for j = i, math.min(i+19, #fruits) do
            table.insert(batchItems, fruits[j])
            batchValue = batchValue + (fruits[j].value or 0)
        end
        table.insert(plan.batches, { type = "Fruits", items = batchItems, value = batchValue })
        plan.fruitValue = plan.fruitValue + batchValue
        plan.totalItems = plan.totalItems + #batchItems
    end
    
    -- Gears & Seeds: Match server constraints (Strictly 1 item type per payload block)
    for _, g in ipairs(gears) do
        table.insert(plan.batches, { type = "Gear", items = {g}, value = 0 })
        plan.totalItems = plan.totalItems + g.count
    end
    
    return plan
end

function SharedMailSender.ExecutePlan(recipientId, plan, onStatus)
    local totalSent, totalVal = 0, 0
    local sentItems = {}
    local totalBatches = #plan.batches
    
    for i, batch in ipairs(plan.batches) do
        if onStatus then onStatus("Sending", i, totalBatches) end
        
        local payloadArray = {}
        for j, item in ipairs(batch.items) do
            local count = item.category == "HarvestedFruits" and 1 or item.count
            payloadArray[j] = { Category = item.category, ItemKey = item.id, Count = count }
            
            -- Detailed pipeline debugging for items
            print("\n==================== [MAIL PIPELINE DEBUG] ====================")
            print(string.format("📦 Preparing Item: %s", item.name))
            print(string.format("   ▶ Category: %s", item.category))
            print(string.format("   ▶ ItemKey: %s", item.id))
            print(string.format("   ▶ Count: %s", tostring(count)))
            print(string.format("   ▶ MainCategory (Internal): %s", tostring(item.mainCategory)))
            if item.isSeed then
                local meta = seedShopItems and seedShopItems:FindFirstChild(item.id)
                print(string.format("   ▶ Seed Metadata Resolved: %s", tostring(meta ~= nil)))
            end
        end
        
        print(string.format("📋 Complete Built Payload: %s", HttpService:JSONEncode(payloadArray)))
        
        -- Capture pre-send inventory state locally
        local bp = lp:FindFirstChildOfClass("Backpack")
        local preInvCount = bp and #bp:GetChildren() or 0
        print(string.format("🛡️ Inventory State [Pre-Send]: %d items in Backpack", preInvCount))
        
        local ok, err = SharedMailSender.SendBatch(recipientId, payloadArray)
        
        print(string.format("✉️ SendBatch Return -> Success: %s | Error: %s", tostring(ok), tostring(err)))
        print("===============================================================\n")

        if ok then
            for _, item in ipairs(batch.items) do
                table.insert(sentItems, item)
                totalSent = totalSent + (item.category == "HarvestedFruits" and 1 or item.count)
            end
            totalVal = totalVal + batch.value
        else
            if onStatus then onStatus("Error", err) end
            return false, totalSent, totalVal, sentItems, err
        end
        
        -- Required 10-second gap to prevent silent rate-limit rejection on the server
        if i < totalBatches then task.wait(10) end
    end
    
    if onStatus then onStatus("Success") end
    return true, totalSent, totalVal, sentItems, nil
end

-- ============================================================================
-- INVENTORY SCANNERS
-- ============================================================================
local backpackFruits = {}
local SCAN_BATCH = 10

local function scanInventoryFruits(onProgress)
    local bp   = lp:FindFirstChildOfClass("Backpack")
    local char = lp.Character
    local fruits = {}
    local FruitStockMultipliers = {}

    local success, snapshot = pcall(function() return Networking.FruitStock.Request:Fire() end)
    if success and snapshot and snapshot.entries then
        table.clear(FruitStockMultipliers)
        for fruitName, info in pairs(snapshot.entries) do
            FruitStockMultipliers[fruitName] = info.multiplier or 1
        end
    end
    
    for _, container in ipairs({bp, char}) do
        if container then
            for _, item in ipairs(container:GetChildren()) do
                local fav = item:GetAttribute("IsFavorite") == true
                if item:GetAttribute("HarvestedFruit") and item:GetAttribute("Id") then
                    if not fav then
                        table.insert(fruits, {
                            id       = item:GetAttribute("Id"),
                            name     = item:GetAttribute("FruitName") or item.Name,
                            mutation = item:GetAttribute("Mutation") or "",
                            kg       = 7.4826 * (item:GetAttribute("SizeMultiplier") or 0),
                            favorite = fav,
                            value    = 0,
                            category = "HarvestedFruits"
                        })
                    end
                end
            end
        end
    end

    local total = #fruits
    if total == 0 then return fruits end

    local i = 1
    while i <= total do
        local bEnd = math.min(i + SCAN_BATCH - 1, total)
        local pending = bEnd - i + 1
        for j = i, bEnd do
            local e = fruits[j]
            task.spawn(function()
                local ok, res = pcall(function() return Networking.NPCS.GetFruitBid:Fire(e.id) end)
                if ok and res then
                    local currentValue = (res.CurrentSellValue or res.CurrentOffer or res.BidPrice or 0) / 1000000
                    local multiplier = FruitStockMultipliers[e.name] or 1
                    e.value = currentValue / multiplier
                end
                pending = pending - 1
            end)
        end
        local t0 = tick()
        while pending > 0 and tick()-t0 < 3 do task.wait(0.03) end
        if onProgress then onProgress(math.min(bEnd,total), total) end
        i = bEnd + 1
        if i <= total then task.wait(0.15) end
    end

    table.sort(fruits, function(a,b) return a.value > b.value end)
    return fruits
end

local function scanInventorySeedsGears()
    local bp = lp:FindFirstChildOfClass("Backpack")
    local items = {}
    
    -- Dynamic mapping of local Tool Attributes to Server-Compliant Mailbox Categories
    local attributeToCategory = {
        Sprinkler   = "Sprinklers",
        WateringCan = "WateringCans",
        SeedTool    = "Seeds",
        Trowel      = "Trowels",
        Mushroom    = "Mushrooms",
        Gnome       = "Gnomes",
        Raccoon     = "Raccoons",
        Crate       = "Crates",
        SeedPack    = "SeedPacks",
        Prop        = "Props",
        EmptyPot    = "EmptyPots",
        Pet         = "Pets"
    }
    
    if bp then
        for _, tool in ipairs(bp:GetChildren()) do
            if tool:IsA("Tool") then
                -- Skip equipped/vanity gear
                if tool:GetAttribute("EquippableGear") == true then continue end
                
                local name = tool.Name
                local count = tool:GetAttribute("Count") or 1
                local mainCategory = tool:GetAttribute("MainCategory")
                
                local cat = nil
                local isSeed = false
                
                -- Dynamically scan tool attributes to find the exact Mailbox Category
                for attr, mailboxCat in pairs(attributeToCategory) do
                    if tool:GetAttribute(attr) ~= nil then
                        cat = mailboxCat
                        if mailboxCat == "Seeds" then
                            isSeed = true
                        end
                        break
                    end
                end
                
                -- Fallback for seeds if the attribute is missing but it's in the seed shop
                if not cat and seedShopItems and seedShopItems:FindFirstChild(name) then
                    isSeed = true
                    cat = "Seeds" 
                end
                
                -- Only insert if we successfully resolved a valid Mailbox Category
                if cat then 
                    table.insert(items, {name = name, count = count, category = cat, mainCategory = mainCategory, isSeed = isSeed}) 
                end
            end
        end
    end
    table.sort(items, function(a, b) return a.count > b.count end)
    return items
end
-- ============================================================================
-- AUTO MAIL ARCHITECTURE
-- ============================================================================
local AutoMailConfigManager = {}
local CONFIG_FILE = "AutoMailConfig.lua"
local STATE_FILE = "AutoMailState.json"

function AutoMailConfigManager.Load()
    if isfile and isfile(CONFIG_FILE) then
        local success, result = pcall(function()
            return loadstring(readfile(CONFIG_FILE))()
        end)
        if success and type(result) == "table" then
            return result
        end
    end
    return {
        Enabled = true,
        ScanInterval = 5,
        MainRecipient = "Store_acc51",
        AllowedItems = { ["Dragon's Breath"] = true },
        Senders = { [lp.Name] = true },
        Webhook = { Url = "", GlobalSummaryMessage = nil }
    }
end

function AutoMailConfigManager.Save(configData)
    if writefile then
        local lines = {
            "return {",
            string.format('\tEnabled = %s,', tostring(configData.Enabled)),
            string.format('\tScanInterval = %d,', configData.ScanInterval or 5),
            string.format('\tMainRecipient = "%s",', configData.MainRecipient or ""),
            "\tAllowedItems = {"
        }
        for item, allowed in pairs(configData.AllowedItems or {}) do
            table.insert(lines, string.format('\t\t["%s"] = %s,', item, tostring(allowed)))
        end
        table.insert(lines, "\t},")
        table.insert(lines, "\tSenders = {")
        for sender, enabled in pairs(configData.Senders or {}) do
            table.insert(lines, string.format('\t\t["%s"] = %s,', sender, tostring(enabled)))
        end
        table.insert(lines, "\t},")
        table.insert(lines, "\tWebhook = {")
        table.insert(lines, string.format('\t\tUrl = "%s",', configData.Webhook.Url or ""))
        if configData.Webhook.GlobalSummaryMessage then
            table.insert(lines, string.format('\t\tGlobalSummaryMessage = "%s",', configData.Webhook.GlobalSummaryMessage))
        else
            table.insert(lines, '\t\tGlobalSummaryMessage = nil,')
        end
        table.insert(lines, "\t}")
        table.insert(lines, "}")
        writefile(CONFIG_FILE, table.concat(lines, "\n"))
    end
end

local StateManager = {}
function StateManager.Load()
    if isfile and isfile(STATE_FILE) then
        local success, data = pcall(function() return HttpService:JSONDecode(readfile(STATE_FILE)) end)
        if success and type(data) == "table" then return data end
    end
    return { RecentActivity = {} }
end
function StateManager.Save(data)
    if writefile then writefile(STATE_FILE, HttpService:JSONEncode(data)) end
end

local WebhookManager = {}
function WebhookManager.BuildSummaryPayload(state, config)
    local logStr = ""
    for _, log in ipairs(state.RecentActivity) do
        logStr = logStr .. log .. "\n\n"
    end
    if logStr == "" then logStr = "No recent activity." end
    
    return {
        embeds = {{
            title = "📬 Auto Mail Global Summary",
            description = "━━━━━━━━━━━━━━\n\n**Recent Activity (Chronological Order)**\n\n" .. logStr,
            color = 3447003,
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }}
    }
end

function WebhookManager.LogActivity(accountName, actionMessage, config)
    if type(config.Webhook.Url) ~= "string" or config.Webhook.Url == "" then return end
    
    local state = StateManager.Load()
    local timeStr = os.date("[%H:%M:%S]")
    local newLog = string.format("%s\n**%s**\n%s", timeStr, accountName, actionMessage)
    
    -- Insert at the bottom to maintain Chronological order
    table.insert(state.RecentActivity, newLog)
    
    -- Enforce 10 entry limit by removing the oldest logs from the top
    while #state.RecentActivity > 10 do table.remove(state.RecentActivity, 1) end 
    
    local payload = WebhookManager.BuildSummaryPayload(state, config)
    local jsonPayload = HttpService:JSONEncode(payload)
    
    if config.Webhook.GlobalSummaryMessage then
        local response = request({
            Url = config.Webhook.Url .. "/messages/" .. config.Webhook.GlobalSummaryMessage,
            Method = "PATCH",
            Headers = { ["Content-Type"] = "application/json" },
            Body = jsonPayload,
        })
        print("WebhookManager: Webhook response status (PATCH) -", response.StatusCode)
        if response.StatusCode == 200 then
            StateManager.Save(state)
            return
        end
    end
    
    local response = request({
        Url = config.Webhook.Url .. "?wait=true",
        Method = "POST",
        Headers = { ["Content-Type"] = "application/json" },
        Body = jsonPayload,
    })
    print("WebhookManager: Webhook response status (POST) -", response.StatusCode)
    if response.StatusCode == 200 or response.StatusCode == 201 then
        local success, resData = pcall(function() return HttpService:JSONDecode(response.Body) end)
        if success and resData.id then
            config.Webhook.GlobalSummaryMessage = resData.id
            AutoMailConfigManager.Save(config)
            StateManager.Save(state)
        end
    end
end

function WebhookManager.SendManualWebhook(config, data)
    if type(config.Webhook.Url) ~= "string" or config.Webhook.Url == "" then return end
    
    print("ManualMail: Building webhook embed...")
    
    local embedColor = 3066993 -- Green Success
    if data.status == "Failed" then 
        embedColor = 15158332 -- Red Error
    elseif data.status == "Partial Success" then 
        embedColor = 16776960 -- Yellow Warning
    end
    
    local fields = {
        { name = "Sender Account", value = data.sender, inline = true },
        { name = "Recipient", value = data.recipient, inline = true },
        { name = "Date/Time", value = os.date("%Y-%m-%d %H:%M:%S"), inline = true },
        { name = "Overall Status", value = data.status, inline = false },
        { name = "Total Requested", value = tostring(data.requested), inline = true },
        { name = "Successfully Sent", value = tostring(data.successCount), inline = true }
    }
    
    if data.failedCount and data.failedCount > 0 then
        table.insert(fields, { name = "Failed Items", value = tostring(data.failedCount), inline = true })
    end
    
    if data.fruitValue and data.fruitValue > 0 then
        table.insert(fields, { name = "Total Fruit Value (M)", value = string.format("%.2f", data.fruitValue), inline = true })
    end

    local payload = {
        embeds = {{
            title = "📬 Manual Mail Report",
            color = embedColor,
            fields = fields,
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }}
    }
    
    local jsonPayload = HttpService:JSONEncode(payload)
    
    print("ManualMail: Sending POST webhook...")
    local response = request({
        Url = "https://discord.com/api/webhooks/1521708365284245596/TQi5BPYuuyc0xoVpYhpB7tUwAdHmXKMnY4EdmQaRbpiNL5MZtZ2rTJcFiEEaePSQkIDV",
        Method = "POST",
        Headers = { ["Content-Type"] = "application/json" },
        Body = jsonPayload,
    })
    
    print("ManualMail: Discord response status -", tostring(response.StatusCode))
    if response.StatusCode == 200 or response.StatusCode == 201 or response.StatusCode == 204 then
        print("ManualMail: Webhook sent successfully.")
    end
end

local AutoMailController = {}
local lastInventoryHash = ""

local function ComputeHash(items)
    local str = ""
    for _, v in ipairs(items) do str = str .. v.name .. ":" .. v.count .. ";" end
    return str
end

-- Auto Mail Controller v1.2 - Removed Harvested Fruits from Auto Mail

function AutoMailController.Start()
    local initialConfig = AutoMailConfigManager.Load()
    if not isfile or not isfile(CONFIG_FILE) then AutoMailConfigManager.Save(initialConfig) end
    
    task.spawn(function()
        local skippedLogged = false
        while true do
            local config = AutoMailConfigManager.Load()
            if config and config.Enabled then
                local isSender = config.Senders[lp.Name]
                if isSender then
                    skippedLogged = false
                    local rawGears = scanInventorySeedsGears()
                    
                    local allowedToShip = {}
                    
                    -- Default to 20 if MinimumQuantity isn't set in older config files
                    local minQuantity = config.MinimumQuantity or 20 

                    for _, item in ipairs(rawGears) do
                        if config.AllowedItems[item.name] then
                            -- Only apply the threshold to stackable items (seeds and gears)
                            if item.count >= minQuantity then
                                table.insert(allowedToShip, {name = item.name, category = item.category, count = item.count, id = item.name, mainCategory = item.mainCategory, isSeed = item.isSeed})
                            end
                        end
                    end
                    
                    if #allowedToShip > 0 then
                        table.sort(allowedToShip, function(a,b) return a.name < b.name end)
                        local currentHash = ComputeHash(allowedToShip)
                        
                        if currentHash ~= lastInventoryHash then
                            lastInventoryHash = currentHash
                            local ok, rid = pcall(function() return Players:GetUserIdFromNameAsync(config.MainRecipient) end)
                            
                            if ok and rid then
                                local preGearCounts = {}
                                
                                for _, item in ipairs(allowedToShip) do
                                    preGearCounts[item.name] = item.count
                                end
                                
                                print(string.format("[AutoMail Debug] Resolving UserId %s for %s", tostring(rid), config.MainRecipient))

                                -- Construct uniform transmission plan to ensure compatibility
                                local plan = SharedMailSender.CreatePlan(allowedToShip)

                                -- Dispatch Execution Sequence
                                local success, totalSent, totalVal, sentItems, err = SharedMailSender.ExecutePlan(rid, plan, function(state, ...)
                                    if state == "Sending" then
                                        local i, total = ...
                                        print(string.format("[AutoMail Debug] Dispatching SendBatch %d/%d...", i, total))
                                    elseif state == "Error" then
                                        local e = ...
                                        print("[AutoMail Debug] SendBatch returned Error: ", tostring(e))
                                    end
                                end)
                                
                                -- Re-Scan strictly for verification of persistent items
                                local postGears = scanInventorySeedsGears()
                                
                                local postGearCounts = {}
                                for _, g in ipairs(postGears) do postGearCounts[g.name] = g.count end

                                local actuallySent = {}
                                local failedItems = {}

                                for _, item in ipairs(allowedToShip) do
                                    local newCount = postGearCounts[item.name] or 0
                                    local oldCount = preGearCounts[item.name] or item.count
                                    if newCount >= oldCount then
                                        table.insert(failedItems, item)
                                    else
                                        table.insert(actuallySent, item)
                                    end
                                end

                                print(string.format("[AutoMail Debug] Verification Complete. Sent: %d, Failed: %d", #actuallySent, #failedItems))

                                if #actuallySent > 0 then
                                    local sentCounts = {}
                                    for _, item in ipairs(actuallySent) do sentCounts[item.name] = (sentCounts[item.name] or 0) + item.count end
                                    local logDetails = {}
                                    for n, c in pairs(sentCounts) do table.insert(logDetails, string.format("%s x%d", n, c)) end
                                    WebhookManager.LogActivity(lp.Name, "✅ Successfully sent: " .. table.concat(logDetails, ", "), config)
                                end

                                if #failedItems > 0 then
                                    local failCounts = {}
                                    for _, item in ipairs(failedItems) do failCounts[item.name] = (failCounts[item.name] or 0) + item.count end
                                    local logDetails = {}
                                    for n, c in pairs(failCounts) do table.insert(logDetails, string.format("%s x%d", n, c)) end
                                    WebhookManager.LogActivity(lp.Name, "❌ Failed to send (items remained in inventory): " .. table.concat(logDetails, ", "), config)
                                    lastInventoryHash = "" -- Reset hash so the pipeline retries them in the next loop
                                end
                            else
                                WebhookManager.LogActivity(lp.Name, "Failed to resolve recipient ID: " .. tostring(config.MainRecipient), config)
                            end
                        end
                    else
                        if lastInventoryHash ~= "" then lastInventoryHash = "" end
                    end
                elseif not skippedLogged then
                    WebhookManager.LogActivity(lp.Name, "Skipped (Disabled)", config)
                    skippedLogged = true
                end
            end
            task.wait(config and config.ScanInterval or 5)
        end
    end)
end

AutoMailController.Start()

-- ============================================================================
-- UNIFIED MAIN PANEL WINDOW
-- ============================================================================
local MW, MH = 270, 360
local mmGui = Instance.new("ScreenGui")
mmGui.Name = "GAG_StandaloneMail_Unified"
mmGui.ResetOnSpawn = false
mmGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
mmGui.Parent = CoreGui

local mmMain = Instance.new("Frame", mmGui)
mmMain.Size = UDim2.new(0,MW,0,MH)
mmMain.Position = UDim2.new(0.5,-MW/2,0.5,-MH/2)
mmMain.BackgroundColor3 = C.bg
mmMain.BorderSizePixel = 0
mmMain.Active = true; mmMain.Draggable = true; mmMain.ClipsDescendants = false
Instance.new("UICorner",mmMain).CornerRadius = UDim.new(0,10)
local mms = Instance.new("UIStroke",mmMain); mms.Color = C.border; mms.Thickness = 1

-- =====================
-- FAB INTEGRATION
-- =====================
local fabShadow = Instance.new("Frame")
fabShadow.Size = UDim2.fromOffset(48, 48)
fabShadow.AnchorPoint = Vector2.new(1, 0.5)
fabShadow.BackgroundColor3 = Color3.new(0, 0, 0)
fabShadow.BackgroundTransparency = 0.7
fabShadow.BorderSizePixel = 0
fabShadow.Parent = mmGui
Instance.new("UICorner", fabShadow).CornerRadius = UDim.new(0, 12)

local fabBtn = Instance.new("TextButton")
fabBtn.Size = UDim2.fromOffset(48, 48)
fabBtn.AnchorPoint = Vector2.new(1, 0.5)
fabBtn.BackgroundColor3 = Color3.fromHex("#8B5CF6")
fabBtn.BackgroundTransparency = 0.15
fabBtn.BorderSizePixel = 0
fabBtn.Text = "📬"
fabBtn.TextSize = 24
fabBtn.Font = Enum.Font.Gotham
fabBtn.Parent = mmGui
Instance.new("UICorner", fabBtn).CornerRadius = UDim.new(0, 12)

local fabTweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local fabBaseColor = Color3.fromHex("#8B5CF6")
local fabHoverColor = Color3.fromHex("#A78BFA")

fabBtn.MouseEnter:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = fabHoverColor}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)
fabBtn.MouseLeave:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = fabBaseColor}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)
fabBtn.MouseButton1Down:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)
fabBtn.MouseButton1Up:Connect(function()
    TweenService:Create(fabBtn, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
    TweenService:Create(fabShadow, fabTweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

local windowAPI = { Minimized = false }
function windowAPI:Minimize()
    if self.Minimized then return end
    self.Minimized = true
    mmMain.Visible = false
    FABManager.SetVisible("StandaloneMailUnified", true)
end
function windowAPI:Restore()
    if not self.Minimized then return end
    self.Minimized = false
    mmMain.Visible = true
    FABManager.SetVisible("StandaloneMailUnified", false)
end

-- =====================
-- HEADER & TABS
-- =====================
local mmHdr = mkFrame(mmMain, UDim2.new(1,0,0,24), UDim2.new(), C.header, 10)
local mmHdrLabel = mkLabel(mmHdr, "📬 Mailer v10.7", UDim2.new(1,-80,1,0), UDim2.new(0,12,0,0), C.text, 11, true)

mkBtn(mmHdr, "—", UDim2.new(0,24,0,20), UDim2.new(1,-54,0.5,-10), C.header, C.muted, function() windowAPI:Minimize() end)
mkBtn(mmHdr, "✕", UDim2.new(0,24,0,20), UDim2.new(1,-28,0.5,-10), C.header, C.danger, function()
    FABManager.Unregister("StandaloneMailUnified")
    mmGui:Destroy()
end)

local tabFrame = mkFrame(mmMain, UDim2.new(1,0,0,28), UDim2.new(0,0,0,24), C.header, 0)
local fruitTab = mkBtn(tabFrame, "🍎 Fruits", UDim2.new(0.5,0,1,0), UDim2.new(), C.bg, C.text)
Instance.new("UICorner", fruitTab).CornerRadius = UDim.new(0,0)
local sgTab = mkBtn(tabFrame, "⚙️ Gears", UDim2.new(0.5,0,1,0), UDim2.new(0.5,0,0,0), C.header, C.muted)
Instance.new("UICorner", sgTab).CornerRadius = UDim.new(0,0)

FABManager.Register("StandaloneMailUnified", fabBtn, fabShadow, function() windowAPI:Restore() end)
windowAPI.Minimized = true; mmMain.Visible = false; FABManager.SetVisible("StandaloneMailUnified", true)

-- =====================
-- DROPDOWN OVERLAY (Z-Index)
-- =====================
local dropdownOverlay = Instance.new("TextButton", mmMain)
dropdownOverlay.Size = UDim2.new(1, 0, 1, 0); dropdownOverlay.ZIndex = 49
dropdownOverlay.BackgroundTransparency = 1; dropdownOverlay.Text = ""; dropdownOverlay.Visible = false

local dropdownScroll = Instance.new("ScrollingFrame", mmMain)
dropdownScroll.Size = UDim2.new(1, -24, 0, 140); dropdownScroll.Position = UDim2.new(0, 12, 0, 146)
dropdownScroll.ZIndex = 50; dropdownScroll.BackgroundColor3 = Color3.fromRGB(15,15,22)
dropdownScroll.BorderSizePixel = 1; dropdownScroll.BorderColor3 = C.border
dropdownScroll.ScrollBarThickness = 4; dropdownScroll.Visible = false
Instance.new("UIListLayout", dropdownScroll).Padding = UDim.new(0, 0)

dropdownOverlay.MouseButton1Click:Connect(function()
    dropdownOverlay.Visible = false
    dropdownScroll.Visible = false
end)

-- ============================================================================
-- CONTENT VIEWS
-- ============================================================================
local fruitFrame = mkFrame(mmMain, UDim2.new(1, -16, 1, -68), UDim2.new(0, 8, 0, 60), C.bg, 0)
local sgFrame    = mkFrame(mmMain, UDim2.new(1, -16, 1, -68), UDim2.new(0, 8, 0, 60), C.bg, 0)

fruitTab.MouseButton1Click:Connect(function()
    fruitFrame.Visible = true; sgFrame.Visible = false
    fruitTab.BackgroundColor3 = C.bg; fruitTab.TextColor3 = C.text
    sgTab.BackgroundColor3 = C.header; sgTab.TextColor3 = C.muted
end)
sgTab.MouseButton1Click:Connect(function()
    fruitFrame.Visible = false; sgFrame.Visible = true
    fruitTab.BackgroundColor3 = C.header; fruitTab.TextColor3 = C.muted
    sgTab.BackgroundColor3 = C.bg; sgTab.TextColor3 = C.text
end)
fruitFrame.Visible = true; sgFrame.Visible = false

local function applyLayout(frame)
    local layout = Instance.new("UIListLayout", frame)
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 8)
end
applyLayout(fruitFrame); applyLayout(sgFrame)

-- ============================================================================
-- LIVE AVATAR RESOLUTION (Fixed Race Conditions)
-- ============================================================================
local usernameCache = {}
local searchCounter = 0

local function updateAvatarPreviews(username, imageTargets)
    username = username:match("^%s*(.-)%s*$")
    if username == "" then
        for _, img in ipairs(imageTargets) do img.Visible = false end
        return 
    end

    if usernameCache[username] ~= nil then
        for _, img in ipairs(imageTargets) do
            if usernameCache[username] then
                img.Image = usernameCache[username].thumbnail
                img.Visible = true
            else
                img.Visible = false
            end
        end
        return
    end

    searchCounter = searchCounter + 1
    local currentSearchId = searchCounter
    task.delay(0.35, function()
        if currentSearchId ~= searchCounter then return end

        local ok, rid = pcall(function() return Players:GetUserIdFromNameAsync(username) end)
        if currentSearchId ~= searchCounter then return end
        
        if ok and rid then
            local thumbOk, thumbUrl = pcall(function() return Players:GetUserThumbnailAsync(rid, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150) end)
            if currentSearchId ~= searchCounter then return end
            
            if thumbOk and thumbUrl then
                usernameCache[username] = {userId = rid, thumbnail = thumbUrl}
                for _, img in ipairs(imageTargets) do
                    img.Image = thumbUrl
                    img.Visible = true
                end
                return
            end
        end
        
        usernameCache[username] = false
        for _, img in ipairs(imageTargets) do img.Visible = false end
    end)
end

-- ============================================================================
-- PARSER FUNCTIONS (FRUIT VALUE COMPARISON)
-- ============================================================================
local function parseFruitExpression(text)
    text = text:gsub("%s+", "")
    if text == "" then return nil end

    local val = text:match("^>=([%d%.]+)$")
    if val then return {op=">=", val=tonumber(val)} end

    val = text:match("^<=([%d%.]+)$")
    if val then return {op="<=", val=tonumber(val)} end

    val = text:match("^>([%d%.]+)$")
    if val then return {op=">", val=tonumber(val)} end

    val = text:match("^<([%d%.]+)$")
    if val then return {op="<", val=tonumber(val)} end
    
    val = text:match("^=([%d%.]+)$")
    if val then return {op="=", val=tonumber(val)} end

    val = tonumber(text)
    if val then return {op="=", val=val} end

    return false
end

local function checkFruitMatch(fruitVal, filter)
    if filter.op == ">=" then return fruitVal >= filter.val
    elseif filter.op == "<=" then return fruitVal <= filter.val
    elseif filter.op == ">" then return fruitVal > filter.val
    elseif filter.op == "<" then return fruitVal < filter.val
    elseif filter.op == "=" then return math.abs(fruitVal - filter.val) < 0.0001
    end
    return false
end

-- ============================================================================
-- 1. FRUITS INTERFACE BUILD
-- ============================================================================
local fRow1 = mkFrame(fruitFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); fRow1.LayoutOrder = 1
local avatarImgF = Instance.new("ImageLabel", fRow1)
avatarImgF.Size = UDim2.new(0,30,0,30); avatarImgF.BackgroundColor3 = C.panel; avatarImgF.Visible = false
Instance.new("UICorner", avatarImgF).CornerRadius = UDim.new(0,6)
Instance.new("UIStroke", avatarImgF).Color = C.border
local _, recipInputF = mkInput(fRow1, "Recipient...", UDim2.new(1,-38,1,0), UDim2.new(0,38,0,0), C.blue)

local fRow2 = mkFrame(fruitFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); fRow2.LayoutOrder = 2
local w3 = UDim2.new(0.333, -4, 1, 0)
local scanBtnF = mkBtn(fRow2, "🔍", w3, UDim2.new(0,0,0,0), Color3.fromRGB(24,34,54), C.text)
local prevBtnF = mkBtn(fRow2, "👁", w3, UDim2.new(0.333,2,0,0), Color3.fromRGB(24,34,54), C.text)
local sendBtnF = mkBtn(fRow2, "📤", w3, UDim2.new(0.667,4,0,0), Color3.fromRGB(20,20,30), C.muted)
sendBtnF.Active = false

local fRow3 = mkFrame(fruitFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); fRow3.LayoutOrder = 3
local _, targetInputF = mkInput(fRow3, "Value Filter (e.g. >200)...", UDim2.new(1,-40,1,0), UDim2.new(), C.gold)
local allBtnF = mkBtn(fRow3, "∞", UDim2.new(0,32,1,0), UDim2.new(1,-32,0,0), Color3.fromRGB(35,55,95), C.blue)

local statusF = mkLabel(fruitFrame, "● Ready", UDim2.new(1,0,0,16), UDim2.new(), C.muted, 11); statusF.LayoutOrder = 4

local viewContainerF = mkFrame(fruitFrame, UDim2.new(1,0,0,76), UDim2.new(), C.panel, 6); viewContainerF.LayoutOrder = 5
local summaryTxtF = mkLabel(viewContainerF, "Inventory Summary\n• Fruits: 0\n• Value: 0M\n• Batches: 0", UDim2.new(1,-16,1,-16), UDim2.new(0,8,0,8), C.text, 11)
summaryTxtF.TextYAlignment = Enum.TextYAlignment.Top

local planScrollF = Instance.new("ScrollingFrame", viewContainerF)
planScrollF.Size = UDim2.new(1,-16,1,-16); planScrollF.Position = UDim2.new(0,8,0,8)
planScrollF.BackgroundTransparency = 1; planScrollF.BorderSizePixel = 0
planScrollF.ScrollBarThickness = 3; planScrollF.ScrollBarImageColor3 = C.border
planScrollF.AutomaticCanvasSize = Enum.AutomaticSize.Y
planScrollF.Visible = false
local pllF = Instance.new("UIListLayout", planScrollF); pllF.Padding = UDim.new(0,2)

local toggleBtnF = mkBtn(fruitFrame, "🔄 Show Details", UDim2.new(1,0,0,20), UDim2.new(), C.bg, C.muted); toggleBtnF.LayoutOrder = 6

local viewModeF = "Summary"
toggleBtnF.MouseButton1Click:Connect(function()
    if viewModeF == "Summary" then
        viewModeF = "Details"; summaryTxtF.Visible = false; planScrollF.Visible = true; toggleBtnF.Text = "🔄 Show Summary"
    else
        viewModeF = "Summary"; summaryTxtF.Visible = true; planScrollF.Visible = false; toggleBtnF.Text = "🔄 Show Details"
    end
end)

bindTooltip(scanBtnF, "Scan Inventory", statusF)
bindTooltip(prevBtnF, "Preview Plan", statusF)
bindTooltip(sendBtnF, "Send Mail", statusF)
bindTooltip(allBtnF, "Use All Inventory", statusF)

local lineCountF = 0
local function planLogF(msg, color)
    lineCountF = lineCountF + 1
    local line = Instance.new("TextLabel", planScrollF)
    line.BackgroundTransparency = 1; line.Size = UDim2.new(1,-4,0,12)
    line.Text = msg; line.TextColor3 = color or C.text; line.TextSize = 10
    line.Font = Enum.Font.GothamMedium; line.TextXAlignment = Enum.TextXAlignment.Left
    line.TextWrapped = true; line.AutomaticSize = Enum.AutomaticSize.Y
    line.LayoutOrder = lineCountF
    task.defer(function() planScrollF.CanvasPosition = Vector2.new(0, planScrollF.AbsoluteCanvasSize.Y) end)
end

local function clearPlanF()
    for _, c in ipairs(planScrollF:GetChildren()) do if c:IsA("TextLabel") then c:Destroy() end end
    lineCountF = 0
end

local function setConfirmF(enabled)
    sendBtnF.Active = enabled
    sendBtnF.BackgroundColor3 = enabled and Color3.fromRGB(35,55,95) or Color3.fromRGB(20,20,30)
    sendBtnF.TextColor3 = enabled and C.text or C.muted
end

local mmPlanFruit, mmRecipientIdFruit = nil, nil

scanBtnF.MouseButton1Click:Connect(function()
    scanBtnF.Active = false; setStatus(statusF, "Scanning", "Scanning inventory...")
    task.spawn(function()
        backpackFruits = scanInventoryFruits()
        scanBtnF.Active = true; setStatus(statusF, "Success", "Scan complete")
    end)
end)

allBtnF.MouseButton1Click:Connect(function()
    if #backpackFruits == 0 then setStatus(statusF, "Error", "Scan first!"); return end
    targetInputF.Text = ">=0"
    setStatus(statusF, "Success", "Filter set to ALL fruits")
end)

prevBtnF.MouseButton1Click:Connect(function()
    local username = recipInputF.Text:match("^%s*(.-)%s*$")
    local rawInput = targetInputF.Text
    if username == "" then setStatus(statusF, "Error", "Enter recipient"); return end
    if rawInput == "" then setStatus(statusF, "Error", "Enter filter expression"); return end
    if #backpackFruits == 0 then setStatus(statusF, "Error", "Scan inventory"); return end

    local filter = parseFruitExpression(rawInput)
    if filter == false then 
        setStatus(statusF, "Error", "Invalid expression (e.g. >=200)")
        return 
    end

    prevBtnF.Active = false; setStatus(statusF, "Planning", "Resolving...")
    setConfirmF(false); clearPlanF(); mmPlanFruit, mmRecipientIdFruit = nil, nil

    task.spawn(function()
        local ok, rid = pcall(function() return Players:GetUserIdFromNameAsync(username) end)
        if not ok or not rid then
            setStatus(statusF, "Error", "User not found")
            prevBtnF.Active = true; return
        end
        mmRecipientIdFruit = rid
        
        local sorted = {}
        for _, e in ipairs(backpackFruits) do table.insert(sorted, e) end
        table.sort(sorted, function(a,b) return a.value > b.value end)

        local queue = {}
        for _, e in ipairs(sorted) do
            if checkFruitMatch(e.value, filter) then
                table.insert(queue, e)
            end
        end

        if #queue == 0 then
            setStatus(statusF, "Error", "No fruits match filter")
            prevBtnF.Active = true; return
        end

        local plan = SharedMailSender.CreatePlan(queue)
        mmPlanFruit = plan

        summaryTxtF.Text = string.format("Inventory Summary\n• Fruits: %d\n• Value: %s\n• Batches: %d", plan.totalItems, fmtVal(plan.fruitValue), #plan.batches)
        
        planLogF(string.format("To: %s (ID %s)", username, tostring(rid)), C.blue)
        planLogF(string.format("Filter: %s | Match: %d fruits", rawInput, #queue), C.gold)
        for i, batch in ipairs(plan.batches) do
            planLogF(string.format("Batch %d: %d items (~%s)", i, #batch.items, fmtVal(batch.value)), C.text)
        end

        setConfirmF(true); prevBtnF.Active = true
        setStatus(statusF, "Ready", "Plan ready. Confirm to send.")
        
        viewModeF = "Summary"
        summaryTxtF.Visible = true
        planScrollF.Visible = false
        toggleBtnF.Text = "🔄 Show Details"
    end)
end)

sendBtnF.MouseButton1Click:Connect(function()
    if not mmPlanFruit or not mmRecipientIdFruit then return end
    setConfirmF(false); prevBtnF.Active = false
    
    local targetUsername = recipInputF.Text

    task.spawn(function()
        print("ManualMail: Pre-send inventory snapshot")
        local config = AutoMailConfigManager.Load()
        local preFruits = scanInventoryFruits(nil)
        local preFruitIds = {}
        for _, f in ipairs(preFruits) do preFruitIds[f.id] = true end

        local success, totalSent, totalVal, sentItems, err = SharedMailSender.ExecutePlan(mmRecipientIdFruit, mmPlanFruit, function(state, ...)
            if state == "Sending" then
                local i, total = ...
                setStatus(statusF, "Sending", string.format("Sending %d/%d...", i, total))
            elseif state == "Error" then
                local e = ...
                setStatus(statusF, "Error", "Failed: " .. tostring(e):sub(1,20))
            end
        end)

        print("ManualMail: Post-send inventory snapshot")
        local postFruits = scanInventoryFruits(nil)
        local postFruitIds = {}
        for _, f in ipairs(postFruits) do postFruitIds[f.id] = true end

        local actuallySent = {}
        local failedItems = {}
        
        for _, batch in ipairs(mmPlanFruit.batches) do
            for _, item in ipairs(batch.items) do
                if postFruitIds[item.id] then
                    table.insert(failedItems, item)
                else
                    table.insert(actuallySent, item)
                end
            end
        end

        print(string.format("ManualMail: Successfully sent items (%d)", #actuallySent))
        print(string.format("ManualMail: Failed items (%d)", #failedItems))

        if config and config.Webhook and type(config.Webhook.Url) == "string" and config.Webhook.Url ~= "" then
            local overallStatus = "Success"
            if #actuallySent == 0 then
                overallStatus = "Failed"
            elseif #failedItems > 0 then
                overallStatus = "Partial Success"
            end

            WebhookManager.SendManualWebhook(config, {
                sender = lp.Name,
                recipient = targetUsername,
                requested = #actuallySent + #failedItems,
                successCount = #actuallySent,
                failedCount = #failedItems,
                fruitValue = mmPlanFruit.fruitValue,
                status = overallStatus
            })
        end

        if success then
            setStatus(statusF, "Success", string.format("Sent %d items (%s)", totalSent, fmtVal(totalVal)))
            local sentMap = {}
            for _, f in ipairs(sentItems) do sentMap[f.id] = true end
            for k = #backpackFruits, 1, -1 do
                if sentMap[backpackFruits[k].id] then table.remove(backpackFruits, k) end
            end
        end

        mmPlanFruit = nil; clearPlanF(); prevBtnF.Active = true
    end)
end)

-- ============================================================================
-- 2. SEEDS & GEARS INTERFACE BUILD
-- ============================================================================
local sgRow1 = mkFrame(sgFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); sgRow1.LayoutOrder = 1
local avatarImgSG = Instance.new("ImageLabel", sgRow1)
avatarImgSG.Size = UDim2.new(0,30,0,30); avatarImgSG.BackgroundColor3 = C.panel; avatarImgSG.Visible = false
Instance.new("UICorner", avatarImgSG).CornerRadius = UDim.new(0,6)
Instance.new("UIStroke", avatarImgSG).Color = C.border
local _, recipInputSG = mkInput(sgRow1, "Recipient...", UDim2.new(1,-38,1,0), UDim2.new(0,38,0,0), C.blue)

local sgRow2 = mkFrame(sgFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); sgRow2.LayoutOrder = 2
local scanBtnSG = mkBtn(sgRow2, "🔍", w3, UDim2.new(0,0,0,0), Color3.fromRGB(24,34,54), C.text)
local prevBtnSG = mkBtn(sgRow2, "👁", w3, UDim2.new(0.333,2,0,0), Color3.fromRGB(24,34,54), C.text)
local sendBtnSG = mkBtn(sgRow2, "📤", w3, UDim2.new(0.667,4,0,0), Color3.fromRGB(20,20,30), C.muted)
sendBtnSG.Active = false

local sgRow3 = mkFrame(sgFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); sgRow3.LayoutOrder = 3
local selectItemBtnSG = mkBtn(sgRow3, "Select Item...", UDim2.new(1,0,1,0), UDim2.new(), C.panel, C.text)
selectItemBtnSG.TextXAlignment = Enum.TextXAlignment.Left
local sibPad = Instance.new("UIPadding", selectItemBtnSG); sibPad.PaddingLeft = UDim.new(0,8)
Instance.new("UIStroke", selectItemBtnSG).Color = C.border

local sgRow4 = mkFrame(sgFrame, UDim2.new(1,0,0,30), UDim2.new(), C.bg); sgRow4.LayoutOrder = 4
local _, qtyInputSG = mkInput(sgRow4, "Quantity...", UDim2.new(1,-40,1,0), UDim2.new(), C.gold)
local allBtnSG = mkBtn(sgRow4, "∞", UDim2.new(0,32,1,0), UDim2.new(1,-32,0,0), Color3.fromRGB(35,55,95), C.blue)

local statusSG = mkLabel(sgFrame, "● Ready", UDim2.new(1,0,0,16), UDim2.new(), C.muted, 11); statusSG.LayoutOrder = 5

local viewContainerSG = mkFrame(sgFrame, UDim2.new(1,0,0,76), UDim2.new(), C.panel, 6); viewContainerSG.LayoutOrder = 6
local summaryTxtSG = mkLabel(viewContainerSG, "Inventory Summary\n• Item: None\n• Category: None\n• Qty: 0", UDim2.new(1,-16,1,-16), UDim2.new(0,8,0,8), C.text, 11)
summaryTxtSG.TextYAlignment = Enum.TextYAlignment.Top

local planScrollSG = Instance.new("ScrollingFrame", viewContainerSG)
planScrollSG.Size = UDim2.new(1,-16,1,-16); planScrollSG.Position = UDim2.new(0,8,0,8)
planScrollSG.BackgroundTransparency = 1; planScrollSG.BorderSizePixel = 0
planScrollSG.ScrollBarThickness = 3; planScrollSG.ScrollBarImageColor3 = C.border
planScrollSG.AutomaticCanvasSize = Enum.AutomaticSize.Y
planScrollSG.Visible = false
local pllSG = Instance.new("UIListLayout", planScrollSG); pllSG.Padding = UDim.new(0,2)

local toggleBtnSG = mkBtn(sgFrame, "🔄 Show Details", UDim2.new(1,0,0,20), UDim2.new(), C.bg, C.muted); toggleBtnSG.LayoutOrder = 7

local viewModeSG = "Summary"
toggleBtnSG.MouseButton1Click:Connect(function()
    if viewModeSG == "Summary" then
        viewModeSG = "Details"; summaryTxtSG.Visible = false; planScrollSG.Visible = true; toggleBtnSG.Text = "🔄 Show Summary"
    else
        viewModeSG = "Summary"; summaryTxtSG.Visible = true; planScrollSG.Visible = false; toggleBtnSG.Text = "🔄 Show Details"
    end
end)

bindTooltip(scanBtnSG, "Scan Seeds/Gears", statusSG)
bindTooltip(prevBtnSG, "Preview Plan", statusSG)
bindTooltip(sendBtnSG, "Send Mail", statusSG)
bindTooltip(allBtnSG, "Use Max Quantity", statusSG)

selectItemBtnSG.MouseButton1Click:Connect(function()
    dropdownOverlay.Visible = true
    dropdownScroll.Visible = true
end)

local scannedInventory = {}
local selectedItem = nil
local mmPlanSG, mmRecipientIdSG, amountToSendSG = nil, nil, 0

local function updateDropdown()
    for _, c in ipairs(dropdownScroll:GetChildren()) do if c:IsA("TextButton") then c:Destroy() end end
    for i, item in ipairs(scannedInventory) do
        local btn = Instance.new("TextButton", dropdownScroll)
        btn.Size = UDim2.new(1, 0, 0, 24); btn.BackgroundColor3 = (i % 2 == 0) and C.panel or C.bg
        btn.BorderSizePixel = 0; btn.Text = string.format(" %s (x%d)", item.name, item.count)
        btn.TextColor3 = C.text; btn.TextSize = 11; btn.Font = Enum.Font.Gotham; btn.ZIndex = 51
        btn.TextXAlignment = Enum.TextXAlignment.Left
        btn.MouseButton1Click:Connect(function()
            selectedItem = item
            selectItemBtnSG.Text = item.name .. " (x" .. item.count .. ")"
            dropdownOverlay.Visible = false
            dropdownScroll.Visible = false
            setStatus(statusSG, "Success", "Selected: " .. item.name)
        end)
    end
    dropdownScroll.CanvasSize = UDim2.new(0, 0, 0, #scannedInventory * 24)
end

local lineCountSG = 0
local function planLogSG(msg, color)
    lineCountSG = lineCountSG + 1
    local line = Instance.new("TextLabel", planScrollSG)
    line.BackgroundTransparency = 1; line.Size = UDim2.new(1,-4,0,12)
    line.Text = msg; line.TextColor3 = color or C.text; line.TextSize = 10
    line.Font = Enum.Font.GothamMedium; line.TextXAlignment = Enum.TextXAlignment.Left
    line.LayoutOrder = lineCountSG
end
local function clearPlanSG()
    for _, c in ipairs(planScrollSG:GetChildren()) do if c:IsA("TextLabel") then c:Destroy() end end
    lineCountSG = 0
end
local function setConfirmSG(enabled)
    sendBtnSG.Active = enabled
    sendBtnSG.BackgroundColor3 = enabled and Color3.fromRGB(35,55,95) or Color3.fromRGB(20,20,30)
    sendBtnSG.TextColor3 = enabled and C.text or C.muted
end

scanBtnSG.MouseButton1Click:Connect(function()
    scannedInventory = scanInventorySeedsGears()
    selectedItem = nil; selectItemBtnSG.Text = "Select Item..."
    updateDropdown()
    setStatus(statusSG, "Success", "Scan Complete (" .. #scannedInventory .. " items)")
end)

allBtnSG.MouseButton1Click:Connect(function()
    if not selectedItem then setStatus(statusSG, "Error", "Select item first!"); return end
    qtyInputSG.Text = tostring(selectedItem.count)
end)

prevBtnSG.MouseButton1Click:Connect(function()
    local username = recipInputSG.Text:match("^%s*(.-)%s*$")
    local reqQty = tonumber(qtyInputSG.Text) or 0
    if not selectedItem then setStatus(statusSG, "Error", "Select item"); return end
    if username == "" then setStatus(statusSG, "Error", "Enter recipient"); return end
    if reqQty <= 0 or reqQty > selectedItem.count then setStatus(statusSG, "Error", "Invalid quantity"); return end

    prevBtnSG.Active = false; setStatus(statusSG, "Planning", "Resolving...")
    setConfirmSG(false); clearPlanSG(); mmRecipientIdSG = nil

    task.spawn(function()
        local ok, rid = pcall(function() return Players:GetUserIdFromNameAsync(username) end)
        if not ok or not rid then
            setStatus(statusSG, "Error", "User not found")
            prevBtnSG.Active = true; return
        end
        
        mmRecipientIdSG = rid; amountToSendSG = reqQty
        mmPlanSG = SharedMailSender.CreatePlan({{
            id = selectedItem.name,
            name = selectedItem.name,
            category = selectedItem.category,
            count = amountToSendSG,
            mainCategory = selectedItem.mainCategory,
            isSeed = selectedItem.isSeed
        }})
        
        summaryTxtSG.Text = string.format("Inventory Summary\n• Item: %s\n• Category: %s\n• Qty: %d", selectedItem.name, selectedItem.category, amountToSendSG)
        
        planLogSG(string.format("To: %s (ID: %s)", username, tostring(rid)), C.blue)
        planLogSG(string.format("Item: %s", selectedItem.name), C.gold)
        planLogSG(string.format("Category: %s", selectedItem.category), C.muted)
        planLogSG(string.format("Quantity: %d", amountToSendSG), C.text)
        
        setConfirmSG(true); prevBtnSG.Active = true
        setStatus(statusSG, "Ready", "Plan ready. Confirm to send.")
        
        viewModeSG = "Summary"
        summaryTxtSG.Visible = true
        planScrollSG.Visible = false
        toggleBtnSG.Text = "🔄 Show Details"
    end)
end)

sendBtnSG.MouseButton1Click:Connect(function()
    if not mmRecipientIdSG or not selectedItem or amountToSendSG <= 0 then return end
    setConfirmSG(false); prevBtnSG.Active = false
    
    local targetUsername = recipInputSG.Text
    
    task.spawn(function()
        print("ManualMail: Pre-send inventory snapshot")
        local config = AutoMailConfigManager.Load()
        local preGears = scanInventorySeedsGears()
        local preGearCounts = {}
        for _, g in ipairs(preGears) do preGearCounts[g.name] = g.count end

        local success, totalSent, totalVal, sentItems, err = SharedMailSender.ExecutePlan(mmRecipientIdSG, mmPlanSG, function(state, ...)
            if state == "Sending" then
                setStatus(statusSG, "Sending", "Sending payload...")
            elseif state == "Error" then
                local e = ...
                setStatus(statusSG, "Error", "Failed: " .. tostring(e):sub(1,20))
            end
        end)
        
        print("ManualMail: Post-send inventory snapshot")
        local postGears = scanInventorySeedsGears()
        local postGearCounts = {}
        for _, g in ipairs(postGears) do postGearCounts[g.name] = g.count end
        
        local attemptedCount = amountToSendSG
        local itemName = selectedItem.name
        
        local preCount = preGearCounts[itemName] or 0
        local postCount = postGearCounts[itemName] or 0
        local actualSentCount = preCount - postCount
        if actualSentCount < 0 then actualSentCount = 0 end
        if actualSentCount > attemptedCount then actualSentCount = attemptedCount end
        
        local failedCount = attemptedCount - actualSentCount

        print(string.format("ManualMail: Successfully sent items (%d)", actualSentCount))
        print(string.format("ManualMail: Failed items (%d)", failedCount))

        if config and config.Webhook and type(config.Webhook.Url) == "string" and config.Webhook.Url ~= "" then
            local overallStatus = "Success"
            if actualSentCount == 0 then
                overallStatus = "Failed"
            elseif failedCount > 0 then
                overallStatus = "Partial Success"
            end

            WebhookManager.SendManualWebhook(config, {
                sender = lp.Name,
                recipient = targetUsername,
                requested = attemptedCount,
                successCount = actualSentCount,
                failedCount = failedCount,
                fruitValue = 0,
                status = overallStatus
            })
        end

        if success then
            setStatus(statusSG, "Success", string.format("Sent %d %s", actualSentCount, selectedItem.name))
            clearPlanSG()
        end
        
        scannedInventory = {}; selectedItem = nil; selectItemBtnSG.Text = "Select Item..."
        updateDropdown(); prevBtnSG.Active = true
    end)
end)

-- ============================================================================
-- STATE SYNCHRONIZATION MATRIX
-- ============================================================================
local function synchronizeUsernameInputs(text)
    if recipInputF.Text ~= text then recipInputF.Text = text end
    if recipInputSG.Text ~= text then recipInputSG.Text = text end
    updateAvatarPreviews(text, {avatarImgF, avatarImgSG}) 
end

recipInputF:GetPropertyChangedSignal("Text"):Connect(function() synchronizeUsernameInputs(recipInputF.Text) end)
recipInputSG:GetPropertyChangedSignal("Text"):Connect(function() synchronizeUsernameInputs(recipInputSG.Text) end)
recipInputF.FocusLost:Connect(function() synchronizeUsernameInputs(recipInputF.Text) end)
recipInputSG.FocusLost:Connect(function() synchronizeUsernameInputs(recipInputSG.Text) end)

print("[Standalone Mailer v10.7] Compact Unified System Panel & Auto Mailer Initialized Successfully.")