local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- Attempt to load modules
local FruitVisualizerController = require(player:WaitForChild("PlayerScripts"):WaitForChild("Controllers"):WaitForChild("FruitVisualizerController"))
local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))

-- 1. Find Plot
local myPlot
for _, plot in ipairs(workspace.Gardens:GetChildren()) do
    if plot:GetAttribute("OwnerUserId") == player.UserId then
        myPlot = plot
        break
    end
end

if not myPlot then
    warn("Couldn't find your plot!")
    return
end

-- 2. Variables
local SHOVEL_NAME = "Shovel"
local SHOVEL_INTERVAL = 0.65
local LOOP_INTERVAL = 2 
local isAutoFarming = false

-- State Locks to prevent overlapping scans
local isHarvesting = false
local isShoveling = false

local harvestPlants = {}
local keptPlants = {}
local shovelPlants = {}
local allPlants = {}

-- 3. Build UI
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "AdminPanel"
screenGui.ResetOnSpawn = false
screenGui.Parent = playerGui

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(220, 215)
frame.Position = UDim2.fromScale(0.02, 0.25)
frame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
frame.BorderSizePixel = 0
frame.Active = true
frame.Draggable = true
frame.Parent = screenGui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

local titleBar = Instance.new("Frame")
titleBar.Size = UDim2.new(1, 0, 0, 30)
titleBar.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
titleBar.BorderSizePixel = 0
titleBar.Parent = frame
Instance.new("UICorner", titleBar).CornerRadius = UDim.new(0, 8)

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Size = UDim2.new(1, -60, 1, 0)
title.Position = UDim2.fromOffset(8, 0)
title.Font = Enum.Font.GothamBold
title.Text = "Auto-Farm v24"
title.TextSize = 14
title.TextXAlignment = Enum.TextXAlignment.Left
title.TextColor3 = Color3.new(1, 1, 1)
title.Parent = titleBar

local minimize = Instance.new("TextButton")
minimize.Size = UDim2.fromOffset(25, 25)
minimize.Position = UDim2.new(1, -55, 0, 2)
minimize.BackgroundColor3 = Color3.fromRGB(90, 90, 90)
minimize.Text = "-"
minimize.Font = Enum.Font.GothamBold
minimize.TextColor3 = Color3.new(1, 1, 1)
minimize.TextSize = 18
minimize.Parent = titleBar
Instance.new("UICorner", minimize).CornerRadius = UDim.new(0, 4)

local close = Instance.new("TextButton")
close.Size = UDim2.fromOffset(25, 25)
close.Position = UDim2.new(1, -28, 0, 2)
close.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
close.Text = "X"
close.Font = Enum.Font.GothamBold
close.TextColor3 = Color3.new(1, 1, 1)
close.TextSize = 14
close.Parent = titleBar
Instance.new("UICorner", close).CornerRadius = UDim.new(0, 4)

local content = Instance.new("Frame")
content.BackgroundTransparency = 1
content.Position = UDim2.fromOffset(0, 30)
content.Size = UDim2.new(1, 0, 1, -30)
content.Parent = frame

local autoToggleBtn = Instance.new("TextButton")
autoToggleBtn.Size = UDim2.new(1, -20, 0, 35)
autoToggleBtn.Position = UDim2.new(0, 10, 0, 10)
autoToggleBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
autoToggleBtn.Text = "Auto-Farm: OFF"
autoToggleBtn.Font = Enum.Font.GothamBold
autoToggleBtn.TextSize = 14
autoToggleBtn.TextColor3 = Color3.new(1, 1, 1)
autoToggleBtn.Parent = content
Instance.new("UICorner", autoToggleBtn).CornerRadius = UDim.new(0, 6)

local function createStatusLabel(yPos)
    local lbl = Instance.new("TextLabel")
    lbl.Size = UDim2.new(1, -20, 0, 20)
    lbl.Position = UDim2.new(0, 12, 0, yPos)
    lbl.BackgroundTransparency = 1
    lbl.Font = Enum.Font.GothamMedium
    lbl.TextSize = 13
    lbl.TextColor3 = Color3.fromRGB(220, 220, 220)
    lbl.TextXAlignment = Enum.TextXAlignment.Left
    lbl.Parent = content
    return lbl
end

-- Individual UI Labels
local stateLbl = createStatusLabel(55)
local harvestLbl = createStatusLabel(80)
local shovelLbl = createStatusLabel(105)
local keptLbl = createStatusLabel(130)

stateLbl.Text = "Status: Idle"
harvestLbl.Text = "🌿 Harvest State: 0"
shovelLbl.Text = "🪓 Shovel State: 0"
keptLbl.Text = "🛡️ Kept Plant: 0"

local function setState(text)
    stateLbl.Text = "Status: " .. text
end

local function updateCounts()
    harvestLbl.Text = "🌿 Harvest State: " .. #harvestPlants
    shovelLbl.Text = "🪓 Shovel State: " .. #shovelPlants
    keptLbl.Text = "🛡️ Kept Plant: " .. #keptPlants
end

-- 4. Core Logic Functions
local function scanPlants()
    setState("Scanning plot...")
    table.clear(harvestPlants)
    table.clear(keptPlants)
    table.clear(shovelPlants)
    table.clear(allPlants)

    for _, plant in ipairs(myPlot.Plants:GetChildren()) do
        local fruits = plant:FindFirstChild("Fruits")

        if fruits then
            local plantId = plant:GetAttribute("PlantId") or plant.Name
            if plantId then
                for _, fruit in ipairs(fruits:GetChildren()) do
                    local name = fruit:GetAttribute("CorePartName")
                    local id = fruit:GetAttribute("FruitId")

                    if not id or not name then continue end

                    local mutation = fruit:GetAttribute("Mutation")
                    if not mutation or mutation == "" then
                        mutation = "None"
                    end

                    local weight = FruitVisualizerController:CalculateFruitWeight(fruit)
                    if not weight and FruitVisualizerController.CalculatePlantWeight then
                        weight = FruitVisualizerController:CalculatePlantWeight(fruit)
                    end
                    weight = tonumber(weight) or 0

                    local fruitData = {
                        PlantId = plantId,
                        Id = id,
                        Name = name,
                        Weight = weight,
                        Mutation = mutation,
                        Instance = fruit,
                    }

                    if weight < 45 then
                        table.insert(harvestPlants, fruitData)
                    elseif weight < 60 then
                        table.insert(shovelPlants, fruitData)
                    else
                        table.insert(keptPlants, fruitData)
                    end
                end
            end
        end
    end

    updateCounts()
end

local function harvestFruit(fruitInstance)
    if not fruitInstance then return end
    local plantId = fruitInstance:GetAttribute("PlantId")
    if not plantId then return end
    local fruitId = fruitInstance:GetAttribute("FruitId")

    pcall(function()
        Networking.Garden.CollectFruit:Fire(plantId, fruitId or "")
    end)
end

local function startHarvest()
    local total = #harvestPlants
    if total == 0 then return end
    
    isHarvesting = true -- Lock state
    local processed = 0
    
    for _, fruit in ipairs(harvestPlants) do
        -- Safety check: Break loop if user turns off Auto-Farm
        if not isAutoFarming then break end 
        
        if fruit.Instance and fruit.Instance:IsDescendantOf(workspace) then
            processed += 1
            
            -- Update specific state label visually
            harvestLbl.Text = ("🌿 Harvest State: Active (%d/%d)"):format(processed, total)
            setState("Harvesting...")
            
            harvestFruit(fruit.Instance)
            task.wait(0.1)
        end
    end
    
    isHarvesting = false -- Unlock state
end

local function equipTool(toolName)
    local character = player.Character
    if not character then return false end
    local humanoid = character:FindFirstChild("Humanoid")
    if not humanoid then return false end

    local tool = character:FindFirstChild(toolName) or player.Backpack:FindFirstChild(toolName)
    if not tool then return false end

    humanoid:EquipTool(tool)
    return true
end

local function shovelFruit(fruitInstance)
    if not fruitInstance then return end
    local plantId = fruitInstance:GetAttribute("PlantId")
    if not plantId then return end
    local fruitId = fruitInstance:GetAttribute("FruitId")
    if not fruitId then return end

    local character = player.Character
    if not character then return end

    local equippedTool = character:FindFirstChildOfClass("Tool")
    if not equippedTool then return end

    local shovelType = equippedTool:GetAttribute("Shovel")

    pcall(function()
        Networking.Shovel.UseShovel:Fire(
            plantId,
            fruitId,
            shovelType,
            equippedTool
        )
    end)
end

local function startShovel(toolName)
    if #shovelPlants == 0 then return end

    if not equipTool(toolName) then
        setState("Failed: Shovel missing!")
        warn("Failed to equip shovel!")
        return
    end

    isShoveling = true -- Lock state
    local total = #shovelPlants
    local processed = 0
    local nextAllowedTime = os.clock()

    for _, fruit in ipairs(shovelPlants) do
        -- Safety check: Break loop if user turns off Auto-Farm
        if not isAutoFarming then break end 
        
        if fruit.Instance and fruit.Instance:IsDescendantOf(workspace) then
            local now = os.clock()
            if now < nextAllowedTime then
                task.wait(nextAllowedTime - now)
            end

            nextAllowedTime = os.clock() + SHOVEL_INTERVAL

            processed += 1
            
            -- Update specific state label visually
            shovelLbl.Text = ("🪓 Shovel State: Active (%d/%d)"):format(processed, total)
            setState("Shoveling...")
            
            shovelFruit(fruit.Instance)
        end
    end
    
    isShoveling = false -- Unlock state
end

-- 5. Thread-Safe Auto-Loop Execution
task.spawn(function()
    while true do
        if isAutoFarming then
            -- ONLY scan and trigger if previous tasks have finished
            if not isHarvesting and not isShoveling then
                scanPlants()
                
                -- Trigger Harvest in a separate thread
                if #harvestPlants > 0 and isAutoFarming then
                    task.spawn(function()
                        startHarvest()
                    end)
                end
                
                -- Wait 1 second before starting Shovel, as requested
                if isAutoFarming then
                    task.wait(1) 
                end
                
                -- Trigger Shovel in a separate thread
                if #shovelPlants > 0 and isAutoFarming then
                    task.spawn(function()
                        startShovel(SHOVEL_NAME)
                    end)
                end
                
                if isAutoFarming then
                    setState("Processes running in background...")
                end
            else
                -- If it takes longer than LOOP_INTERVAL, we just wait here
                setState("Yielding: Tasks still running...")
            end
        end
        task.wait(LOOP_INTERVAL)
    end
end)

-- 6. Wiring the UI Button
autoToggleBtn.MouseButton1Click:Connect(function()
    isAutoFarming = not isAutoFarming
    if isAutoFarming then
        autoToggleBtn.Text = "Auto-Farm: ON"
        autoToggleBtn.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
        setState("Starting routine...")
    else
        autoToggleBtn.Text = "Auto-Farm: OFF"
        autoToggleBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
        setState("Idle (Paused)")
    end
end)

-- Minimize/Close Logic
local minimized = false
local expandedSize = frame.Size

minimize.MouseButton1Click:Connect(function()
    minimized = not minimized
    if minimized then
        content.Visible = false
        frame.Size = UDim2.fromOffset(expandedSize.X.Offset, 30)
        minimize.Text = "+"
    else
        content.Visible = true
        frame.Size = expandedSize
        minimize.Text = "-"
    end
end)

close.MouseButton1Click:Connect(function()
    isAutoFarming = false 
    screenGui:Destroy()
end)
