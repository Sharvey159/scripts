-- ============================================================================
-- Mutant Harvester v5 (Floating Icon Version)
-- ============================================================================
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

if playerGui:FindFirstChild("MutantHarvesterIconUI") then
    playerGui.MutantHarvesterIconUI:Destroy()
end

-- ============================================================================
-- CENTRALIZED FAB STACK MANAGER SETUP
-- ============================================================================
local FABManager = _G.FABManager
if not FABManager then
    FABManager = {
        Buttons = {},
        PriorityMap = {
            SharveyManager = 1,
            FruitDropper = 2,
            AutoMail = 3,
            FruitSummary = 4,
            HarvestFruits = 5
        }
    }
    _G.FABManager = FABManager
    
    function FABManager.Update()
        local TweenSvc = game:GetService("TweenService")
        -- Self-heal: Clean up destroyed buttons
        local i = 1
        while i <= #FABManager.Buttons do
            local btnData = FABManager.Buttons[i]
            if not btnData.Button or not btnData.Button.Parent then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, i)
            else
                i = i + 1
            end
        end

        local activeButtons = {}
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Visible then
                table.insert(activeButtons, btnData)
            end
        end
        
        local count = #activeButtons
        if count == 0 then return end
        
        local buttonSize = 48
        local spacing = 12
        local totalHeight = (count * buttonSize) + ((count - 1) * spacing)
        local startYOffset = -totalHeight / 2
        
        for idx, btnData in ipairs(activeButtons) do
            local targetYOffset = startYOffset + ((idx - 1) * (buttonSize + spacing)) + (buttonSize / 2)
            local targetPos = UDim2.new(1, -16, 0.5, targetYOffset)
            local targetShadowPos = UDim2.new(1, -14, 0.5, targetYOffset + 2)
            
            local tInfo = TweenInfo.new(0.25, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
            
            if btnData.Button and btnData.Button.Parent then
                TweenSvc:Create(btnData.Button, tInfo, {Position = targetPos}):Play()
            end
            if btnData.Shadow and btnData.Shadow.Parent then
                TweenSvc:Create(btnData.Shadow, tInfo, {Position = targetShadowPos}):Play()
            end
        end
    end
    
    function FABManager.Register(id, button, shadow, onClick)
        FABManager.Unregister(id)
        
        local btnData = {
            Id = id,
            Button = button,
            Shadow = shadow,
            Visible = true,
            OnClick = onClick
        }
        
        table.insert(FABManager.Buttons, btnData)
        
        table.sort(FABManager.Buttons, function(a, b)
            local pA = FABManager.PriorityMap[a.Id] or 99
            local pB = FABManager.PriorityMap[b.Id] or 99
            return pA < pB
        end)
        
        if onClick then
            btnData.Connection = button.MouseButton1Click:Connect(onClick)
        end
        
        FABManager.Update()
        return btnData
    end
    
    function FABManager.Unregister(id)
        for idx, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                if btnData.Connection then btnData.Connection:Disconnect() end
                table.remove(FABManager.Buttons, idx)
                FABManager.Update()
                break
            end
        end
    end
    
    function FABManager.SetVisible(id, visible)
        for _, btnData in ipairs(FABManager.Buttons) do
            if btnData.Id == id then
                btnData.Visible = visible
                if btnData.Button and btnData.Button.Parent then
                    btnData.Button.Visible = visible
                end
                if btnData.Shadow and btnData.Shadow.Parent then
                    btnData.Shadow.Visible = visible
                end
                FABManager.Update()
                break
            end
        end
    end
end

-- ============================================================================
-- ALLOWED FRUITS WHITELIST
-- ============================================================================
local AllowedToProcess = {
	["Moon Bloom"] = true,
}

local function IsFruitAllowed(fruitName)
	if not fruitName then return false end
	return AllowedToProcess[fruitName] == true
end

local FruitVisualizerController = require(player:WaitForChild("PlayerScripts"):WaitForChild("Controllers"):WaitForChild("FruitVisualizerController"))
local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))

local myPlot
for _, plot in ipairs(workspace.Gardens:GetChildren()) do
    if plot:GetAttribute("OwnerUserId") == player.UserId then
        myPlot = plot
        break
    end
end

if not myPlot then
    warn("Couldn't find your plot!")
    return
end

-- UI Setup
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "MutantHarvesterIconUI"
screenGui.ResetOnSpawn = false
screenGui.Parent = playerGui

-- Shadow Frame for Drop Shadow effect
local shadow = Instance.new("Frame")
shadow.Size = UDim2.fromOffset(48, 48)
shadow.AnchorPoint = Vector2.new(1, 0.5) -- Vertically center stack anchor
shadow.BackgroundColor3 = Color3.new(0, 0, 0)
shadow.BackgroundTransparency = 0.7
shadow.BorderSizePixel = 0
shadow.Parent = screenGui
Instance.new("UICorner", shadow).CornerRadius = UDim.new(0, 12)

-- Main Button
local harvestBtn = Instance.new("TextButton")
harvestBtn.Size = UDim2.fromOffset(48, 48)
harvestBtn.AnchorPoint = Vector2.new(1, 0.5) -- Vertically center stack anchor
harvestBtn.BackgroundColor3 = Color3.fromHex("#22C55E") -- Green
harvestBtn.BackgroundTransparency = 0.15
harvestBtn.BorderSizePixel = 0
harvestBtn.Text = "🌾"
harvestBtn.TextSize = 24
harvestBtn.Font = Enum.Font.Gotham
harvestBtn.Parent = screenGui
Instance.new("UICorner", harvestBtn).CornerRadius = UDim.new(0, 12)

---------------------------------------------------
-- Animations
---------------------------------------------------
local tweenInfo = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local baseColor = Color3.fromHex("#22C55E")
local hoverColor = Color3.fromHex("#4ADE80") -- Brighter green

harvestBtn.MouseEnter:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(52, 52), BackgroundColor3 = hoverColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

harvestBtn.MouseLeave:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(48, 48), BackgroundColor3 = baseColor}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(48, 48)}):Play()
end)

harvestBtn.MouseButton1Down:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(44, 44)}):Play()
end)

harvestBtn.MouseButton1Up:Connect(function()
	TweenService:Create(harvestBtn, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
	TweenService:Create(shadow, tweenInfo, {Size = UDim2.fromOffset(52, 52)}):Play()
end)

---------------------------------------------------
-- Core Harvesting Logic
---------------------------------------------------
local isHarvesting = false

local function harvestMutants()
    if isHarvesting then return end
    isHarvesting = true
    
    local targets = {}
    print("Harvester: Scanning for mutants...")
    
    -- Scan Phase
    for _, plant in ipairs(myPlot.Plants:GetChildren()) do
        local fruits = plant:FindFirstChild("Fruits")
        if fruits then
            local plantId = plant:GetAttribute("PlantId") or plant.Name
            if plantId then
                for _, fruit in ipairs(fruits:GetChildren()) do
                    local name = fruit:GetAttribute("CorePartName")
                    
                    if not IsFruitAllowed(name) then continue end
                    
                    local id = fruit:GetAttribute("FruitId")
                    if not id or not name then continue end

                    local mutation = fruit:GetAttribute("Mutation")
                    if not mutation or mutation == "" then mutation = "None" end

                    local weight = FruitVisualizerController:CalculateFruitWeight(fruit)
                    if not weight and FruitVisualizerController.CalculatePlantWeight then
                        weight = FruitVisualizerController:CalculatePlantWeight(fruit)
                    end
                    weight = tonumber(weight) or 0

                    if mutation ~= "None" and weight > 30 then
                        table.insert(targets, {PlantId = plantId, FruitId = id, Instance = fruit})
                    end
                end
            end
        end
    end

    -- Harvest Phase
    local total = #targets
    if total == 0 then
        print("Harvester: No valid mutants found.")
        task.wait(2)
        isHarvesting = false
        return
    end

    local processed = 0
    for _, target in ipairs(targets) do
        if target.Instance and target.Instance:IsDescendantOf(workspace) then
            processed += 1
            print(("Harvester: Harvesting... %d/%d"):format(processed, total))
            
            pcall(function()
                Networking.Garden.CollectFruit:Fire(target.PlantId, target.FruitId)
            end)
            
            task.wait(0.1) 
        end
    end

    print("Harvester: Finished! Harvested: " .. processed)
    task.wait(2)
    isHarvesting = false
end

local function onHarvestClick()
    task.spawn(harvestMutants)
end

-- Register natively into the central stack positioning system
FABManager.Register("HarvestFruits", harvestBtn, shadow, onHarvestClick)