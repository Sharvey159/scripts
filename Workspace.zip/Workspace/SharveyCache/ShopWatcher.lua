-- [[ Stock Values Notifier v17.0 (Verified Auto-Buy Edition) ]] --

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local CONFIG_FILE = "StockNotifierConfig.lua"
local DEFAULT_WEBHOOK = "https://discord.com/api/webhooks/1526045938206900335/ykZb_vJTmf4O2FT537kpWHKwKOH3_7fouBkFS6OlqAtx09fjZtKT8mfNbBfDumQu5F9p"
local DEFAULT_MENTION = "<@604609802835853333>"

-- Global Summary Webhook Configuration
local GLOBAL_WEBHOOK_URL = "https://discord.com/api/webhooks/1527570165535997994/qqMgyo2h-xh4lKHopQj2iabFmC5_qnvLVHmU6RtVjcIj_vpyQ-e9XRAh95spBOUGUAxs"

local INVENTORY_CACHE_FILE = "ShopInventoryCache.json"
local GLOBAL_WEBHOOK_CACHE_FILE = "ShopGlobalSummaryWebhookCache.json"

-- Allowed Stock Notifiers
local ALLOWED_NOTIFIERS = {
	["Store_acc51"] = true,
	["SharvxPLayz"] = true,
}

-- Debug Configuration
local DEBUG = {
	Enabled = true, -- Set to true to receive verification webhooks
	ForceCarrot = true, -- Overrides config to force Carrot monitoring and auto-buying
}

-- Auto-Buy Configuration (Verified System)
local AUTO_BUY = {
	Enabled = true,
	Delay = 0.2, -- Delay between individual purchase packets
	
	VerificationDelay = 0.35, -- Wait time before reading stock again
	MaxVerificationRetries = 5, -- Max retries if stock isn't fully depleted
}

-- Safely wait for the target folders to load in ReplicatedStorage
local stockValues = ReplicatedStorage:WaitForChild("StockValues")
local gearShopItems = stockValues:WaitForChild("GearShop"):WaitForChild("Items")
local seedShopItems = stockValues:WaitForChild("SeedShop"):WaitForChild("Items")

---------------------------------------------------
-- Networking & Caching Setup
---------------------------------------------------

local Networking = nil
local PurchaseSeed = nil
local PurchaseGear = nil

-- Attempt to require the module safely once during initialization
local requireSuccess, requireError = pcall(function()
	return require(game:GetService("ReplicatedStorage").SharedModules.Networking)
end)

if requireSuccess and requireError then
	Networking = requireError
	
	-- Cache SeedShop Packet
	if Networking.SeedShop and Networking.SeedShop.PurchaseSeed then
		PurchaseSeed = Networking.SeedShop.PurchaseSeed
		print("[AutoBuy Debug] Successfully cached 'PurchaseSeed' packet.")
	else
		warn("[AutoBuy Debug] Warning: 'Networking.SeedShop.PurchaseSeed' packet could not be found.")
	end
	
	-- Cache GearShop Packet
	if Networking.GearShop and Networking.GearShop.PurchaseGear then
		PurchaseGear = Networking.GearShop.PurchaseGear
		print("[AutoBuy Debug] Successfully cached 'PurchaseGear' packet.")
	else
		warn("[AutoBuy Debug] Warning: 'Networking.GearShop.PurchaseGear' packet could not be found.")
	end
else
	warn("[AutoBuy Debug] Warning: Networking module could not be required! Error: " .. tostring(requireError))
end

---------------------------------------------------
-- Configuration Management
---------------------------------------------------

local Config = nil

-- Serializes the table back into the exact requested Lua string format
local function SaveConfig(configData)
	local lines = {
		"return {",
		string.format('\tWebhook = "%s",', configData.Webhook or ""),
		string.format('\tMention = "%s",\n', configData.Mention or ""),
	}

	for _, shop in ipairs({"SeedShop", "GearShop"}) do
		if configData[shop] then
			table.insert(lines, string.format('\t%s = {', shop))
			
			local sortedItems = {}
			for item, _ in pairs(configData[shop]) do
				table.insert(sortedItems, item)
			end
			table.sort(sortedItems)

			for _, item in ipairs(sortedItems) do
				local toggle = configData[shop][item]
				table.insert(lines, string.format('\t\t["%s"] = %s,', item, tostring(toggle)))
			end
			table.insert(lines, "\t},\n")
		end
	end

	table.insert(lines, "}")
	
	if writefile then
		writefile(CONFIG_FILE, table.concat(lines, "\n"))
	end
end

-- Loads the Lua config file using loadstring
local function LoadConfig()
	if isfile and isfile(CONFIG_FILE) then
		local success, result = pcall(function()
			local content = readfile(CONFIG_FILE)
			local func = loadstring(content)
			if func then return func() end
		end)
		if success and type(result) == "table" then
			return result
		end
	end
	return nil
end

Config = LoadConfig()
local configModified = false

if not Config then
	Config = {
		Webhook = DEFAULT_WEBHOOK,
		Mention = DEFAULT_MENTION,
		SeedShop = {},
		GearShop = {}
	}
	configModified = true
else
	if Config.Mention == nil then
		Config.Mention = DEFAULT_MENTION
		configModified = true
	end
end

local function SyncConfigWithShop(shopName, folder)
	if type(Config[shopName]) ~= "table" then
		Config[shopName] = {}
		configModified = true
	end

	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			if Config[shopName][item.Name] == nil then
				Config[shopName][item.Name] = true
				configModified = true
			end
		end
	end
end

SyncConfigWithShop("GearShop", gearShopItems)
SyncConfigWithShop("SeedShop", seedShopItems)

if configModified then
	SaveConfig(Config)
end

---------------------------------------------------
-- Global Helper Functions
---------------------------------------------------

local function IsItemMonitored(shopName, itemName)
	if DEBUG.ForceCarrot and shopName == "SeedShop" and itemName == "Carrot" then
		return true
	end
	return Config[shopName] and Config[shopName][itemName] == true
end

local function ShouldAutoBuy(shopName, itemName)
	if DEBUG.ForceCarrot and shopName == "SeedShop" and itemName == "Carrot" then
		return true
	end
	return AUTO_BUY.Enabled and Config[shopName] and Config[shopName][itemName] == true
end

---------------------------------------------------
-- Caching & Inventory Snapshots
---------------------------------------------------

local function LoadInventoryCache()
	if isfile and isfile(INVENTORY_CACHE_FILE) then
		local success, data = pcall(function()
			return HttpService:JSONDecode(readfile(INVENTORY_CACHE_FILE))
		end)
		if success and type(data) == "table" then return data end
	end
	return {}
end

local function SaveInventoryCache(data)
	if writefile then
		writefile(INVENTORY_CACHE_FILE, HttpService:JSONEncode(data))
	end
end

local function LoadGlobalWebhookCache()
	if isfile and isfile(GLOBAL_WEBHOOK_CACHE_FILE) then
		local success, data = pcall(function()
			return HttpService:JSONDecode(readfile(GLOBAL_WEBHOOK_CACHE_FILE))
		end)
		if success and type(data) == "table" then return data end
	end
	return {}
end

local function SaveGlobalWebhookCache(data)
	if writefile then
		writefile(GLOBAL_WEBHOOK_CACHE_FILE, HttpService:JSONEncode(data))
	end
end

local function GetShecklesValue()
	local leaderstats = Players.LocalPlayer:FindFirstChild("leaderstats")
	local sheckles = leaderstats and (leaderstats:FindFirstChild("Sheckles") or leaderstats:FindFirstChild("Shekels"))
	if sheckles and (sheckles:IsA("ValueBase") or sheckles.ClassName:match("Value$")) then
		return sheckles.Value
	end
	return Players.LocalPlayer:GetAttribute("Sheckles") or Players.LocalPlayer:GetAttribute("Shekels") or 0
end

local function FormatCompact(val)
	val = tonumber(val) or 0
	if val >= 1e12 then
		local formatted = string.format("%.1f", val / 1e12)
		return (formatted:sub(-2) == ".0" and formatted:sub(1, -3) or formatted) .. "T"
	elseif val >= 1e9 then
		local formatted = string.format("%.1f", val / 1e9)
		return (formatted:sub(-2) == ".0" and formatted:sub(1, -3) or formatted) .. "B"
	elseif val >= 1e6 then
		local formatted = string.format("%.1f", val / 1e6)
		return (formatted:sub(-2) == ".0" and formatted:sub(1, -3) or formatted) .. "M"
	elseif val >= 1e3 then
		local formatted = string.format("%.1f", val / 1e3)
		return (formatted:sub(-2) == ".0" and formatted:sub(1, -3) or formatted) .. "K"
	else
		return tostring(val)
	end
end

local function BuildInventorySnapshot()
	local snapshot = {
		Seeds = {},
		Gears = {},
		Sheckles = GetShecklesValue()
	}

	if Config.SeedShop then
		for item, enabled in pairs(Config.SeedShop) do
			if enabled == true or (DEBUG.ForceCarrot and item == "Carrot") then snapshot.Seeds[item] = 0 end
		end
	end

	if Config.GearShop then
		for item, enabled in pairs(Config.GearShop) do
			if enabled == true then snapshot.Gears[item] = 0 end
		end
	end

	local backpack = Players.LocalPlayer:FindFirstChild("Backpack")
	if backpack then
		for _, tool in ipairs(backpack:GetChildren()) do
			if tool:IsA("Tool") then
				local name = tool.Name
				local count = tool:GetAttribute("Count") or 0
				if IsItemMonitored("SeedShop", name) then
					snapshot.Seeds[name] = (snapshot.Seeds[name] or 0) + count
				elseif IsItemMonitored("GearShop", name) then
					snapshot.Gears[name] = (snapshot.Gears[name] or 0) + count
				end
			end
		end
	end

	return snapshot
end

local function CompareSnapshots(snap1, snap2)
	if not snap1 or not snap2 then return false end
	if snap1.Sheckles ~= snap2.Sheckles then return false end

	for k, v in pairs(snap1.Seeds) do
		if snap2.Seeds[k] ~= v then return false end
	end
	for k, v in pairs(snap2.Seeds) do
		if snap1.Seeds[k] ~= v then return false end
	end

	for k, v in pairs(snap1.Gears) do
		if snap2.Gears[k] ~= v then return false end
	end
	for k, v in pairs(snap2.Gears) do
		if snap1.Gears[k] ~= v then return false end
	end

	return true
end

---------------------------------------------------
-- Global Summary Webhook
---------------------------------------------------

local function SendOrPatchGlobalSummaryWebhook(diskCache, changedItemsString)
	local playerName = Players.LocalPlayer.Name
	local currentTime = os.date("%Y-%m-%d %H:%M:%S")
	local isoTime = os.date("!%Y-%m-%dT%H:%M:%SZ")

	local cache = LoadGlobalWebhookCache()
	local messageId = cache.messageId

	local shecklesData = {}
	local totalSheckles = 0
	local accountsTracked = 0
	
	for accName, accData in pairs(diskCache) do
		accountsTracked = accountsTracked + 1
		local accSheckles = accData.Sheckles or 0
		totalSheckles = totalSheckles + accSheckles
		table.insert(shecklesData, { Name = accName, Sheckles = accSheckles })
	end
	
	table.sort(shecklesData, function(a, b) return a.Sheckles > b.Sheckles end)
	
	local shecklesLines = {}
	for _, acc in ipairs(shecklesData) do
		table.insert(shecklesLines, string.format("%s • %s", acc.Name, FormatCompact(acc.Sheckles)))
	end
	
	local shecklesBody = ""
	if #shecklesLines > 0 then
		shecklesBody = shecklesBody .. table.concat(shecklesLines, "\n") .. "\n\n"
	else
		shecklesBody = shecklesBody .. "No accounts tracked.\n\n"
	end
	
	shecklesBody = shecklesBody .. "Total Sheckles\n" .. FormatCompact(totalSheckles) .. "\n\n"
	shecklesBody = shecklesBody .. "Accounts Tracked\n" .. tostring(accountsTracked)

	local payload = {
		embeds = {
			{
				title = "💰 Global Shop Sheckles Summary",
				description = shecklesBody,
				color = 15844367, 
				timestamp = isoTime,
				footer = { text = string.format("Last Updated By: %s\nUpdated: %s\nChanged: %s", playerName, currentTime, changedItemsString) }
			}
		}
	}

	local jsonPayload = HttpService:JSONEncode(payload)

	if messageId then
		local response = request({
			Url = GLOBAL_WEBHOOK_URL .. "/messages/" .. messageId,
			Method = "PATCH",
			Headers = { ["Content-Type"] = "application/json" },
			Body = jsonPayload,
		})

		if response.StatusCode == 200 then
			return
		elseif response.StatusCode == 404 then
			messageId = nil 
		end
	end

	if not messageId then
		local response = request({
			Url = GLOBAL_WEBHOOK_URL .. "?wait=true",
			Method = "POST",
			Headers = { ["Content-Type"] = "application/json" },
			Body = jsonPayload,
		})

		if response.StatusCode == 200 or response.StatusCode == 201 then
			local success, responseData = pcall(function() return HttpService:JSONDecode(response.Body) end)
			if success and responseData.id then
				SaveGlobalWebhookCache({ messageId = responseData.id })
			end
		end
	end
end

---------------------------------------------------
-- Core Trigger & Diff Logic
---------------------------------------------------

local function CheckAndUpdateInventoryDashboard()
	local playerName = Players.LocalPlayer.Name
	local currentSnap = BuildInventorySnapshot()
	local diskCache = LoadInventoryCache()
	local savedSnap = diskCache[playerName]

	if not CompareSnapshots(currentSnap, savedSnap) then
		local changedItems = {}
		local function checkDiff(category)
			local curDict = currentSnap[category] or {}
			local oldDict = (savedSnap and savedSnap[category]) or {}
			local keys = {}
			
			for k in pairs(curDict) do keys[k] = true end
			for k in pairs(oldDict) do keys[k] = true end
			
			for k in pairs(keys) do
				local curV = curDict[k] or 0
				local oldV = oldDict[k] or 0
				if curV ~= oldV then
					local diff = curV - oldV
					local sign = diff > 0 and "+" or ""
					table.insert(changedItems, string.format("%s (%s%d)", k, sign, diff))
				end
			end
		end
		
		checkDiff("Seeds")
		checkDiff("Gears")
		
		local changedString = table.concat(changedItems, ", ")
		if changedString == "" then
			if currentSnap.Sheckles ~= (savedSnap and savedSnap.Sheckles) then
				changedString = "Sheckles Update"
			else
				changedString = "None"
			end
		end

		diskCache[playerName] = currentSnap
		SaveInventoryCache(diskCache)
		
		SendOrPatchGlobalSummaryWebhook(diskCache, changedString)
	end
end

---------------------------------------------------
-- Verified Auto-Buy Logic & Webhooks
---------------------------------------------------

local function SendDebugWebhook(itemName, initial, remaining, status, attempts, cycles)
	if not DEBUG.Enabled then return end
	
	local webhookUrl = Config.Webhook
	if type(webhookUrl) ~= "string" or webhookUrl == "" or not webhookUrl:match("^https://discord%.com/api/webhooks/") then return end

	task.spawn(function()
		local color = status == "VERIFIED" and 65280 or 16711680 -- Green for Success, Red for Fail
		
		local description = string.format("Item: %s\nInitial Stock: %d\nRemaining Stock: %d\nStatus: %s\nAttempts: %d\nVerification Cycles: %d", 
			itemName, initial, remaining, status, attempts, cycles)

		local payload = {
			embeds = {{
				title = "🛠️ Auto-Buy Verification Debug",
				description = description,
				color = color,
				timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
			}}
		}

		request({
			Url = webhookUrl,
			Method = "POST",
			Headers = { ["Content-Type"] = "application/json" },
			Body = HttpService:JSONEncode(payload),
		})
	end)
end

local activePurchases = {
	SeedShop = {},
	GearShop = {}
}

local function AutoBuyVerified(shopName, itemName, purchasePacket, itemsFolder)
	if activePurchases[shopName][itemName] then
		return
	end
	
	if not purchasePacket then
		warn(string.format("[AutoBuy Debug] %s - '%s' Triggered, but packet is missing!", shopName, itemName))
		return
	end

	local itemValueObj = itemsFolder:FindFirstChild(itemName)
	if not itemValueObj then return end

	local initialStock = itemValueObj.Value
	if initialStock <= 0 then return end

	activePurchases[shopName][itemName] = true

	print(string.format("\n[AutoBuy] %s detected.\n\nInitial Stock: %d\n", itemName, initialStock))

	local remainingStock = initialStock
	local totalAttempts = 0
	local retries = 0
	local isVerified = false

	while retries <= AUTO_BUY.MaxVerificationRetries do
		if retries > 0 then
			print(string.format("\nRetry #%d", retries))
		end

		local toBuy = remainingStock
		
		if toBuy == 1 then
			print(string.format("Sending %d purchase request...", toBuy))
		else
			print(string.format("Sending %d purchase requests...", toBuy))
		end

		for i = 1, toBuy do
			totalAttempts = totalAttempts + 1
			pcall(function() purchasePacket:Fire(itemName) end)
			if i < toBuy then task.wait(AUTO_BUY.Delay) end
		end

		print("Waiting for verification...")
		task.wait(AUTO_BUY.VerificationDelay)

		remainingStock = itemValueObj.Value
		
		if retries == 0 then
			print(string.format("\nRemaining Stock: %d", remainingStock))
		else
			print(string.format("Remaining Stock: %d", remainingStock))
		end

		if remainingStock == 0 then
			isVerified = true
			break
		end

		retries = retries + 1
	end

	local cycles = retries + 1

	if isVerified then
		print("\nPurchase VERIFIED.")
		SendDebugWebhook(itemName, initialStock, 0, "VERIFIED", totalAttempts, cycles)
	else
		print(string.format("\nFailed to fully purchase %s.\n\nInitial Stock: %d\nRemaining Stock: %d\nRetries: %d", itemName, initialStock, remainingStock, retries))
		SendDebugWebhook(itemName, initialStock, remainingStock, "FAILED", totalAttempts, cycles)
	end

	task.spawn(CheckAndUpdateInventoryDashboard)
	activePurchases[shopName][itemName] = nil
end

local function AutoBuySeed(seedName)
	AutoBuyVerified("SeedShop", seedName, PurchaseSeed, seedShopItems)
end

local function AutoBuyGear(gearName)
	AutoBuyVerified("GearShop", gearName, PurchaseGear, gearShopItems)
end

---------------------------------------------------
-- Standard Stock Webhook Notification
---------------------------------------------------

local function SendWebhookNotification(shopName, itemName, currentStock)
	if not ALLOWED_NOTIFIERS[Players.LocalPlayer.Name] then return end
	
	local webhookUrl = Config.Webhook
	if type(webhookUrl) ~= "string" or webhookUrl == "" or not webhookUrl:match("^https://discord%.com/api/webhooks/") then return end

	task.spawn(function()
		local isoTime = os.date("!%Y-%m-%dT%H:%M:%SZ")
		local currentTime = os.date("%Y-%m-%d %H:%M:%S")
		local description = string.format("**Shop:** %s\n**Item:** %s\n**Current Stock:** %d\n**Time Detected:** %s\n**JobId:** `%s`\n**PlaceId:** `%s`", shopName, itemName, currentStock, currentTime, game.JobId, tostring(game.PlaceId))

		local messageContent = string.format("%dx %s has appeared.", currentStock, itemName)
		if type(Config.Mention) == "string" and Config.Mention ~= "" then
			messageContent = string.format("%s %s", Config.Mention, messageContent)
		end

		local payload = {
			content = messageContent,
			embeds = {{
				title = "📦 Stock Restock Detected!",
				description = description,
				color = 5763719,
				timestamp = isoTime,
				footer = { text = string.format("Detected by %s", Players.LocalPlayer.Name) }
			}}
		}

		request({
			Url = webhookUrl,
			Method = "POST",
			Headers = { ["Content-Type"] = "application/json" },
			Body = HttpService:JSONEncode(payload),
		})
	end)
end

---------------------------------------------------
-- Startup Scan
---------------------------------------------------

local function PerformStartupScan(shopName, folder)
	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			if IsItemMonitored(shopName, item.Name) and item.Value >= 1 then
				print(string.format("[StockNotifier] Startup Scan Detected: %d %s in %s", item.Value, item.Name, shopName))
				SendWebhookNotification(shopName, item.Name, item.Value)
				
				if ShouldAutoBuy(shopName, item.Name) then
					if shopName == "SeedShop" then task.spawn(AutoBuySeed, item.Name)
					elseif shopName == "GearShop" then task.spawn(AutoBuyGear, item.Name) end
				end
			end
		end
	end
end

---------------------------------------------------
-- Polling Monitoring Logic
---------------------------------------------------

local stockState = { GearShop = {}, SeedShop = {} }

local function InitStockState(shopName, folder)
	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			stockState[shopName][item.Name] = item.Value
		end
	end
end

local function PollShop(shopName, folder)
	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			local newValue = item.Value
			local oldValue = stockState[shopName][item.Name] or 0
			
			if newValue ~= oldValue then
				stockState[shopName][item.Name] = newValue
				
				if newValue > oldValue and newValue >= 1 then
					print(string.format("[StockNotifier] Polling Detected Restock: %d %s in %s", newValue, item.Name, shopName))
					
					if IsItemMonitored(shopName, item.Name) then
						SendWebhookNotification(shopName, item.Name, newValue)
						
						if ShouldAutoBuy(shopName, item.Name) then
							if shopName == "SeedShop" then task.spawn(AutoBuySeed, item.Name)
							elseif shopName == "GearShop" then task.spawn(AutoBuyGear, item.Name) end
						end
					end
				end
			end
		end
	end
end

local isPolling = false
local function StartPolling()
	if isPolling then return end
	isPolling = true
	
	task.spawn(function()
		while true do
			task.wait(3)
			PollShop("GearShop", gearShopItems)
			PollShop("SeedShop", seedShopItems)
		end
	end)
end

---------------------------------------------------
-- Inventory Observer Setup
---------------------------------------------------

local function SetupInventoryListeners()
	local backpack = Players.LocalPlayer:WaitForChild("Backpack", 10)
	if not backpack then return end
	local activeConnections = {}
	
	local function trackTool(tool)
		if not tool:IsA("Tool") then return end
		if IsItemMonitored("SeedShop", tool.Name) or IsItemMonitored("GearShop", tool.Name) then
			if activeConnections[tool] then activeConnections[tool]:Disconnect() end
			activeConnections[tool] = tool:GetAttributeChangedSignal("Count"):Connect(CheckAndUpdateInventoryDashboard)
			CheckAndUpdateInventoryDashboard()
		end
	end
	
	backpack.ChildAdded:Connect(trackTool)
	backpack.ChildRemoved:Connect(function(tool)
		if activeConnections[tool] then
			activeConnections[tool]:Disconnect()
			activeConnections[tool] = nil
		end
		if IsItemMonitored("SeedShop", tool.Name) or IsItemMonitored("GearShop", tool.Name) then CheckAndUpdateInventoryDashboard() end
	end)
	
	for _, tool in ipairs(backpack:GetChildren()) do trackTool(tool) end

	task.spawn(function()
		local leaderstats = Players.LocalPlayer:WaitForChild("leaderstats", 10)
		local sheckles = leaderstats and (leaderstats:WaitForChild("Sheckles", 5) or leaderstats:WaitForChild("Shekels", 5))
		if sheckles then sheckles.Changed:Connect(CheckAndUpdateInventoryDashboard) end
		Players.LocalPlayer:GetAttributeChangedSignal("Sheckles"):Connect(CheckAndUpdateInventoryDashboard)
		Players.LocalPlayer:GetAttributeChangedSignal("Shekels"):Connect(CheckAndUpdateInventoryDashboard)
	end)
end

-- 1. Perform immediate startup scan 
PerformStartupScan("GearShop", gearShopItems)
PerformStartupScan("SeedShop", seedShopItems)

-- 2. Establish initial baseline for polling
InitStockState("GearShop", gearShopItems)
InitStockState("SeedShop", seedShopItems)

-- 3. Launch the dedicated polling loop
StartPolling()

-- 4. Setup existing dashboard/inventory monitors
SetupInventoryListeners()
CheckAndUpdateInventoryDashboard()