-- [[ Stock Values Notifier v5.0 ]] --

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local CONFIG_FILE = "StockNotifierConfig.lua"
local DEFAULT_WEBHOOK = "https://discord.com/api/webhooks/1526045938206900335/ykZb_vJTmf4O2FT537kpWHKwKOH3_7fouBkFS6OlqAtx09fjZtKT8mfNbBfDumQu5F9p"
local DEFAULT_MENTION = "<@604609802835853333>"

-- Safely wait for the target folders to load in ReplicatedStorage
local stockValues = ReplicatedStorage:WaitForChild("StockValues")
local gearShopItems = stockValues:WaitForChild("GearShop"):WaitForChild("Items")
local seedShopItems = stockValues:WaitForChild("SeedShop"):WaitForChild("Items")

---------------------------------------------------
-- Configuration Management
---------------------------------------------------

-- Serializes the table back into the exact requested Lua string format
local function SaveConfig(configData)
	local lines = {
		"return {",
		string.format('\tWebhook = "%s",', configData.Webhook or ""),
		string.format('\tMention = "%s",\n', configData.Mention or ""),
	}

	for _, shop in ipairs({"SeedShop", "GearShop"}) do
		if configData[shop] then
			table.insert(lines, string.format('\t%s = {', shop))
			
			-- Sort items alphabetically for a clean config file
			local sortedItems = {}
			for item, _ in pairs(configData[shop]) do
				table.insert(sortedItems, item)
			end
			table.sort(sortedItems)

			for _, item in ipairs(sortedItems) do
				local toggle = configData[shop][item]
				table.insert(lines, string.format('\t\t["%s"] = %s,', item, tostring(toggle)))
			end
			table.insert(lines, "\t},\n")
		end
	end

	table.insert(lines, "}")
	
	if writefile then
		writefile(CONFIG_FILE, table.concat(lines, "\n"))
	end
end

-- Loads the Lua config file using loadstring
local function LoadConfig()
	if isfile and isfile(CONFIG_FILE) then
		local success, result = pcall(function()
			local content = readfile(CONFIG_FILE)
			local func = loadstring(content)
			if func then return func() end
		end)
		if success and type(result) == "table" then
			return result
		end
	end
	return nil
end

-- Initialize and update configuration
local Config = LoadConfig()
local configModified = false

if not Config then
	Config = {
		Webhook = DEFAULT_WEBHOOK,
		Mention = DEFAULT_MENTION,
		SeedShop = {},
		GearShop = {}
	}
	configModified = true
else
	-- Ensure the Mention field exists in older configs
	if Config.Mention == nil then
		Config.Mention = DEFAULT_MENTION
		configModified = true
	end
end

-- Scan folders to append missing items to config
local function SyncConfigWithShop(shopName, folder)
	if type(Config[shopName]) ~= "table" then
		Config[shopName] = {}
		configModified = true
	end

	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			if Config[shopName][item.Name] == nil then
				Config[shopName][item.Name] = true
				configModified = true
			end
		end
	end
end

SyncConfigWithShop("GearShop", gearShopItems)
SyncConfigWithShop("SeedShop", seedShopItems)

if configModified then
	SaveConfig(Config)
end

---------------------------------------------------
-- Webhook Logic
---------------------------------------------------

local function SendWebhookNotification(shopName, itemName, currentStock)
	local webhookUrl = Config.Webhook
	
	if type(webhookUrl) ~= "string" or webhookUrl == "" or not webhookUrl:match("^https://discord%.com/api/webhooks/") then
		warn("[StockNotifier] Webhook notification skipped: Invalid or empty webhook URL.")
		return
	end

	task.spawn(function()
		local isoTime = os.date("!%Y-%m-%dT%H:%M:%SZ")
		local currentTime = os.date("%Y-%m-%d %H:%M:%S")

		local description = string.format(
			"**Shop:** %s\n**Item:** %s\n**Current Stock:** %d\n**Time Detected:** %s\n**JobId:** `%s`\n**PlaceId:** `%s`",
			shopName, 
			itemName, 
			currentStock, 
			currentTime, 
			game.JobId, 
			tostring(game.PlaceId)
		)

		local messageContent = string.format("%dx %s has appeared.", currentStock, itemName)
		if type(Config.Mention) == "string" and Config.Mention ~= "" then
			messageContent = string.format("%s %s", Config.Mention, messageContent)
		end

		local payload = {
			content = messageContent,
			embeds = {
				{
					title = "📦 Stock Restock Detected!",
					description = description,
					color = 5763719, -- Green color
					timestamp = isoTime,
					footer = {
						text = string.format("Detected by %s", Players.LocalPlayer.Name)
					}
				}
			}
		}

		local jsonPayload = HttpService:JSONEncode(payload)

		local response = request({
			Url = webhookUrl,
			Method = "POST",
			Headers = { ["Content-Type"] = "application/json" },
			Body = jsonPayload,
		})

		if response.StatusCode == 200 or response.StatusCode == 204 then
		else
			warn("[StockNotifier] Failed to send webhook:", response.StatusCode, response.Body)
		end
	end)
end

---------------------------------------------------
-- Monitoring Logic
---------------------------------------------------

local stockState = {}

local function MonitorShop(shopName, folder)
	stockState[shopName] = {}

	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			-- Initialize previous state silently
			stockState[shopName][item.Name] = item.Value

			-- Listen for future changes
			item:GetPropertyChangedSignal("Value"):Connect(function()
				local newValue = item.Value
				local oldValue = stockState[shopName][item.Name]
				
				-- Update local tracker
				stockState[shopName][item.Name] = newValue

				-- Only trigger if stock went from 0 to 1 or higher
				if oldValue == 0 and newValue >= 1 then
					local isMonitored = Config[shopName] and Config[shopName][item.Name]
					
					if isMonitored then
						SendWebhookNotification(shopName, item.Name, newValue)
					else
					end
				end
			end)
			
		end
	end
end

---------------------------------------------------
-- Startup Scan
---------------------------------------------------

local function PerformStartupScan(shopName, folder)
	for _, item in ipairs(folder:GetChildren()) do
		if item:IsA("NumberValue") then
			local isMonitored = Config[shopName] and Config[shopName][item.Name]
			
			-- If enabled and stock exists, notify immediately
			if isMonitored and item.Value >= 1 then
				SendWebhookNotification(shopName, item.Name, item.Value)
			end
		end
	end
end

-- Attach listeners
MonitorShop("GearShop", gearShopItems)
MonitorShop("SeedShop", seedShopItems)

-- Perform one-time startup scan
PerformStartupScan("GearShop", gearShopItems)
PerformStartupScan("SeedShop", seedShopItems)