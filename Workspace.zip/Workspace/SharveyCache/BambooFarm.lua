-- ============================================================================
-- Auto Planter & Manager - Standalone Script
-- Version: 1.3.3 (Single Center Sprinkler Placement - Moon Finder Logic)
-- Dedicated to automatic planting in Plant Area 2 & Sprinkler management.
-- Integrated with Webhook Notification System & Strict Tool Management.
-- ============================================================================

if not game:IsLoaded() then
    game.Loaded:Wait()
end

-- ============================================================================
-- SERVICES & NETWORKING
-- ============================================================================
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")
local HttpService = game:GetService("HttpService")

local request = request or http_request or (syn and syn.request)

local player = Players.LocalPlayer
local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))

-- Securely load the Fruit Visualizer Controller to calculate weights
local FruitVisualizerController = require(player:WaitForChild("PlayerScripts"):WaitForChild("Controllers"):WaitForChild("FruitVisualizerController"))

-- ============================================================================
-- ⚙️ CONFIGURATION
-- ============================================================================

-- [ PLANTING CONFIG ]
local PLANT_DELAY = 0.1
local MIN_PLANT_DISTANCE = 0.5
local MAX_GENERATION_ATTEMPTS = 50 
local TARGET_SEED_NAME = "Bamboo"

-- [ SUPER SPRINKLER CONFIG ]
local ENABLE_SUPER_SPRINKLER_WORKER = true
local SPRINKLER_SCAN_INTERVAL = 1 -- seconds
local TARGET_SPRINKLER = "Super Sprinkler"
local SPRINKLER_SPACING = 10 -- Set this to the exact coverage diameter of your sprinkler

-- [ WEBHOOK CONFIG ]
local WEBHOOK_ENABLED = true
local WEBHOOK_URL = "https://discord.com/api/webhooks/1527922387146772630/qMBBvpj84LCKL_ri9wCTVCj-Habrd-4Al85USQMqj4zGDKFdLtIcA5BPFcuCjZhgzPjB"
local WEBHOOK_USERNAME = "Bamboo Farm"
local WEBHOOK_AVATAR = ""
local WEBHOOK_COLOR = 65280 -- Green
local KEEP_KG = 150

-- ============================================================================
-- VARIABLES
-- ============================================================================
local isPlanting = false
local plantingThread = nil

local isSprinklerWorkerRunning = false
local sprinklerThread = nil

local notifierThread = nil
local NotifiedBamboos = {}

-- Synchronization State
local sprinklerBusy = false
local isPlanterYielding = false

-- ============================================================================
-- WEBHOOK & NOTIFICATION SYSTEM
-- ============================================================================

local function HasAlreadyNotified(guid)
    return NotifiedBamboos[guid] == true
end

local function MarkBambooNotified(guid)
    if guid then
        NotifiedBamboos[guid] = true
    end
end

local function BuildWebhookEmbed(data)
    local embedDescription = string.format(
        "🌿 **Bamboo Keeper Detected**\n\n" ..
        "**Weight:**\n%.2f KG\n\n" ..
        "**Mutation:**\n%s\n\n" ..
        "**Variant:**\n%s\n\n" ..
        "**Growth:**\n%d%%\n\n" ..
        "**Threshold:**\n%.2f KG\n\n" ..
        "**Position:**\n%d, %d, %d\n\n" ..
        "**GUID:**\n%s\n\n" ..
        "**Time:**\n<t:%d:F>",
        data.Weight,
        data.Mutation,
        data.Variant,
        data.Growth,
        data.Threshold,
        data.Position.X, data.Position.Y, data.Position.Z,
        data.GUID,
        data.Timestamp
    )

    return {
        username = WEBHOOK_USERNAME,
        avatar_url = WEBHOOK_AVATAR ~= "" and WEBHOOK_AVATAR or nil,
        embeds = {{
            title = "✨ High-Weight Bamboo Kept!",
            description = embedDescription,
            color = WEBHOOK_COLOR,
            footer = { text = "Plot Owner: " .. data.PlotOwner }
        }}
    }
end

local function SendWebhook(data)
    if not WEBHOOK_ENABLED or WEBHOOK_URL == "" then return end
    if not request then return end
    
    local payload = BuildWebhookEmbed(data)
    
    task.spawn(function()
        pcall(function()
            request({
                Url = WEBHOOK_URL,
                Method = "POST",
                Headers = { ["Content-Type"] = "application/json" },
                Body = HttpService:JSONEncode(payload)
            })
        end)
    end)
    
    print(string.format("[Bamboo Farm]\nWebhook sent for Bamboo:\nWeight: %.2f KG\nMutation: %s\nGUID: %s", data.Weight, data.Mutation, data.GUID))
end

local function ShouldNotifyBamboo(bamboo)
    local guid = bamboo:GetAttribute("PlantId") or bamboo.Name
    if HasAlreadyNotified(guid) then return false, 0, guid end
    
    local seedName = bamboo:GetAttribute("SeedName") or ""
    if not string.find(seedName, "Bamboo") then return false, 0, guid end
    
    local ok, weight = pcall(function()
        return tonumber(FruitVisualizerController.CalculatePlantWeight and FruitVisualizerController:CalculatePlantWeight(bamboo) or 0)
    end)
    if not ok or not weight then weight = 0 end
    
    if weight >= KEEP_KG then
        return true, weight, guid
    end
    
    return false, weight, guid
end

local function StartNotifierScanner()
    if notifierThread then return end
    notifierThread = task.spawn(function()
        while true do
            if WEBHOOK_ENABLED and WEBHOOK_URL ~= "" then
                local gardens = Workspace:FindFirstChild("Gardens")
                if gardens then
                    for _, plot in ipairs(gardens:GetChildren()) do
                        if plot:GetAttribute("OwnerUserId") == player.UserId then
                            local plantsFolder = plot:FindFirstChild("Plants")
                            if plantsFolder then
                                for _, plant in ipairs(plantsFolder:GetChildren()) do
                                    local shouldNotify, weight, guid = ShouldNotifyBamboo(plant)
                                    
                                    if shouldNotify then
                                        MarkBambooNotified(guid)
                                        
                                        local mutation = plant:GetAttribute("Mutation") or "None"
                                        local variant = plant:GetAttribute("Variant") or "Normal"
                                        local age = plant:GetAttribute("Age") or 0
                                        local maxAge = plant:GetAttribute("MaxAge") or 1
                                        local growth = math.min(100, math.floor((age / maxAge) * 100))
                                        local pos = plant:GetPivot().Position
                                        
                                        local data = {
                                            Weight = weight,
                                            Mutation = mutation,
                                            Variant = variant,
                                            Growth = growth,
                                            Threshold = KEEP_KG,
                                            Position = pos,
                                            GUID = guid,
                                            PlotOwner = player.Name,
                                            Timestamp = os.time()
                                        }
                                        
                                        SendWebhook(data)
                                    end
                                end
                            end
                            break
                        end
                    end
                end
            end
            task.wait(2)
        end
    end)
end

-- ============================================================================
-- PLOT & AREA DETECTION
-- ============================================================================

local function GetPlayerPlot()
    local gardens = Workspace:FindFirstChild("Gardens")
    if not gardens then return nil end

    for _, plot in ipairs(gardens:GetChildren()) do
        if plot:GetAttribute("OwnerUserId") == player.UserId then
            return plot
        end
    end
    return nil
end

local function GetPlantArea2()
    local plot = GetPlayerPlot()
    if not plot then return nil end

    local visualFolder = plot:FindFirstChild("Visual")
    if not visualFolder then return nil end

    return visualFolder:FindFirstChild("PlantAreaColumn2")
end

local function GetPlayerGroundHeight()
    local char = player.Character
    if not char then return 0 end
    
    local root = char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart
    if not root then return 0 end
    
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = { char }
    
    local result = Workspace:Raycast(root.Position, Vector3.new(0, -100, 0), params)
    return result and result.Position.Y or root.Position.Y
end

-- ============================================================================
-- TOOL MANAGEMENT & VALIDATION (MOON FINDER IMPLEMENTATION)
-- ============================================================================

local function getCharacter()
    return player.Character or player.CharacterAdded:Wait()
end

local function equipTool(toolName)
    local char = getCharacter()
    local tool = player.Backpack:FindFirstChild(toolName) or char:FindFirstChild(toolName)
    if not tool then return nil end
    
    if tool.Parent ~= char then
        local humanoid = char:FindFirstChild("Humanoid")
        if humanoid then humanoid:EquipTool(tool) end
        
        -- Exact Moon Finder equip wait sequence
        local deadline = tick() + 2
        repeat task.wait() until tool.Parent == char or tick() > deadline
        task.wait(0.1) -- Critical 1-frame wait before placement
    end
    return tool
end

local function VerifySprinklerExists(plot)
    if not plot then return false end
    local sprinklersFolder = plot:FindFirstChild("Sprinklers")
    if not sprinklersFolder then return false end
    
    -- Exact Moon Finder sprinkler detection
    for _, s in ipairs(sprinklersFolder:GetChildren()) do
        local sName = s:GetAttribute("SprinklerName") or s.Name
        if sName == TARGET_SPRINKLER then
            return true
        end
    end
    return false
end

-- ============================================================================
-- SPRINKLER PLACEMENT HELPER
-- ============================================================================

local function placeSprinklerAt(position, sprinklerName, plotId)
    local tool = equipTool(sprinklerName)
    if not tool then return false end
    
    print("\n[Sprinkler]")
    print("Using Moon Finder placement logic...")
    print("Remote: Networking.Place.PlaceSprinkler")
    print("Arguments:")
    print("Position: " .. tostring(position))
    print("Tool: " .. tostring(tool))
    print("Tool Name: " .. tostring(sprinklerName))
    print("Plot ID: " .. tostring(plotId))
    
    -- Exact Moon Finder network remote, argument order, and types
    local success = pcall(function() 
        Networking.Place.PlaceSprinkler:Fire(position, sprinklerName, tool, plotId) 
    end)
    
    print("Placement fired.\n")
    return success
end

-- ============================================================================
-- SYNCHRONIZATION HELPERS (UPDATED WITH MOON FINDER LOGIC)
-- ============================================================================

local function PausePlanting()
    sprinklerBusy = true
end

local function ResumePlanting()
    sprinklerBusy = false
end

local function WaitForPlantingPaused()
    -- Yields until the planter confirms it has paused its loop
    while isPlanting and not isPlanterYielding do
        task.wait(0.1)
    end
end

local function PlaceMissingSuperSprinkler(plot, area)
    print("[Sprinkler Worker] Missing sprinkler.")
    
    PausePlanting()
    WaitForPlantingPaused()
    
    -- Extract Plot ID using Moon Finder's matching logic
    local plotId = tonumber(plot.Name:match("%d+")) or 0
    
    while isSprinklerWorkerRunning and not VerifySprinklerExists(plot) do
        print("[Sprinkler Worker] Placing ONE Super Sprinkler at center of Plant Column Area 2...")
        
        -- Compute single center position
        local surfaceY = GetPlayerGroundHeight()
        local centerPos = Vector3.new(area.Position.X, surfaceY, area.Position.Z)
        
        -- Run the single center placement
        placeSprinklerAt(centerPos, TARGET_SPRINKLER, plotId)
        
        task.wait(2) -- Wait for server replication
        
        if VerifySprinklerExists(plot) then
            print("[Sprinkler Worker] Placement verified.")
            break 
        else
            task.wait(0.5) 
        end
    end
    
    while isSprinklerWorkerRunning do
        if equipTool(TARGET_SEED_NAME) then
            break
        end
        task.wait(0.5)
    end
    
    print("[Sprinkler Worker] Resuming planter.")
    ResumePlanting()
end

-- ============================================================================
-- SUPER SPRINKLER WORKER (SYNCHRONIZED)
-- ============================================================================

local function StartSprinklerWorker()
    if isSprinklerWorkerRunning then return end
    isSprinklerWorkerRunning = true
    
    sprinklerThread = task.spawn(function()
        while isSprinklerWorkerRunning do
            task.wait(SPRINKLER_SCAN_INTERVAL)
            
            if not ENABLE_SUPER_SPRINKLER_WORKER then continue end
            
            local plot = GetPlayerPlot()
            local area = GetPlantArea2()
            
            if not plot or not area then continue end
            
            if not VerifySprinklerExists(plot) then
                PlaceMissingSuperSprinkler(plot, area)
            end
        end
    end)
end

local function StopSprinklerWorker()
    isSprinklerWorkerRunning = false
    if sprinklerThread then
        task.cancel(sprinklerThread)
        sprinklerThread = nil
    end
end

-- ============================================================================
-- POSITIONING & VALIDATION (PLANTING)
-- ============================================================================

local function GenerateRandomPlantPosition()
    local areaPart = GetPlantArea2()
    if not areaPart then return nil end

    local randomX = (math.random() - 0.5) * areaPart.Size.X
    local randomZ = (math.random() - 0.5) * areaPart.Size.Z

    local randomCFrame = areaPart.CFrame * CFrame.new(randomX, 0, randomZ)
    
    local groundY = GetPlayerGroundHeight()
    
    return Vector3.new(randomCFrame.Position.X, groundY, randomCFrame.Position.Z)
end

local function IsPlantPositionValid(position)
    if not position then return false end

    local plot = GetPlayerPlot()
    if not plot then return false end

    local plantsFolder = plot:FindFirstChild("Plants")
    if not plantsFolder then return true end 

    for _, plant in ipairs(plantsFolder:GetChildren()) do
        local plantPos = nil
        
        if plant:IsA("Model") and plant.PrimaryPart then
            plantPos = plant.PrimaryPart.Position
        else
            pcall(function() plantPos = plant:GetPivot().Position end)
        end
        
        if not plantPos then
            for _, child in ipairs(plant:GetDescendants()) do
                if child:IsA("BasePart") then
                    plantPos = child.Position
                    break
                end
            end
        end

        if plantPos then
            local flatPosition = Vector3.new(position.X, 0, position.Z)
            local flatPlantPos = Vector3.new(plantPos.X, 0, plantPos.Z)
            
            local distance = (flatPosition - flatPlantPos).Magnitude
            if distance < MIN_PLANT_DISTANCE then
                return false
            end
        end
    end

    return true
end

local function PlantSeed(position, tool, seedName)
    if tool and seedName and position then
        pcall(function()
            Networking.Plant.PlantSeed:Fire(position, seedName, tool)
        end)
    end
end

-- ============================================================================
-- PLANTING WORKER (SYNCHRONIZED)
-- ============================================================================

local function StartPlanting()
    if isPlanting then return end
    isPlanting = true
    
    plantingThread = task.spawn(function()
        while isPlanting do
            -- SYNCHRONIZATION: Yield if Sprinkler Worker takes priority
            if sprinklerBusy then
                isPlanterYielding = true
                while sprinklerBusy and isPlanting do
                    task.wait(0.1)
                end
                isPlanterYielding = false
                continue -- Restart iteration from the beginning once unpaused
            end
            
            local area = GetPlantArea2()
            
            if sprinklerBusy then continue end
            
            local tool = equipTool(TARGET_SEED_NAME)
            if not tool then
                warn(string.format("Auto Planter: %s not found in backpack or could not be equipped.", TARGET_SEED_NAME))
                task.wait(1)
                continue
            end
            
            local seedName = tool:GetAttribute("SeedTool")
            
            -- Check before generating positions
            if sprinklerBusy then continue end
            if area and tool and seedName then
                local targetPosition = nil
                
                for i = 1, MAX_GENERATION_ATTEMPTS do
                    -- Safety check inside the generation loop
                    if sprinklerBusy then break end
                    
                    local candidatePosition = GenerateRandomPlantPosition()
                    if IsPlantPositionValid(candidatePosition) then
                        targetPosition = candidatePosition
                        break
                    end
                end
                
                -- Final check before committing to the plant action
                if sprinklerBusy then continue end
                
                if targetPosition then
                    PlantSeed(targetPosition, tool, seedName)
                else
                    warn("Auto Planter: Unable to find valid spacing in area. Is it full?")
                end
            end
            
            task.wait(PLANT_DELAY)
        end
    end)
end

local function StopPlanting()
    isPlanting = false
    if plantingThread then
        task.cancel(plantingThread)
        plantingThread = nil
    end
end

-- ============================================================================
-- UI SETUP
-- ============================================================================

local function CreateUI()
    local playerGui = player:WaitForChild("PlayerGui")
    
    local oldGui = playerGui:FindFirstChild("AutoPlanterGUI")
    if oldGui then oldGui:Destroy() end

    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "AutoPlanterGUI"
    screenGui.ResetOnSpawn = false
    screenGui.Parent = playerGui

    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(0, 150, 0, 80)
    frame.Position = UDim2.new(0.02, 0, 0.4, 0)
    frame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
    frame.Active = true
    frame.Draggable = true
    frame.Parent = screenGui
    
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 6)
    corner.Parent = frame

    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, 0, 0, 25)
    title.BackgroundTransparency = 1
    title.Font = Enum.Font.GothamBold
    title.Text = "Auto Planter"
    title.TextColor3 = Color3.new(1, 1, 1)
    title.TextSize = 14
    title.Parent = frame

    local toggleBtn = Instance.new("TextButton")
    toggleBtn.Size = UDim2.new(0.8, 0, 0, 35)
    toggleBtn.Position = UDim2.new(0.1, 0, 0, 35)
    toggleBtn.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
    toggleBtn.Font = Enum.Font.GothamBold
    toggleBtn.Text = "Start"
    toggleBtn.TextColor3 = Color3.new(1, 1, 1)
    toggleBtn.TextSize = 14
    toggleBtn.Parent = frame
    
    local btnCorner = Instance.new("UICorner")
    btnCorner.CornerRadius = UDim.new(0, 4)
    btnCorner.Parent = toggleBtn

    toggleBtn.MouseButton1Click:Connect(function()
        if isPlanting then
            StopPlanting()
            toggleBtn.Text = "Start"
            toggleBtn.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
        else
            StartPlanting()
            toggleBtn.Text = "Stop"
            toggleBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
        end
    end)
end

-- Initialize background threads (Independent of Auto Planter UI Toggle)
StartNotifierScanner()
StartSprinklerWorker()
CreateUI()