if not game:IsLoaded() then
    game.Loaded:Wait()
end

task.wait(5)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- ============================================================================
-- CONFIGURATION
-- ============================================================================
Config = {
    TargetUsers = {
        "SharvxPlayz",
        "PhoeyuArmy",
	"1MJ000K3R",
    }, -- Players whose plots will be maintained (searched in order)

    TweenSpeed = 20,             -- Studs per second
    WaterDelay = 8,             -- Seconds between watering attempts
    WaterDistance = 20,          -- Begin watering / stop moving within this distance

    CheckInterval = 1,           -- Seconds to wait if no plants exist

    PlaceSprinklers = true,
    AutoWater = true,
}

-- ============================================================================
-- STATE MANAGEMENT
-- ============================================================================
local State = {
    MaintenanceRunning = false,
    CurrentPlot = nil,
    TargetUserIds = {},        -- Cached dictionary mapping Username -> UserId
    ActiveTargetId = nil,      -- The UserId of the currently selected plot owner
    ActiveTargetName = nil,    -- The Username of the currently selected plot owner
    CurrentTargetPlant = nil,
    CurrentTween = nil,
}

local TimerState = {
    TimeRemaining = 300 -- 4 minutes in seconds
}

local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))
local toggleBtn -- Forward declaration for UI
local timerLabel -- Forward declaration for Timer UI

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================
local function getCharacter()
    return player.Character or player.CharacterAdded:Wait()
end

local function cancelCurrentTween()
    if State.CurrentTween then
        pcall(function() State.CurrentTween:Cancel() end)
        State.CurrentTween = nil
    end
end

-- ============================================================================
-- TARGET PLOT & USER DETECTION
-- ============================================================================
local function resolveTargetUserIds()
    for _, username in ipairs(Config.TargetUsers) do
        -- Only lookup if not already cached
        if not State.TargetUserIds[username] then
            if username == player.Name then
                State.TargetUserIds[username] = player.UserId
            else
                local targetPlayer = Players:FindFirstChild(username)
                if targetPlayer then
                    State.TargetUserIds[username] = targetPlayer.UserId
                else
                    pcall(function()
                        State.TargetUserIds[username] = Players:GetUserIdFromNameAsync(username)
                    end)
                end
            end
        end
    end
end

local function getTargetPlot()
    resolveTargetUserIds()

    -- Return cached plot if it remains valid
    if State.CurrentPlot and State.CurrentPlot.Parent then
        local currentOwnerId = State.CurrentPlot:GetAttribute("OwnerUserId")
        if currentOwnerId == State.ActiveTargetId then
            return State.CurrentPlot
        end
        -- In case the active ID was wiped but the plot is still owned by a valid user
        for username, id in pairs(State.TargetUserIds) do
            if currentOwnerId == id then
                State.ActiveTargetId = id
                State.ActiveTargetName = username
                return State.CurrentPlot
            end
        end
    end

    -- Reacquire if missing or invalid
    local gardens = Workspace:FindFirstChild("Gardens")
    if gardens then
        for _, plot in ipairs(gardens:GetChildren()) do
            local ownerId = plot:GetAttribute("OwnerUserId")
            if ownerId then
                -- Check if the owner matches any of our target users
                for username, id in pairs(State.TargetUserIds) do
                    if ownerId == id then
                        State.CurrentPlot = plot
                        State.ActiveTargetId = id
                        State.ActiveTargetName = username
                        return State.CurrentPlot
                    end
                end
            end
        end
    end

    State.CurrentPlot = nil
    State.ActiveTargetId = nil
    State.ActiveTargetName = nil
    return nil
end

local function getTargetUserGroundY()
    if not State.ActiveTargetName then return nil end

    local targetPlayer = Players:FindFirstChild(State.ActiveTargetName)
    if not targetPlayer then return nil end

    local targetChar = targetPlayer.Character
    if not targetChar then return nil end

    local targetHrp = targetChar:FindFirstChild("HumanoidRootPart")
    if not targetHrp then return nil end

    -- Raycast downward from the target user's HRP to find the ground
    local rayOrigin = targetHrp.Position
    local rayDirection = Vector3.new(0, -50, 0)

    local raycastParams = RaycastParams.new()
    raycastParams.FilterDescendantsInstances = {targetChar}
    raycastParams.FilterType = Enum.RaycastFilterType.Exclude

    local rayResult = Workspace:Raycast(rayOrigin, rayDirection, raycastParams)

    if rayResult then
        return rayResult.Position.Y
    end

    -- Graceful fallback if raycast fails
    return targetHrp.Position.Y
end

-- ============================================================================
-- PLANT DETECTION & VALIDATION
-- ============================================================================
local function getPlantPosition(plant)
    if not plant or not plant.Parent then return nil end
    if plant:FindFirstChild("Model") and plant.PrimaryPart then return plant.PrimaryPart.Position end

    local ok, pivot = pcall(function() return plant:GetPivot() end)
    if ok and pivot then return pivot.Position end

    if plant:IsA("BasePart") then return plant.Position end

    for _, child in ipairs(plant:GetDescendants()) do
        if child:IsA("BasePart") then return child.Position end
    end
    return nil
end

local function isPlantValid(plant, plot)
    if not plant then return false end
    if plant.Parent ~= plot:FindFirstChild("Plants") then return false end
    if not getPlantPosition(plant) then return false end

    -- Exclude plants that are actively being removed/destroyed
    if plant:GetAttribute("Destroyed") or plant:GetAttribute("Harvested") then return false end

    return true
end

local function getFirstValidPlant(plot)
    if not plot then return nil end
    local plantsFolder = plot:FindFirstChild("Plants")
    if not plantsFolder then return nil end

    for _, plant in ipairs(plantsFolder:GetChildren()) do
        if isPlantValid(plant, plot) then
            return plant
        end
    end
    return nil
end

-- ============================================================================
-- MOVEMENT (TWEEN ENGINE)
-- ============================================================================
local function tweenToPosition(targetPos)
    cancelCurrentTween()

    local char = getCharacter()
    local hrp = char:FindFirstChild("HumanoidRootPart")
    if not hrp then return false end

    -- Distance calculated directly to the provided targetPos (which already uses TargetUserGroundY)
    local distance = (targetPos - hrp.Position).Magnitude

    -- Skip tween if already in range
    if distance <= Config.WaterDistance then return true end

    local duration = distance / Config.TweenSpeed
    local tweenInfo = TweenInfo.new(duration, Enum.EasingStyle.Linear)

    State.CurrentTween = TweenService:Create(hrp, tweenInfo, {CFrame = CFrame.new(targetPos)})

    local tweenCompleted = false
    local connection
    connection = State.CurrentTween.Completed:Connect(function()
        tweenCompleted = true
    end)

    State.CurrentTween:Play()

    -- Safe monitoring loop: Cancel if we get close enough or conditions change
    local timeout = tick() + duration + 1
    while State.MaintenanceRunning and not tweenCompleted and tick() < timeout and hrp.Parent do
        task.wait(0.1)
        
        -- Abort if the target plant vanished while we were walking to it
        if not isPlantValid(State.CurrentTargetPlant, State.CurrentPlot) then
            break
        end

        local currentDist = (targetPos - hrp.Position).Magnitude
        if currentDist <= Config.WaterDistance then
            tweenCompleted = true
            break
        end
    end

    if connection then connection:Disconnect() end
    cancelCurrentTween()

    return State.MaintenanceRunning and (hrp.Parent ~= nil)
end

-- ============================================================================
-- ACTION HANDLERS & SPRINKLER LOGIC
-- ============================================================================
local function equipTool(toolName)
    local char = getCharacter()
    local tool = player.Backpack:FindFirstChild(toolName) or char:FindFirstChild(toolName)

    if not tool then return nil end

    if tool.Parent ~= char then
        local humanoid = char:FindFirstChild("Humanoid")
        if humanoid then
            humanoid:EquipTool(tool)
            task.wait(0.2) -- Network replication buffer
        end
    end

    return tool
end

local function hasSuperSprinkler(plot)
    if not plot then return false end
    local sprinklersFolder = plot:FindFirstChild("Sprinklers")
    if not sprinklersFolder then return false end

    for _, sprinkler in ipairs(sprinklersFolder:GetChildren()) do
        local sName = sprinkler:GetAttribute("SprinklerName") or sprinkler.Name
        if sName == "Super Sprinkler" then
            return true
        end
    end
    return false
end

local function checkAndPlaceSprinkler(plot, position)
    if not Config.PlaceSprinklers then return end
    if not plot then return end

    -- Check if one already exists to prevent duplicates
    if hasSuperSprinkler(plot) then return end

    local sprinklerTool = equipTool("Super Sprinkler")
    if sprinklerTool then
        local plotId = tonumber(plot.Name:match("%d+")) or 0
        pcall(function() 
            Networking.Place.PlaceSprinkler:Fire(position, "Super Sprinkler", sprinklerTool, plotId) 
        end)
        
        -- Wait briefly to ensure the server registers the placement
        task.wait(1.5) 
        
        -- Verify that the sprinkler actually exists before attempting another placement later
        if not hasSuperSprinkler(plot) then
            return -- Verification failed, it will gracefully retry next cycle
        end
    end
end

local function performWatering(position)
    if not Config.AutoWater then return end

    local waterTool = equipTool("Super Watering Can") or equipTool("Watering Can")
    if waterTool then
        pcall(function() 
            Networking.WateringCan.UseWateringCan:Fire(position, waterTool.Name, waterTool) 
        end)
    end
end

-- ============================================================================
-- TIMER LOGIC
-- ============================================================================
local function updateTimerUI()
    if not timerLabel then return end
    local minutes = math.floor(TimerState.TimeRemaining / 60)
    local seconds = TimerState.TimeRemaining % 60
    timerLabel.Text = string.format("Next Super Sprinkler: %02d:%02d", minutes, seconds)
end

local function forceSprinklerCheck()
    if State.CurrentPlot and State.CurrentTargetPlant then
        local plantPos = getPlantPosition(State.CurrentTargetPlant)
        local yPos = getTargetUserGroundY()
        if plantPos and yPos then
            local targetPos = Vector3.new(plantPos.X, yPos, plantPos.Z)
            task.spawn(checkAndPlaceSprinkler, State.CurrentPlot, targetPos)
        end
    end
end

local function runCountdownTimer()
    task.spawn(function()
        while true do
            task.wait(1)
            -- Pause timer if maintenance is stopped
            if State.MaintenanceRunning then
                TimerState.TimeRemaining = TimerState.TimeRemaining - 1
                
                if TimerState.TimeRemaining <= 0 then
                    -- Reset to 04:00 immediately
                    TimerState.TimeRemaining = 300
                    -- Trigger replacement check immediately
                    forceSprinklerCheck()
                end
                
                updateTimerUI()
            end
        end
    end)
end

-- ============================================================================
-- MAIN MAINTENANCE CYCLE
-- ============================================================================
local function runMaintenanceCycle()
    task.spawn(function()
        while State.MaintenanceRunning do
            -- 1. Ensure cached plot exists
            local plot = getTargetPlot()
            if not plot then
                task.wait(Config.CheckInterval)
                continue
            end

            -- 2. Find the FIRST valid plant
            State.CurrentTargetPlant = getFirstValidPlant(plot)
            if not State.CurrentTargetPlant then
                task.wait(Config.CheckInterval)
                continue
            end
            
            local plantPos = getPlantPosition(State.CurrentTargetPlant)
            if not plantPos then
                task.wait(0.1)
                continue
            end

            -- Recalculate and Cache TargetUserGroundY for this plant
            local targetUserGroundY = getTargetUserGroundY()
            if not targetUserGroundY then
                task.wait(0.5) -- TargetUser character might be loading/missing
                continue
            end
            
            -- Final calculation for Movement and Sprinkler placement
            local targetPos = Vector3.new(plantPos.X, targetUserGroundY, plantPos.Z)
            
            -- 3. Tween directly to that FIRST plant using the TargetUser Y position
            local arrivedSafely = tweenToPosition(targetPos)
            
            if arrivedSafely and State.MaintenanceRunning and isPlantValid(State.CurrentTargetPlant, plot) then
                local char = getCharacter()
                local hrp = char:FindFirstChild("HumanoidRootPart")
                
                if hrp then
                    local dist = (targetPos - hrp.Position).Magnitude
                    
                    -- 4. Once within Config.WaterDistance
                    if dist <= Config.WaterDistance then
                        
                        -- 5. Continue watering until the target becomes invalid
                        while State.MaintenanceRunning and isPlantValid(State.CurrentTargetPlant, plot) do
                            local currentPlantPos = getPlantPosition(State.CurrentTargetPlant)
                            if not currentPlantPos then break end
                            
                            -- Verify we haven't died or been flung
                            if not hrp or not hrp.Parent then break end

                            -- Dynamically track distance using the cached ground height
                            local currentTargetPos = Vector3.new(currentPlantPos.X, targetUserGroundY, currentPlantPos.Z)
                            local currentDist = (currentTargetPos - hrp.Position).Magnitude
                            
                            if currentDist <= Config.WaterDistance then
                                -- Continuously check and place sprinkler while camping
                                checkAndPlaceSprinkler(plot, currentTargetPos)
                                
                                -- UPDATED: Use currentTargetPos (ground Y) instead of currentPlantPos (pivot Y)
                                performWatering(currentTargetPos) 
                                task.wait(Config.WaterDelay)
                            else
                                -- If we were pushed out of range, break the loop to re-tween to it
                                break 
                            end
                        end
                    end
                end
            end
            
            -- 6 & 7. Inner loop breaks when plant is invalid, repeats to find the NEXT first plant
            task.wait(0.1) 
        end
    end)
end


local function stopMaintenance()
    State.MaintenanceRunning = false
    State.CurrentTargetPlant = nil
    cancelCurrentTween()

    -- Cleanup Character State
    local char = player.Character
    if char then
        local humanoid = char:FindFirstChild("Humanoid")
        if humanoid then humanoid:UnequipTools() end
    end
end

-- ============================================================================
-- USER INTERFACE
-- ============================================================================
local function createUI()
    local existing = playerGui:FindFirstChild("WaterAdminPanel")
    if existing then
        existing:Destroy()
    end

    local gui = Instance.new("ScreenGui")
    gui.Name = "WaterAdminPanel"
    gui.ResetOnSpawn = false
    gui.Parent = playerGui

    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(0, 220, 0, 70)
    frame.Position = UDim2.new(0.5, -110, 0.8, -70)
    frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
    frame.BorderSizePixel = 0
    frame.Active = true
    frame.Draggable = true
    frame.Parent = gui

    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

    local layout = Instance.new("UIListLayout")
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    layout.VerticalAlignment = Enum.VerticalAlignment.Center
    layout.Parent = frame

    toggleBtn = Instance.new("TextButton")
    toggleBtn.Size = UDim2.new(0.9, 0, 0, 35)

    -- Set default visuals to running state
    toggleBtn.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
    toggleBtn.Text = "Stop Maintenance"

    toggleBtn.TextColor3 = Color3.new(1, 1, 1)
    toggleBtn.Font = Enum.Font.GothamBold
    toggleBtn.TextSize = 14
    toggleBtn.Parent = frame

    Instance.new("UICorner", toggleBtn).CornerRadius = UDim.new(0, 4)

    toggleBtn.MouseButton1Click:Connect(function()
        if State.MaintenanceRunning then
            stopMaintenance()
            toggleBtn.Text = "Start Maintenance"
            toggleBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
        else
            State.MaintenanceRunning = true
            toggleBtn.Text = "Stop Maintenance"
            toggleBtn.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
            runMaintenanceCycle()
        end
    end)
end

local function createTimerUI()
    local existing = playerGui:FindFirstChild("SprinklerTimerPanel")
    if existing then 
        existing:Destroy() 
    end

    local gui = Instance.new("ScreenGui")
    gui.Name = "SprinklerTimerPanel"
    gui.ResetOnSpawn = false
    gui.Parent = playerGui

    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(0, 200, 0, 45)
    frame.Position = UDim2.new(1, -220, 1, -65) -- Bottom right placement
    frame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
    frame.BorderSizePixel = 0
    frame.Active = true
    frame.Draggable = true
    frame.Parent = gui

    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

    local layout = Instance.new("UIListLayout")
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    layout.VerticalAlignment = Enum.VerticalAlignment.Center
    layout.Parent = frame

    timerLabel = Instance.new("TextLabel")
    timerLabel.Size = UDim2.new(0.9, 0, 0, 35)
    timerLabel.BackgroundTransparency = 1
    timerLabel.TextColor3 = Color3.new(1, 1, 1)
    timerLabel.Font = Enum.Font.GothamBold
    timerLabel.TextSize = 14
    timerLabel.Parent = frame
    
    updateTimerUI()
end

createUI()
createTimerUI()

-- Auto-start the process when the script is executed
State.MaintenanceRunning = true
runMaintenanceCycle()
runCountdownTimer()