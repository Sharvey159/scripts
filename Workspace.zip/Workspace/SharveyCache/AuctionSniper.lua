-- ========================================================================
-- AUCTION OBSERVER v4.2
-- Event-Driven UI Monitor & Webhook Notification System
-- ========================================================================

local CONFIG = {
    WebhookURL = "https://discord.com/api/webhooks/1520090710290731101/wBfz1Eg2q2nvSNMBYKeu0ivklrMD-7DtKpLa5zHShJbj6-Js2cfBIP_ynFrQkd9ZprYD",
    
    Mention = {
        Enabled = true,
        UserId = "604609802835853333"
    },
    
    Items = {
        ["Super Watering Can"] = { Enabled = false , Mention = false },
        ["Super Sprinkler"] = { Enabled = true, Mention = true },

        ["Hypno Bloom"] = { Enabled = true, Mention = true },
        ["Dragon's Breath"] = { Enabled = true, Mention = true },
        ["Venom Spitter"] = { Enabled = false, Mention = false },
        ["Moon Bloom"] = { Enabled = true, Mention = true },

        ["Ghost Pepper"] = { Enabled = false, Mention = false },
        ["Venus Flytrap"] = { Enabled = false, Mention = false },

        ["Bamboo"] = { Enabled = false, Mention = false },
        ["Mushroom"] = { Enabled = false, Mention = false },

        ["Uncommon Seed Pack"] = { Enabled = false, Mention = false },

        ["Bear Trap Crate"] = { Enabled = false, Mention = false },
        ["Fence Crate"] = { Enabled = false, Mention = false },
        ["Teleporter Pad Crate"] = { Enabled = false, Mention = false },
        ["Conveyor Crate"] = { Enabled = false, Mention = false },

        ["Common Egg"] = { Enabled = false, Mention = false },
    }
}

-- ========================================================================
-- COMPATIBILITY POLYFILLS & EXECUTOR CHECKS
-- ========================================================================

local t_unpack = table.unpack or unpack
local t_clear = table.clear or function(t) for k in pairs(t) do t[k] = nil end end
local t_spawn = task and task.spawn or spawn
local t_delay = task and task.delay or delay

local httpRequest = request or http_request or (syn and syn.request) or (fluxus and fluxus.request)
if not httpRequest then
    warn("[Auction Observer] Warning: HTTP request API not found. Webhook notifications are disabled, but UI tracking will proceed.")
end

-- ========================================================================
-- SERVICES & GLOBALS
-- ========================================================================

local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local player = Players.LocalPlayer

-- Caches
local AuctionLots = {}        -- Internal cache of currently visible lots
local NotifiedLots = {}       -- Tracks Lot IDs we have already sent webhooks for
local UIConnections = {}      -- Holds active UI event listeners

local scanQueued = false      -- Debounce flag for event-driven scans

-- ========================================================================
-- HELPER FUNCTIONS
-- ========================================================================

-- Safe thread spawner using xpcall to log full stack traces with subsystem context
local function safeSpawn(contextName, func, ...)
    local args = {...}
    local n = select("#", ...)
    
    t_spawn(function()
        local success, err = xpcall(function()
            if n > 0 then
                func(t_unpack(args, 1, n))
            else
                func()
            end
        end, function(msg)
            return debug.traceback(tostring(msg), 2)
        end)
        
        if not success then
            warn(string.format("[Auction Observer Error - %s] Thread crashed:\n%s", tostring(contextName), tostring(err)))
        end
    end)
end

-- Normalizes string for robust matching, stripping quantities and decorations
local function normalizeString(str)
    if type(str) ~= "string" then return "" end
    str = string.lower(str)
    str = string.gsub(str, " ?%(x%d+%)", "")
    str = string.gsub(str, " x%d+", "")
    str = string.gsub(str, "%b()", "")
    str = string.gsub(str, "%b[]", "")
    str = string.gsub(str, "^%s*(.-)%s*$", "%1")
    str = string.gsub(str, "%s+", " ")
    return str
end

-- Converts time strings like "12m 30s" into total seconds
local function parseTimerToSeconds(timeStr)
    if type(timeStr) ~= "string" or timeStr == "--" or string.find(timeStr, "Refreshing") then return 0 end
    local hrs, mins2 = string.match(timeStr, "(%d+)h (%d+)m")
    if hrs and mins2 then return (tonumber(hrs) * 3600) + (tonumber(mins2) * 60) end
    local mins, secs = string.match(timeStr, "(%d+)m (%d+)s")
    if mins and secs then return (tonumber(mins) * 60) + tonumber(secs) end
    local secsOnly = string.match(timeStr, "(%d+)s")
    if secsOnly then return tonumber(secsOnly) end
    return 0 
end

-- Parses abbreviations like "2.5M" and strips commas
local function parsePriceText(text)
    if type(text) ~= "string" then return 0 end
    text = text:gsub(",", "") 
    local valStr, suffix = string.match(string.lower(text), "([%d%.]+)([kmb]?)")
    if not valStr then return 0 end
    
    local val = tonumber(valStr)
    if not val then return 0 end
    
    if suffix == "k" then val = val * 1000
    elseif suffix == "m" then val = val * 1000000
    elseif suffix == "b" then val = val * 1000000000
    end
    
    return val
end

-- Matches lot item names against the configuration
local function getMatchedConfig(fullName)
    local normalizedFullName = normalizeString(fullName)
    for configName, configData in pairs(CONFIG.Items) do
        if not configData.Enabled then continue end
        local normalizedConfigName = normalizeString(configName)
        if string.find(normalizedFullName, normalizedConfigName, 1, true) then
            return configData, configName
        end
    end
    return nil, nil
end

-- ========================================================================
-- WEBHOOK NOTIFICATIONS
-- ========================================================================

local function sendMentionWebhook(lotData, configData)
    if not httpRequest or not CONFIG.WebhookURL or CONFIG.WebhookURL == "" then return end

    local contentStr = ""
    if CONFIG.Mention.Enabled and configData.Mention then
        contentStr = string.format("<@%s>", CONFIG.Mention.UserId)
    end

    local priceStr = lotData.Price >= 1000000 and string.format("%.2fM", lotData.Price / 1000000) or tostring(lotData.Price)

    local payload = {
        content = contentStr,
        embeds = {{
            title = "🔔 New Auction Item Detected",
            description = string.format(
                "**Item:** %s\n**Price:** %s ¢\n**Timer:** %ds\n**Lot ID:** `%s`",
                lotData.ItemName, priceStr, lotData.Duration, lotData.LotId
            ),
            color = 5814783, -- Soft Blue
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }},
        allowed_mentions = { 
            parse = {"users"},
            users = { CONFIG.Mention.UserId }
        } 
    }

    safeSpawn("Webhook Dispatch", function()
        httpRequest({
            Url = CONFIG.WebhookURL,
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = HttpService:JSONEncode(payload)
        })
    end)
end

-- ========================================================================
-- CACHE MANAGEMENT & SCANNER
-- ========================================================================

-- Pure scanner: Reads UI, builds cache, triggers notifications
local function scanAuctionUI()
    local playerGui = player:FindFirstChild("PlayerGui")
    local auctionGui = playerGui and playerGui:FindFirstChild("Auction")
    local frame = auctionGui and auctionGui:FindFirstChild("Frame")
    local scrollFrame = frame and frame:FindFirstChild("ScrollingFrame")
    
    if not scrollFrame or not scrollFrame.Parent then return end

    local currentVisibleLots = {}

    -- 1. Scan and parse all visible lots
    for _, lotFrame in ipairs(scrollFrame:GetChildren()) do
        if lotFrame:IsA("Frame") and string.sub(lotFrame.Name, 1, 4) == "Lot_" then
            if not lotFrame.Parent then continue end
            
            local lotId = lotFrame.Name
            local mainFrame = lotFrame:FindFirstChild("Frame") and lotFrame.Frame:FindFirstChild("Main_Frame")
            if not mainFrame then continue end
            
            local itemName = mainFrame:FindFirstChild("ItemName") and mainFrame.ItemName.Text or "Unknown Item"
            local imageDisplay = mainFrame:FindFirstChild("ImageDisplay") or mainFrame
            local subtitle = imageDisplay:GetAttribute("ItemToolTipSubtitle") or ""
            local fullName = itemName .. (subtitle ~= "" and " " .. subtitle or "")
            
            local priceLabel = mainFrame:FindFirstChild("Price") or mainFrame:FindFirstChild("CurrentPrice")
            local price = priceLabel and parsePriceText(priceLabel.Text) or 0
            
            local refreshIn = mainFrame:FindFirstChild("RefreshIn")
            local timerLabel = refreshIn and (refreshIn:FindFirstChild("Timer") or refreshIn)
            local duration = timerLabel and timerLabel:IsA("TextLabel") and parseTimerToSeconds(timerLabel.Text) or 0
            
            local lotData = {
                LotId = lotId,
                ItemName = fullName,
                Price = price,
                Duration = duration,
                Subtitle = subtitle
            }

            -- Update Cache
            AuctionLots[lotId] = lotData
            currentVisibleLots[lotId] = true

            -- Check for newly detected items to notify
            if not NotifiedLots[lotId] then
                local configData, _ = getMatchedConfig(fullName)
                if configData then
                    NotifiedLots[lotId] = true -- Mark immediately to prevent duplicate requests
                    sendMentionWebhook(lotData, configData)
                end
            end
        end
    end

    -- 2. Clean up cache (Remove items no longer visible)
    for lotId in pairs(AuctionLots) do
        if not currentVisibleLots[lotId] then
            AuctionLots[lotId] = nil
            NotifiedLots[lotId] = nil 
        end
    end
end

-- ========================================================================
-- EVENT-DRIVEN UI WATCHER
-- ========================================================================

-- Debounced scan trigger to prevent CPU spikes from rapid simultaneous UI events
local function queueScan()
    if scanQueued then return end
    scanQueued = true
    t_delay(0.1, function()
        scanAuctionUI()
        scanQueued = false
    end)
end

-- Disconnects all active UI listeners safely to prevent memory leaks
local function disconnectUIEvents()
    for _, conn in ipairs(UIConnections) do
        if conn and typeof(conn) == "RBXScriptConnection" and conn.Connected then
            conn:Disconnect()
        end
    end
    t_clear(UIConnections)
end

-- Binds Property/Text changes to a specific UI frame dynamically
local function bindFrameEvents(frame)
    if not frame or not frame.Parent then return end

    -- Defensive execution: Only bind Visible checks if the instance is a GuiObject
    if frame:IsA("GuiObject") then
        table.insert(UIConnections, frame:GetPropertyChangedSignal("Visible"):Connect(queueScan))
    end

    if frame:IsA("TextLabel") or frame:IsA("TextBox") then
        table.insert(UIConnections, frame:GetPropertyChangedSignal("Text"):Connect(queueScan))
    end

    -- Recursively scan descendants for internal label text shifts
    for _, desc in ipairs(frame:GetDescendants()) do
        if desc:IsA("TextLabel") or desc:IsA("TextBox") then
            table.insert(UIConnections, desc:GetPropertyChangedSignal("Text"):Connect(queueScan))
        end
    end
end

-- Attaches event listeners specifically to the Auction GUI
local function attachAuctionListeners(auctionGui)
    disconnectUIEvents() -- Clear stale connections

    local frame = auctionGui:WaitForChild("Frame", 5)
    if not frame then return end
    
    local scrollFrame = frame:WaitForChild("ScrollingFrame", 5)
    local header = frame:WaitForChild("Header", 5)
    if not scrollFrame or not header then return end

    -- Detect new or removed lots
    table.insert(UIConnections, scrollFrame.ChildAdded:Connect(function(child)
        bindFrameEvents(child)
        queueScan()
    end))
    table.insert(UIConnections, scrollFrame.ChildRemoved:Connect(queueScan))

    -- Detect Header/Timer updates (Auction Refresh)
    bindFrameEvents(header)

    -- Bind existing lots
    for _, child in ipairs(scrollFrame:GetChildren()) do
        bindFrameEvents(child)
    end

    -- Trigger initial layout validation pass
    queueScan()
end

-- Monitors PlayerGui for the creation/destruction of the Auction GUI
local function watchAuctionUI()
    local playerGui = player:WaitForChild("PlayerGui")

    local existingGui = playerGui:FindFirstChild("Auction")
    if existingGui then
        attachAuctionListeners(existingGui)
    end

    playerGui.ChildAdded:Connect(function(child)
        if child.Name == "Auction" then
            attachAuctionListeners(child)
        end
    end)

    playerGui.ChildRemoved:Connect(function(child)
        if child.Name == "Auction" then
            disconnectUIEvents()
            t_clear(AuctionLots)
            t_clear(NotifiedLots) 
        end
    end)
end

-- ========================================================================
-- INITIALIZATION
-- ========================================================================

watchAuctionUI()
print("[Auction Observer] Successfully initialized v4.2")