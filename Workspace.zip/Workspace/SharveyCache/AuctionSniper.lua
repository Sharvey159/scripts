-- ========================================================================
-- AUCTION OBSERVER v4.8
-- Coordinated Leader/Follower Buying System & Webhook Monitor
-- ========================================================================

local CONFIG = {
    WebhookURL = "https://discord.com/api/webhooks/1527922387146772630/qMBBvpj84LCKL_ri9wCTVCj-Habrd-4Al85USQMqj4zGDKFdLtIcA5BPFcuCjZhgzPjB",
    
    Mention = {
        Enabled = true,
        UserId = "604609802835853333"
    },

    Leader = {
        Enabled = true,
        Username = "Store_acc51"
    },

    Buy = {
        Enabled = true,
        SpamInterval = 0.5
    },
    
    Items = {
        ["Super Watering Can"] = { Enabled = true, Mention = true, BuyZone = 35 },
        ["Super Sprinkler"] = { Enabled = true, Mention = true, BuyZone = 15 },

        ["Hypno Bloom"] = { Enabled = false, Mention = false, BuyZone = 15 },
        ["Dragon's Breath"] = { Enabled = false, Mention = false, BuyZone = 15 },
        ["Venom Spitter"] = { Enabled = false, Mention = false, BuyZone = 15 },
        ["Moon Bloom"] = { Enabled = false, Mention = false, BuyZone = 10 },

        ["Ghost Pepper"] = { Enabled = false, Mention = false },
        ["Venus Flytrap"] = { Enabled = false, Mention = false },

        ["Bamboo"] = { Enabled = false, Mention = false },
        ["Mushroom"] = { Enabled = false, Mention = false },

        ["Uncommon Seed Pack"] = { Enabled = true, Mention = true, BuyZone = 250 },

        ["Bear Trap Crate"] = { Enabled = false, Mention = false },
        ["Fence Crate"] = { Enabled = false, Mention = false },
        ["Teleporter Pad Crate"] = { Enabled = false, Mention = false },
        ["Conveyor Crate"] = { Enabled = false, Mention = false },

        -- Defaults to 15 seconds automatically
        ["Common Egg"] = { Enabled = true, Mention = true, BuyZone = 45 },
    }
}

-- ========================================================================
-- COMPATIBILITY & EXECUTOR UTILITIES
-- ========================================================================

local t_unpack = table.unpack or unpack
local t_spawn = task and task.spawn or spawn

local httpRequest = request or http_request or (syn and syn.request) or (fluxus and fluxus.request)
if not httpRequest then
    warn("[Auction Observer] Warning: HTTP request API not found. Webhook capabilities disabled.")
end

-- ========================================================================
-- SERVICES & CACHE FILES
-- ========================================================================

local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local player = Players.LocalPlayer

local MSG_ID_CACHE_FILE = "auction_observer_msg_id.json"
local NOTIFIED_LOTS_CACHE_FILE = "auction_observer_notified_lots.json"
local BUY_CACHE_FILE = "auction_buy_cache.json"

local cachedMessageId = nil
local NotifiedLots = {}
local cachedScrollFrame = nil
local lastEmbedDescription = ""

-- Role Initialization
local isLeader = false
if CONFIG.Leader.Enabled then
    if player.Name == CONFIG.Leader.Username then
        isLeader = true
        print("[Auction Observer v4.8] Started as: LEADER")
    else
        print("[Auction Observer v4.8] Started as: FOLLOWER")
    end
else
    print("[Auction Observer v4.8] Leader System Disabled. Running independently.")
end

-- ========================================================================
-- HELPER & CACHE MANAGEMENT FUNCTIONS
-- ========================================================================

local function safeSpawn(contextName, func, ...)
    local args = {...}
    local n = select("#", ...)
    t_spawn(function()
        local success, err = xpcall(function()
            if n > 0 then
                func(t_unpack(args, 1, n))
            else
                func()
            end
        end, function(msg)
            return debug.traceback(tostring(msg), 2)
        end)
        
        if not success then
            warn(string.format("[Auction Observer Error - %s]:\n%s", tostring(contextName), tostring(err)))
        end
    end)
end

local function normalizeString(str)
    if type(str) ~= "string" then return "" end
    str = string.lower(str)
    str = string.gsub(str, " ?%(x%d+%)", "")
    str = string.gsub(str, " x%d+", "")
    str = string.gsub(str, "%b()", "")
    str = string.gsub(str, "%b[]", "")
    str = string.gsub(str, "^%s*(.-)%s*$", "%1")
    str = string.gsub(str, "%s+", " ")
    return str
end

local function getMatchedConfig(fullName)
    local normalizedFullName = normalizeString(fullName)
    for configName, configData in pairs(CONFIG.Items) do
        if not configData.Enabled then continue end
        local normalizedConfigName = normalizeString(configName)
        if string.find(normalizedFullName, normalizedConfigName, 1, true) then
            return configData, configName
        end
    end
    return nil, nil
end

local function parseTimerToSeconds(timerText)
    if type(timerText) ~= "string" or timerText == "" then return 0 end
    local m = string.match(timerText, "(%d+)m")
    local s = string.match(timerText, "(%d+)s")
    local mins = m and tonumber(m) or 0
    local secs = s and tonumber(s) or 0
    return (mins * 60) + secs
end

-- General Persistent Handlers
local function loadJsonFile(fileName)
    if isfile and isfile(fileName) then
        local ok, content = pcall(readfile, fileName)
        if ok and content and content ~= "" then
            local okJson, data = pcall(function() return HttpService:JSONDecode(content) end)
            if okJson and type(data) == "table" then
                return data
            end
        end
    end
    return nil
end

local function saveCachedMessageId(msgId)
    if writefile then
        if msgId then
            pcall(writefile, MSG_ID_CACHE_FILE, HttpService:JSONEncode({ MessageId = msgId }))
        else
            if isfile and isfile(MSG_ID_CACHE_FILE) and delfile then
                pcall(delfile, MSG_ID_CACHE_FILE)
            end
        end
    end
end

local function saveNotifiedLotsCache()
    if writefile then
        pcall(writefile, NOTIFIED_LOTS_CACHE_FILE, HttpService:JSONEncode(NotifiedLots))
    end
end

-- Buy Cache Handlers (Updated for Multi-Item Support)
local function writeBuyCache(data)
    if not isLeader then return end
    if writefile then
        local payload = type(data) == "string" and data or HttpService:JSONEncode(data)
        pcall(writefile, BUY_CACHE_FILE, payload)
    end
end

local lastRawBuyCache = ""
local decodedBuyCache = { Items = {} }

local function readBuyCacheFast()
    if not isfile or not isfile(BUY_CACHE_FILE) then return nil end
    local ok, content = pcall(readfile, BUY_CACHE_FILE)
    if ok and content then
        if content == lastRawBuyCache then
            return decodedBuyCache
        end
        local okJson, data = pcall(function() return HttpService:JSONDecode(content) end)
        -- Validate v4.8 cache structure to prevent crashing on old v4.7 caches
        if okJson and type(data) == "table" and data.Items then
            lastRawBuyCache = content
            decodedBuyCache = data
            return data
        end
    end
    return nil
end

cachedMessageId = (loadJsonFile(MSG_ID_CACHE_FILE) or {}).MessageId
NotifiedLots = loadJsonFile(NOTIFIED_LOTS_CACHE_FILE) or {}

-- ========================================================================
-- DISCORD WEBHOOK OPERATIONS
-- ========================================================================

local function sendMentionWebhook(lotData, configData)
    if not httpRequest or not CONFIG.WebhookURL or CONFIG.WebhookURL == "" then return end

    local contentStr = ""
    if CONFIG.Mention.Enabled and configData.Mention then
        contentStr = string.format("<@%s> 🔔 **%s** detected in Lot %d!", CONFIG.Mention.UserId, lotData.ItemName, lotData.LotNumber)
    else
        contentStr = string.format("🔔 **%s** detected in Lot %d!", lotData.ItemName, lotData.LotNumber)
    end

    local payload = {
        content = contentStr,
        allowed_mentions = { parse = {"users"}, users = { CONFIG.Mention.UserId } } 
    }

    safeSpawn("Notification Webhook Dispatch", function()
        httpRequest({ Url = CONFIG.WebhookURL, Method = "POST", Headers = { ["Content-Type"] = "application/json" }, Body = HttpService:JSONEncode(payload) })
    end)
end

local function buildEmbedDescription(lots)
    if not lots or #lots == 0 then return "No active auction lots." end
    local lines = {}
    for _, lot in ipairs(lots) do
        table.insert(lines, string.format("🟢 Lot %d", lot.LotNumber))
        if lot.IsOccupied then
            table.insert(lines, string.format("• %s", lot.ItemName))
            table.insert(lines, string.format("• Time Remaining: %s", lot.Timer ~= "" and lot.Timer or "--"))
        else
            table.insert(lines, "• Empty")
        end
        table.insert(lines, "")
    end
    if #lines > 0 and lines[#lines] == "" then table.remove(lines, #lines) end
    return table.concat(lines, "\n")
end

local function updatePersistentEmbed(lots)
    if not httpRequest or not CONFIG.WebhookURL or CONFIG.WebhookURL == "" then return end

    local description = buildEmbedDescription(lots)
    
    if description == lastEmbedDescription then 
        return 
    end

    local baseUrl = string.gsub(CONFIG.WebhookURL, "%?.*$", "")
    local payload = {
        embeds = {{
            title = "Auction Lots",
            description = description,
            color = 5814783,
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
            footer = { text = "Auction Observer v4.8" }
        }}
    }
    local jsonBody = HttpService:JSONEncode(payload)

    if cachedMessageId then
        local response = httpRequest({ Url = baseUrl .. "/messages/" .. cachedMessageId, Method = "PATCH", Headers = { ["Content-Type"] = "application/json" }, Body = jsonBody })
        local statusCode = response and (response.StatusCode or response.Status)
        
        if statusCode and (statusCode >= 200 and statusCode < 300) then
            lastEmbedDescription = description
            return
        end
        
        cachedMessageId = nil
        saveCachedMessageId(nil)
    end

    local response = httpRequest({ Url = baseUrl .. "?wait=true", Method = "POST", Headers = { ["Content-Type"] = "application/json" }, Body = jsonBody })
    
    if response and response.Body then
        local okJson, resData = pcall(function() return HttpService:JSONDecode(response.Body) end)
        if okJson and type(resData) == "table" and resData.id then
            cachedMessageId = tostring(resData.id)
            saveCachedMessageId(cachedMessageId)
            lastEmbedDescription = description
        end
    end
end

-- ========================================================================
-- UI SCANNING & BUY LOGIC
-- ========================================================================

local function getScrollFrame()
    if cachedScrollFrame and cachedScrollFrame.Parent and cachedScrollFrame:IsDescendantOf(game) then
        return cachedScrollFrame
    end
    
    local playerGui = player:FindFirstChild("PlayerGui")
    local scrollFrame = playerGui and playerGui:FindFirstChild("Auction") and playerGui.Auction:FindFirstChild("Frame") and playerGui.Auction.Frame:FindFirstChild("ScrollingFrame")
    
    if scrollFrame then cachedScrollFrame = scrollFrame end
    return cachedScrollFrame
end

local function parseLotFrame(lotFrame)
    local mainFrame = lotFrame:FindFirstChild("Frame") and lotFrame.Frame:FindFirstChild("Main_Frame") or lotFrame:FindFirstChild("Main_Frame")
    if not mainFrame then return false, "", "" end

    local itemNameObj = mainFrame:FindFirstChild("ItemName")
    local refreshIn = mainFrame:FindFirstChild("RefreshIn")
    local timerObj = refreshIn and (refreshIn:FindFirstChild("Timer") or refreshIn)

    local outOfStock = mainFrame:FindFirstChild("OUT_OF_STOCK")
    local expired = mainFrame:FindFirstChild("EXPIRED")

    local isOutOfStock = outOfStock and outOfStock.Visible
    local isExpired = expired and expired.Visible

    local itemName = ""
    local isOccupied = false

    if itemNameObj and (itemNameObj:IsA("TextLabel") or itemNameObj:IsA("TextBox")) then
        local textVal = itemNameObj.Text
        if textVal ~= "" and textVal ~= "Empty" and not isOutOfStock and not isExpired then
            itemName = textVal
            isOccupied = true
        end
    end

    local timerText = ""
    if timerObj and (timerObj:IsA("TextLabel") or timerObj:IsA("TextBox")) then
        timerText = string.gsub(timerObj.Text, "^Refresh in%s*", "")
    end

    return isOccupied, itemName, timerText
end

local function scanAuctionUI()
    local scrollFrame = getScrollFrame()
    if not scrollFrame then 
        print("[Debug] scanAuctionUI: ScrollFrame not found!")
        return {}, {} 
    end

    local scannedLots = {}
    local currentVisibleLotIds = {}
    local foundTargets = {} -- Now collects ALL active valid targets

    for _, lotFrame in ipairs(scrollFrame:GetChildren()) do
        if lotFrame:IsA("Frame") and lotFrame.Visible and string.sub(lotFrame.Name, 1, 4) == "Lot_" then
            local lotId = lotFrame.Name
            local lotNum = tonumber(string.match(lotId, "%d+")) or 0
            
            local isOccupied, itemName, timerText = parseLotFrame(lotFrame)

            local lotData = { LotId = lotId, LotNumber = lotNum, IsOccupied = isOccupied, ItemName = itemName, Timer = timerText }
            table.insert(scannedLots, lotData)
            currentVisibleLotIds[lotId] = true

            if isOccupied then
                local configData, configName = getMatchedConfig(itemName)
                if configData then
                    if not NotifiedLots[lotId] then
                        NotifiedLots[lotId] = true
                        saveNotifiedLotsCache()
                        sendMentionWebhook(lotData, configData)
                    end
                    
                    -- Record every enabled target discovered
                    if configData.Enabled then
                        foundTargets[lotId] = itemName
                    end
                end
            end
        end
    end

    local cacheChanged = false
    for lotId in pairs(NotifiedLots) do
        if not currentVisibleLotIds[lotId] then
            NotifiedLots[lotId] = nil
            cacheChanged = true
        end
    end
    if cacheChanged then saveNotifiedLotsCache() end

    table.sort(scannedLots, function(a, b) return a.LotNumber < b.LotNumber end)
    return scannedLots, foundTargets
end

-- ========================================================================
-- FOLLOWER BUY WORKERS
-- ========================================================================

local activeBuyRoutines = {}
local currentCacheState = { Items = {} }

local function clickGuiButton(btn)
    if not btn then return end
    pcall(function()
        if firesignal then
            firesignal(btn.MouseButton1Down)
            firesignal(btn.MouseButton1Up)
            firesignal(btn.MouseButton1Click)
            firesignal(btn.Activated)
        elseif getconnections then
            for _, conn in ipairs(getconnections(btn.MouseButton1Click)) do conn:Fire() end
            for _, conn in ipairs(getconnections(btn.Activated)) do conn:Fire() end
        end
    end)
end

local function getLotFrameByItemName(targetName)
    local scroll = getScrollFrame()
    if not scroll then return nil end
    for _, lotFrame in ipairs(scroll:GetChildren()) do
        if lotFrame:IsA("Frame") and lotFrame.Visible and string.sub(lotFrame.Name, 1, 4) == "Lot_" then
            local isOccupied, itemName, _ = parseLotFrame(lotFrame)
            if isOccupied and normalizeString(itemName) == normalizeString(targetName) then
                local mainFrame = lotFrame:FindFirstChild("Frame") and lotFrame.Frame:FindFirstChild("Main_Frame") or lotFrame:FindFirstChild("Main_Frame")
                return lotFrame, mainFrame
            end
        end
    end
    return nil
end

local function startSpamBuyRoutine(targetName)
    if activeBuyRoutines[targetName] then return end
    activeBuyRoutines[targetName] = true
    print("[Debug] Starting Independent Buy Routine for: " .. tostring(targetName))

    safeSpawn("Buy Routine - " .. targetName, function()
        while true do
            -- Cache is the ultimate authority for execution
            local itemCache = currentCacheState.Items and currentCacheState.Items[targetName]
            if not itemCache or not itemCache.Buy then 
                print("[Debug] Stopping Buy Routine for: " .. tostring(targetName) .. " (Cache state changed)")
                break 
            end

            -- Worker interacts only with its own target
            local lotFrame, mainFrame = getLotFrameByItemName(targetName)
            if lotFrame and mainFrame then
                local buyBtn = mainFrame:FindFirstChildWhichIsA("GuiButton", true) or lotFrame:FindFirstChildWhichIsA("GuiButton", true)
                if buyBtn then clickGuiButton(buyBtn) end
            end
            
            task.wait(CONFIG.Buy.SpamInterval)
        end
        
        activeBuyRoutines[targetName] = false
    end)
end

safeSpawn("Shared Cache Monitor", function()
    while true do
        task.wait(0.1)
        if not CONFIG.Leader.Enabled or not CONFIG.Buy.Enabled then 
            task.wait(1) 
            continue 
        end
        
        local cache = readBuyCacheFast()
        if cache and cache.Items then
            currentCacheState = cache
            
            -- Spawn workers for every active item in the shared cache concurrently
            for itemName, itemData in pairs(cache.Items) do
                if itemData.Buy then
                    local confData, _ = getMatchedConfig(itemName)
                    if confData and confData.Enabled then
                        startSpamBuyRoutine(itemName)
                    end
                end
            end
        end
    end
end)

-- ========================================================================
-- MAIN SCANNING LOOP (Leader Only if Configured)
-- ========================================================================

safeSpawn("Auction Monitor Core", function()
    local embedTimer = 0
    local lastScannedLots = {}
    local activeTargets = {} -- Track all concurrent targets
    local lastCacheStateStr = ""

    if not CONFIG.Leader.Enabled or isLeader then
        local success, lots, initTargets = pcall(scanAuctionUI)
        if success and lots then 
            lastScannedLots = lots 
            if initTargets then
                for lotId, itemName in pairs(initTargets) do
                    local itemConfig = getMatchedConfig(itemName)
                    local targetBuyZone = (itemConfig and itemConfig.BuyZone) or 15
                    activeTargets[lotId] = { ItemName = itemName, BuyZone = targetBuyZone, Buy = false }
                end
            end
        end
        updatePersistentEmbed(lastScannedLots)

        while true do
            task.wait(1)

            -- 1. ALWAYS perform full UI scanning
            local success, lots, foundTargets = pcall(scanAuctionUI)
            if success and lots then 
                lastScannedLots = lots 
            else
                print("[Debug] scanAuctionUI failed or returned nil")
            end

            -- 2. ALWAYS attempt to synchronize the webhook embed
            embedTimer = embedTimer + 1
            if embedTimer >= 5 then
                embedTimer = 0
                safeSpawn("Persistent Embed Sync", function()
                    updatePersistentEmbed(lastScannedLots)
                end)
            end

            -- Rebuild the multi-item cache state each cycle
            local newCache = { Items = {} }

            -- 3. Multi-Target Monitoring (Independent Lifecycles)
            local scrollFrame = getScrollFrame()
            for lotId, targetInfo in pairs(activeTargets) do
                local lotFrame = scrollFrame and scrollFrame:FindFirstChild(lotId)
                local keepTarget = false

                if lotFrame then
                    local isOccupied, itemName, timerText = parseLotFrame(lotFrame)
                    
                    if isOccupied and normalizeString(itemName) == normalizeString(targetInfo.ItemName) then
                        keepTarget = true
                        local remainingSecs = parseTimerToSeconds(timerText)
                        
                        -- Set Independent BuyZone
                        if remainingSecs <= targetInfo.BuyZone then
                            targetInfo.Buy = true
                        else
                            targetInfo.Buy = false
                        end
                        print(string.format("[Debug] Monitoring %s (Lot: %s) | Time: %ds | BuyZone: %ds | Buy: %s", targetInfo.ItemName, lotId, remainingSecs, targetInfo.BuyZone, tostring(targetInfo.Buy)))
                    end
                end

                if keepTarget then
                    -- If multiple lots contain the same item, 'Buy' becomes true if ANY of them are within the zone
                    if not newCache.Items[targetInfo.ItemName] then
                        newCache.Items[targetInfo.ItemName] = { Buy = targetInfo.Buy }
                    else
                        newCache.Items[targetInfo.ItemName].Buy = newCache.Items[targetInfo.ItemName].Buy or targetInfo.Buy
                    end
                else
                    print("[Debug] Target lost (expired, empty, or swapped): " .. targetInfo.ItemName .. " (Lot: " .. lotId .. ")")
                    activeTargets[lotId] = nil
                end
            end
            
            -- 4. Target Acquisition (Continuously discover newly active valid lots)
            if foundTargets then
                for lotId, itemName in pairs(foundTargets) do
                    if not activeTargets[lotId] then
                        print("[Debug] Target acquired: " .. tostring(itemName) .. " (Lot: " .. tostring(lotId) .. ")")
                        local itemConfig = getMatchedConfig(itemName)
                        local targetBuyZone = (itemConfig and itemConfig.BuyZone) or 15
                        
                        activeTargets[lotId] = {
                            ItemName = itemName,
                            BuyZone = targetBuyZone,
                            Buy = false
                        }
                        
                        if not newCache.Items[itemName] then
                            newCache.Items[itemName] = { Buy = false }
                        end
                    end
                end
            end
            
            -- 5. Broadcast Multi-Item Cache
            local cachePayloadStr = HttpService:JSONEncode(newCache)
            if cachePayloadStr ~= lastCacheStateStr then
                writeBuyCache(cachePayloadStr)
                lastCacheStateStr = cachePayloadStr
            end
        end
    end
end)

print("[Auction Observer] Successfully initialized v4.8")