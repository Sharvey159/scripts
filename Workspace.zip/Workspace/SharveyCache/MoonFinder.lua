--[[
=============================================================================
Script Version: v92 (Eclipse Automation Overhaul)
Description: Advanced Auto-Farm with Independent Event Detection, Safe Sweeps, Live Analytics Dashboard, Weight Buckets, Webhook Message Editing, & Automatic Eclipse Controller
Architecture: True Producer-Consumer FIFO Shared Queue Engine (O(1) Execution)
=============================================================================
]]

if not game:IsLoaded() then
    game.Loaded:Wait()
end

task.wait(10)

-- ============================================================================
-- ⚙️ MAIN CONFIGURATION
-- ============================================================================
local USER_CONFIG = {

    -- ==========================================
    -- [ GENERAL ]
    -- ==========================================
    DebugMode = false,

    -- ==========================================
    -- [ PLAYER MOVEMENT & NOCLIP ]
    -- ==========================================
    WalkSpeed = 30,
    EnableNoClip = true,

    -- ==========================================
    -- [ WEBHOOKS ]
    -- ==========================================
    DashboardWebhook = "https://discord.com/api/webhooks/1520269449251262494/kIdsK1mVMEVqvZblghzbB7NSIMF4KF9NB13phNN0eAqYFsoeymHaYIkWEoJFKTOiVjBj",
    WeatherWebhook = "https://discord.com/api/webhooks/1520090710290731101/wBfz1Eg2q2nvSNMBYKeu0ivklrMD-7DtKpLa5zHShJbj6-Js2cfBIP_ynFrQkd9ZprYD",
    PhaseWebhook = "https://discord.com/api/webhooks/1521577385122730205/4SCZjVoN91ZuCHDoQiZxTiA20X3lIefGWuPJ4Q1aQmY8OxAHs5etNv1LzcEapytl5H8w",

    -- ==========================================
    -- [ DISCORD IDS & ROLES ]
    -- ==========================================
    MyUserId = "604609802835853333",
    BloodMoonRole = "1521573894383861851",
    SunburstRole = "1522844669027815426",

    -- ==========================================
    -- [ AUTO FARM & MAINTENANCE ]
    -- ==========================================
    DefaultKeptFruitLimit = 300,
    DefaultAutoMaintenance = false,

    -- ==========================================
    -- [ EVENTS ]
    -- ==========================================
    EnableEventAutoCleanup = false,

    -- ==========================================
    -- [ HARVEST & SHOVEL ENGINE DELAYS ]
    -- ==========================================
    HarvestInterval = 0.11,
    ShovelInterval = 0.65,
    VerificationDelay = 1.0,

    -- ==========================================
    -- [ SPRINKLERS & WATERING SETTINGS ]
    -- ==========================================
    SprinklerRadius = 4,
    SprinklerPlaceDelay = 0.5,
    SprinklerTypes = { "Common Sprinkler", "Uncommon Sprinkler", "Rare Sprinkler", "Legendary Sprinkler" },
    SuperSprinklerName = "Super Sprinkler",
    WateringCanName = "Super Watering Can",
    ShovelName = "Shovel",

    -- ==========================================
    -- [ TRASH MANAGER ]
    -- ==========================================
    TrashRemoveDelay = 0.5,
    TrashPlaceDelay = 0.5,

    -- ==========================================
    -- [ WEIGHT THRESHOLDS (DYNAMIC) ]
    -- ==========================================
    DynamicPhase1Limit = 100,
    Phase1TargetWeight = 70,
    Phase2TargetWeight = 70,

    -- ==========================================
    -- [ DASHBOARD & CACHE SETTINGS ]
    -- ==========================================
    DashboardUpdateInterval = 4,
    DashboardCacheFile = "DashboardCache.json",

    -- ==========================================
    -- [ OPTIMIZATION & QUEUE LIMITS ]
    -- ==========================================
    QueueCompactionLimit = 50000,

    -- ==========================================
    -- [ WHITELIST (ALLOWED FRUITS) ]
    -- ==========================================
    AllowedFruits = {
        ["Moon Bloom"] = true,
    }
}

-- ============================================================================
-- INITIALIZATION: PLAYER MOVEMENT & SMART PLANT NOCLIP
-- ============================================================================
task.spawn(function()
    local Players = game:GetService("Players")
    local player = Players.LocalPlayer

    -- 1. WalkSpeed Enforcer
    local walkSpeedConnection = nil
    local function setupCharacter(character)
        if walkSpeedConnection then
            walkSpeedConnection:Disconnect()
            walkSpeedConnection = nil
        end

        local humanoid = character:WaitForChild("Humanoid", 5)
        if humanoid then
            humanoid.WalkSpeed = USER_CONFIG.WalkSpeed
            walkSpeedConnection = humanoid:GetPropertyChangedSignal("WalkSpeed"):Connect(function()
                if humanoid.WalkSpeed ~= USER_CONFIG.WalkSpeed then
                    humanoid.WalkSpeed = USER_CONFIG.WalkSpeed
                end
            end)
        end
    end

    if player.Character then
        task.spawn(setupCharacter, player.Character)
    end
    player.CharacterAdded:Connect(setupCharacter)

    -- 2. Smart Plant NoClip + Local Transparency
    if USER_CONFIG.EnableNoClip then
        task.spawn(function()
            local myPlot
            local gardens = workspace:WaitForChild("Gardens", 10)
            if not gardens then return end

            for _, plot in ipairs(gardens:GetChildren()) do
                if plot:GetAttribute("OwnerUserId") == player.UserId then
                    myPlot = plot
                    break
                end
            end

            if not myPlot then return end

            local plantsFolder = myPlot:WaitForChild("Plants", 5)
            if not plantsFolder then return end

            local function updatePlantPart(obj)
                if obj:IsA("BasePart") then
                    obj.CanCollide = false
                    obj.LocalTransparencyModifier = 0.99
                end
            end

            for _, obj in ipairs(plantsFolder:GetDescendants()) do
                updatePlantPart(obj)
            end

            plantsFolder.DescendantAdded:Connect(updatePlantPart)
        end)
    end
end)

-- ============================================================================
-- SYSTEM INITIALIZATION
-- ============================================================================
local function IsFruitAllowed(fruitName)
    if not fruitName then return false end
    return USER_CONFIG.AllowedFruits[fruitName] == true
end

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local Workspace = game:GetService("Workspace")
local TweenService = game:GetService("TweenService")

local request = request or http_request or (syn and syn.request)
assert(request, "HTTP requests are not supported by this executor.")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local FruitVisualizerController = require(player:WaitForChild("PlayerScripts"):WaitForChild("Controllers"):WaitForChild("FruitVisualizerController"))
local Networking = require(ReplicatedStorage:WaitForChild("SharedModules"):WaitForChild("Networking"))

local myPlot
for _, plot in ipairs(workspace.Gardens:GetChildren()) do
    if plot:GetAttribute("OwnerUserId") == player.UserId then
        myPlot = plot
        break
    end
end

if not myPlot then return warn("Couldn't find your plot!") end
local myPlotId = tonumber(myPlot.Name:match("%d+")) or 0

local isAutoFarming = false
local isAutoMaintenance = USER_CONFIG.DefaultAutoMaintenance
local isAutoSelling = false
local isScriptRunning = true
local isMaintaining = false
local isEventActive = false
local targetKeptLimit = USER_CONFIG.DefaultKeptFruitLimit
local notifiedLimitReached = false
local triggerDashboardUpdate = false

-- ECLIPSE BLOOM AUTOMATION STATE
local isAutoEclipseActive = false
local eclipseAutomationStartTime = 0
local eclipseEventsTriggered = 0
local GlobalEclipseState = {
    Total = 0, Waiting = 0, Growing = 0, Ready = 0,
    OldestReady = nil, Youngest = nil, LastScan = 0, LastUpdate = 0
}

local weightFilterInput 

-- ============================================================================
-- LIVE ANALYTICS DATA STRUCTURES
-- ============================================================================
local sessionStart = os.time()
local totalHarvested, totalShoveled, totalCycles = 0, 0, 0
local keptFruitTimestamps, cycleHistory = {}, {}
local dashboardTextBuffer = {} 
local cycleStartTime = os.time()

local function loadDashboardCache()
    if isfile and isfile(USER_CONFIG.DashboardCacheFile) then
        local success, content = pcall(function()
            return HttpService:JSONDecode(readfile(USER_CONFIG.DashboardCacheFile))
        end)
        if success and type(content) == "table" then return content end
    end
    return {}
end

local function saveDashboardCache(cache)
    if writefile then
        pcall(function() writefile(USER_CONFIG.DashboardCacheFile, HttpService:JSONEncode(cache)) end)
    end
end

local dashboardCache = loadDashboardCache()
local dashboardMessageId = dashboardCache[player.Name]

if type(dashboardCache.EclipseBlooms) ~= "table" then
    dashboardCache.EclipseBlooms = {}
end

local function createQueue()
    return {
        items = {}, first = 1, last = 0, size = 0,
        inQueue = {}, 
        push = function(self, item) 
            if not item then return end
            local key = item.FruitId or item.Id
            if key and self.inQueue[key] then return end
            
            self.last += 1
            self.items[self.last] = item 
            self.size += 1
            if key then self.inQueue[key] = true end
        end,
        pop = function(self)
            if self.size == 0 then return nil end
          
            while self.first <= self.last and self.items[self.first] == nil do self.first += 1 end
            if self.first > self.last then return nil end
            
            local val = self.items[self.first]
            self.items[self.first] = nil
            self.size -= 1
            
            if val then
                local key = val.FruitId or val.Id
                if key then self.inQueue[key] = nil end
            end
            
            if self.first > USER_CONFIG.QueueCompactionLimit then
                local newItems = {}
                local index = 1
                for i = self.first, self.last do
                    if self.items[i] ~= nil then
                        newItems[index] = self.items[i]
                        index += 1
                    end
                end
           
                self.items = newItems
                self.first = 1
                self.last = index - 1
            end
            
            return val
        end,
        count = function(self) return self.size end
    }
end
       
local plantLookupCache = {}
local plantConnections, keptFruitCache, keptFruitList, pendingVerification = {}, {}, {}, {}
local fruitProcessingQueue, sharedActionQueue, webhookQueue = createQueue(), createQueue(), createQueue() 
local keptCount = 0           

-- ============================================================================
-- FILTER PARSING FUNCTIONS
-- ============================================================================
local function ParseWeightCondition(text)
    if not text then return false, nil, nil end
    text = tostring(text):gsub("%s+", "")
    if text == "" then return false, nil, nil end
    
    local op, valStr = text:match("^(>=?)(%d+%.?%d*)$")
    if not op then op, valStr = text:match("^(<=?)(%d+%.?%d*)$") end
    if not op then op, valStr = text:match("^(==?)(%d+%.?%d*)$") end
    if not op then op, valStr = text:match("^(=)(%d+%.?%d*)$") end
    
    if not op then
        valStr = text:match("^(%d+%.?%d*)$")
        if valStr then op = "==" end
    end
    
    if op and valStr then
        local val = tonumber(valStr)
        if val then
            if op == "=" then op = "==" end
            return true, op, val
        end
    end
    
    return false, nil, nil
end

local function MatchesWeightCondition(weight, operator, value)
    if operator == ">" then return weight > value
    elseif operator == ">=" then return weight >= value
    elseif operator == "<" then return weight < value
    elseif operator == "<=" then return weight <= value
    elseif operator == "==" then return weight == value
    end
    return false
end

-- ============================================================================
-- CORE FUNCTIONS & MEMORY RESOLUTION
-- ============================================================================
local function resolveFruitInstance(plantId, fruitId)
    if not plantId or not fruitId then return nil end
    
    local plant = plantLookupCache[plantId]
    
    if not plant or plant.Parent == nil then
        plant = nil
        for _, p in ipairs(myPlot.Plants:GetChildren()) do
            local pId = p:GetAttribute("PlantId") or p.Name
            if pId == plantId then
                plant = p
                plantLookupCache[plantId] = p
                break
            end
        end
    end
    
    if not plant then return nil end
    local fruitsFolder = plant:FindFirstChild("Fruits")
    if not fruitsFolder then return nil end
    
    for _, f in ipairs(fruitsFolder:GetChildren()) do
        if f:GetAttribute("FruitId") == fruitId then return f end
    end
    return nil
end

local FPSOptimizer = {}
function FPSOptimizer.Optimize(instance)
    if not instance then return end
    if instance:IsA("BasePart") and (string.match(string.lower(instance.Name), "harvest") or instance:FindFirstChildWhichIsA("ProximityPrompt") or instance:FindFirstChildWhichIsA("TouchTransmitter")) then return end
    if instance:IsA("Decal") or instance:IsA("Texture") or instance:IsA("ParticleEmitter") then instance:Destroy() end
    for _, child in ipairs(instance:GetChildren()) do FPSOptimizer.Optimize(child) end
end

local function runGlobalOptimizationSweep()
    task.spawn(function()
        local gardens = Workspace:FindFirstChild("Gardens")
        if not gardens then return end
        
        for _, plot in ipairs(gardens:GetChildren()) do
            local plantsFolder = plot:FindFirstChild("Plants")
            if plantsFolder then
                for _, plant in ipairs(plantsFolder:GetChildren()) do 
                    FPSOptimizer.Optimize(plant) 
                end
            end
        end
    end)
end

local function getCharacter() return player.Character or player.CharacterAdded:Wait() end

local cachedShovelInstance = nil
local function getShovelTool()
    local char = player.Character
    if not char then return nil end
    if cachedShovelInstance and cachedShovelInstance.Parent == char then return cachedShovelInstance end
    local tool = char:FindFirstChild(USER_CONFIG.ShovelName) or player.Backpack:FindFirstChild(USER_CONFIG.ShovelName)
    if tool then
        local humanoid = char:FindFirstChildOfClass("Humanoid")
        if humanoid then 
            humanoid:EquipTool(tool)
            cachedShovelInstance = tool 
            return tool 
        end
    end
    return nil
end

local function equipTool(toolName)
    local char = getCharacter()
    local tool = player.Backpack:FindFirstChild(toolName) or char:FindFirstChild(toolName)
    if not tool then return nil end
    if tool.Parent ~= char then
        local humanoid = char:FindFirstChild("Humanoid")
        if humanoid then humanoid:EquipTool(tool) end
        local deadline = tick() + 2
        repeat task.wait() until tool.Parent == char or tick() > deadline
        task.wait(0.1)
    end
    return tool
end

local function getPlantPosition(plant)
    if not plant then return nil end
    if plant:IsA("Model") and plant.PrimaryPart then return plant.PrimaryPart.Position end
    local ok, pivot = pcall(function() return plant:GetPivot() end)
    if ok and pivot then return pivot.Position end
    if plant:IsA("BasePart") then return plant.Position end
    for _, child in ipairs(plant:GetDescendants()) do
        if child:IsA("BasePart") then return child.Position end
    end
    return nil
end

local function getFirstAvailablePlant()
    local plantsFolder = myPlot:FindFirstChild("Plants")
    if not plantsFolder then return nil end
    local plants = plantsFolder:GetChildren()
    for _, plant in ipairs(plants) do
        if getPlantPosition(plant) then return plant end
    end
    return plants[1]
end

local function getPlayerGroundHeight()
    local char = getCharacter()
    local root = char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart
    if not root then return 0 end
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = { char }
    local result = workspace:Raycast(root.Position, Vector3.new(0, -100, 0), params)
    return result and result.Position.Y or root.Position.Y
end

-- ============================================================================
-- STATE TRACKING & DASHBOARD UPDATES
-- ============================================================================
local function getCurrentFarmState()
    if isEventActive and USER_CONFIG.EnableEventAutoCleanup then return "Event Cleanup Active!" end
    if not isAutoFarming then return "Idle (Paused)" end
    if isMaintaining then return "Fixing Sprinklers & Watering..." end
    if fruitProcessingQueue:count() > 0 then return string.format("Processing Fruits (%d)", fruitProcessingQueue:count()) end
    if sharedActionQueue:count() > 0 then return "Clearing Trash Fruits..." end
    return "Running in background..."
end

local function updateAnalyticsDashboard(latestFruitsText)
    local now = os.time()
    local runtime = now - sessionStart

    while #keptFruitTimestamps > 0 and (now - keptFruitTimestamps[1] > 300) do
        table.remove(keptFruitTimestamps, 1)
    end
    local fruitsInFiveMins = #keptFruitTimestamps
   
    local avgCycle = 0
    if #cycleHistory > 0 then
        local sum = 0
        for _, d in ipairs(cycleHistory) do sum += d end
        avgCycle = sum / #cycleHistory
    end
   
    local hourlyRate = runtime > 0 and (keptCount / (runtime / 3600)) or 0
    
    local buckets = {}
    for _, f in ipairs(keptFruitList) do
        local lower = math.floor(f.Weight / 20) * 20
        if lower < 100 then lower = 100 end 
        
        if not buckets[lower] then buckets[lower] = { total = 0, recent = 0 } end
        buckets[lower].total += 1
     
        if not f.IsBaseline and (now - f.Timestamp <= 1800) then 
            buckets[lower].recent += 1
        end
    end
    
    local bucketKeys = {}
    for k in pairs(buckets) do table.insert(bucketKeys, k) end
    table.sort(bucketKeys)
    
    local bucketString = ""
    for _, lower in ipairs(bucketKeys) do
        local bData = buckets[lower]
        local recentStr = bData.recent > 0 and string.format(" *(+%d in last 30m)*", bData.recent) or ""
        bucketString = bucketString .. string.format("• **%dkg - %dkg:** %dx%s\n", lower, lower + 20, bData.total, recentStr)
    end
    if bucketString == "" then bucketString = "• *Awaiting high-yield fruits...*\n" end

    -- Eclipse Bloom Dashboard Section
    local eclipseText = ""
    if GlobalEclipseState.LastScan > 0 then
        local oldestStr = "None"
        local youngestStr = "None"

        if GlobalEclipseState.OldestReady and dashboardCache.EclipseBlooms[GlobalEclipseState.OldestReady] then
            local oData = dashboardCache.EclipseBlooms[GlobalEclipseState.OldestReady]
            oldestStr = string.format("Age: %d / %d", oData.Age, oData.MaxAge)
        end

        if GlobalEclipseState.Youngest and dashboardCache.EclipseBlooms[GlobalEclipseState.Youngest] then
            local yData = dashboardCache.EclipseBlooms[GlobalEclipseState.Youngest]
            youngestStr = string.format("Age: %d / %d", yData.Age, yData.MaxAge)
        end

        eclipseText = string.format(
            "\n\n🌘 **Eclipse Bloom**\n\n" ..
            "Ready: %d\n" ..
            "Growing: %d\n" ..
            "Waiting: %d\n\n" ..
            "**Oldest Ready**\n%s\n\n" ..
            "**Youngest**\n%s\n\n" ..
            "**Last Scan**\n%s",
            GlobalEclipseState.Ready, GlobalEclipseState.Growing, GlobalEclipseState.Waiting,
            oldestStr, youngestStr, os.date("%I:%M:%S %p", GlobalEclipseState.LastScan)
        )
    end

    local embedDescription = string.format(
        "📊 **Live Farm Session Metrics**\n" ..
        "━━━━━━━━━━━━━━━━━━━━━━━━━\n" ..
        "⏱️ **Started:** <t:%d:R>\n" ..
        "🚜 **Status:** %s\n" ..
        "🌍 **World:** %s (%s)\n\n" ..
        "📈 **Performance Analytics:**\n" ..
        "• **Total Farming Cycles:** %d\n" ..
        "• **Avg Cycle (Last 100):** %.2fs\n" ..
        "• **Kept Fruits (Last 5m):** %d\n" ..
        "• **Estimated Yield:** %.2f kept/hr\n\n" ..
        "⚖️ **Yield Buckets (>= 100kg):**\n" ..
        "%s\n" ..
        "━━━━━━━━━━━━━━━━━━━━━━━━━\n" ..
        "📋 **Latest Drops:**\n%s%s",
        sessionStart,
        getCurrentFarmState(),
        Workspace:GetAttribute("ActivePhase") or "Unknown", Workspace:GetAttribute("ActiveWeather") or "None",
        totalCycles, avgCycle, fruitsInFiveMins, hourlyRate,
        bucketString,
        (latestFruitsText and latestFruitsText ~= "") and latestFruitsText or "*Waiting for items...*",
        eclipseText
    )

    local payload = {
        embeds = {{
            title = "⚡ Live Session Dashboard (v92)",
            description = embedDescription,
            color = 3447003,
            timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }}
    }

    if not dashboardMessageId then
        local postUrl = USER_CONFIG.DashboardWebhook .. (string.find(USER_CONFIG.DashboardWebhook, "?") and "&wait=true" or "?wait=true")
        pcall(function()
            local response = request({ Url = postUrl, Method = "POST", Headers = { ["Content-Type"] = "application/json" }, Body = HttpService:JSONEncode(payload) })
            if response and response.StatusCode == 200 then
                local data = HttpService:JSONDecode(response.Body)
                if data and data.id then 
                    dashboardMessageId = data.id 
                    dashboardCache[player.Name] = dashboardMessageId
                    saveDashboardCache(dashboardCache)
                end
            end
        end)
    else
        pcall(function()
            local response = request({ Url = string.format("%s/messages/%s", USER_CONFIG.DashboardWebhook, dashboardMessageId), Method = "PATCH", Headers = { ["Content-Type"] = "application/json" }, Body = HttpService:JSONEncode(payload) })
            if response and response.StatusCode == 404 then
                dashboardMessageId = nil
                dashboardCache[player.Name] = nil
                saveDashboardCache(dashboardCache)
            end
        end)
    end
end

-- ============================================================================
-- WEBHOOK HELPER & MAINTENANCE
-- ============================================================================
local systemWebhookQueue = {}
local function sendWebhook(url, title, body, color, mention)
    table.insert(systemWebhookQueue, {url = url, title = title, body = body, color = color, mention = mention})
end

task.spawn(function()
    while isScriptRunning do
        if #systemWebhookQueue > 0 then
            local hook = table.remove(systemWebhookQueue, 1)
            pcall(function()
                request({
                    Url = hook.url, Method = "POST", Headers = { ["Content-Type"] = "application/json" },
                    Body = HttpService:JSONEncode({
                        content = hook.mention or "", 
                        allowed_mentions = { parse = { "users", "roles" } },
                        embeds = {{ title = hook.title, description = hook.body, color = hook.color or 3447003, timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ") }},
                    }),
                })
            end)
        end
        task.wait(0.2)
    end
end)

local function placeSprinklerAt(position, sprinklerName, plotId)
    local tool = equipTool(sprinklerName)
    if not tool then return false end
    pcall(function() Networking.Place.PlaceSprinkler:Fire(position, sprinklerName, tool, plotId) end)
    return true
end

local lockedSprinklerSlots = {}      
local searchingSprinklerSlots = {}   
local placementPending = {}          

local function runMaintenanceCycle()
    local sprinklersFolder = myPlot:FindFirstChild("Sprinklers")
    local targetPlant = getFirstAvailablePlant()
    local plantPos = targetPlant and getPlantPosition(targetPlant)
    if not sprinklersFolder or not plantPos then return end
    
    local centerPosition = Vector3.new(plantPos.X, getPlayerGroundHeight(), plantPos.Z)

    local activeSprinklers = {}
    for _, s in ipairs(sprinklersFolder:GetChildren()) do
        local sName = s:GetAttribute("SprinklerName") or s.Name
        if sName then 
            activeSprinklers[sName] = true 
            if placementPending[sName] and searchingSprinklerSlots[sName] then
                lockedSprinklerSlots[sName] = searchingSprinklerSlots[sName]
                placementPending[sName] = false
            end
        end
    end

    local char = getCharacter()
    local ownsSuper = player.Backpack:FindFirstChild(USER_CONFIG.SuperSprinklerName) or (char and char:FindFirstChild(USER_CONFIG.SuperSprinklerName))

    local missingSprinklers = {}
    if ownsSuper then
        if not activeSprinklers[USER_CONFIG.SuperSprinklerName] then table.insert(missingSprinklers, USER_CONFIG.SuperSprinklerName) end
    else
        for _, sType in ipairs(USER_CONFIG.SprinklerTypes) do
            if not activeSprinklers[sType] then table.insert(missingSprinklers, sType) end
        end
    end

    for _, missingType in ipairs(missingSprinklers) do
        local fixedIndex = (missingType == USER_CONFIG.SuperSprinklerName) and 1 or (table.find(USER_CONFIG.SprinklerTypes, missingType) or 1)
        
        if not lockedSprinklerSlots[missingType] then
            if placementPending[missingType] then
                searchingSprinklerSlots[missingType] = (searchingSprinklerSlots[missingType] or fixedIndex) + 1
                if searchingSprinklerSlots[missingType] > 10 then
                    searchingSprinklerSlots[missingType] = 1 
                end
            else
                searchingSprinklerSlots[missingType] = searchingSprinklerSlots[missingType] or fixedIndex
            end
            placementPending[missingType] = true
        else
            placementPending[missingType] = true
        end
        
        local slotToUse = lockedSprinklerSlots[missingType] or searchingSprinklerSlots[missingType]
        local angle = (slotToUse - 1) * (2 * math.pi / 10)
        local radius = USER_CONFIG.SprinklerRadius 
        
        local targetPos = centerPosition + Vector3.new(math.cos(angle) * radius, 0, math.sin(angle) * radius)
        placeSprinklerAt(targetPos, missingType, myPlotId)
        task.wait(USER_CONFIG.SprinklerPlaceDelay)
    end

    local waterTool = equipTool(USER_CONFIG.WateringCanName)
    if waterTool then
        pcall(function() Networking.WateringCan.UseWateringCan:Fire(centerPosition, USER_CONFIG.WateringCanName, waterTool) end)
        task.wait(1)
        runGlobalOptimizationSweep()
        getShovelTool() 
        task.wait(3)
    end
end

-- ============================================================================
-- EVENT & PHASE WATCHERS
-- ============================================================================
local function CheckAndRunMaintenance()
    if not isMaintaining and isAutoMaintenance and isAutoFarming then
        isMaintaining = true
        task.spawn(function()
            runMaintenanceCycle()
            isMaintaining = false
        end)
    end
end

local isLeaving = false
local isEventMonitorActive = false
local isSafePhaseActive, activeWeathers = false, {}
local SAFE_WEATHER = { Eclipse = true, Rain = true, Sunburst = true, Starfall = true, Aurora = true, Rainbow = true, Lightning = true }

local function enqueueFruit(plant, fruit, isBaseline)
    task.spawn(function()
        local id = fruit:GetAttribute("FruitId")
        while not id and fruit.Parent do
            task.wait(0.1)
            id = fruit:GetAttribute("FruitId")
        end
        if id then
            local fruitName = fruit:GetAttribute("CorePartName")
            if not IsFruitAllowed(fruitName) then 
                return 
            end

            local plantId = plant:GetAttribute("PlantId") or plant.Name
            fruitProcessingQueue:push({ FruitId = id, PlantId = plantId, isBaseline = isBaseline })
        end
    end)
end

local function forceCleanupScan()
    for _, plant in ipairs(myPlot.Plants:GetChildren()) do
        local fruitsFolder = plant:FindFirstChild("Fruits")
        if fruitsFolder then
            for _, fruit in ipairs(fruitsFolder:GetChildren()) do
                enqueueFruit(plant, fruit, false)
            end
        end
    end
end

local function startEventMonitor()
    if isEventMonitorActive then return end
    isEventMonitorActive = true
    task.spawn(function()
        if USER_CONFIG.EnableEventAutoCleanup and not isAutoFarming then forceCleanupScan() end
        while isEventActive and isScriptRunning do
            task.wait(5)
        end
        isEventMonitorActive = false
    end)
end

local function executeLeave(reason, remainingSeconds, webhookUrl, mention)
    if isLeaving then return end
    isLeaving = true
    isScriptRunning = false 
    local endTime = os.time() + remainingSeconds
    sendWebhook(webhookUrl, "🚨 Avoided Event", string.format("**Event:** %s\n🚪 **Action:** Leaving Server\n📅 **Ends:** <t:%d:R>", reason, endTime), 0xE74C3C, mention)
    task.wait(15) 
    pcall(function() if player then player:Kick("Avoiding " .. reason) end end)
    task.wait(0.5)
    pcall(function() player:Destroy() end)
end

local function evaluateEventState()
    local isAnySafeWeather = false
    for wName, isActive in pairs(activeWeathers) do
        if isActive and SAFE_WEATHER[wName] then isAnySafeWeather = true break end
    end
   
    local currentlyActive = isSafePhaseActive or isAnySafeWeather
    if currentlyActive and not isEventActive then
        isEventActive = true
        startEventMonitor()
    elseif not currentlyActive and isEventActive then
        isEventActive = false
        if not isLeaving then 
            CheckAndRunMaintenance()
        end
    end
    triggerDashboardUpdate = true
end

local WeatherValues = ReplicatedStorage:WaitForChild("WeatherValues", 10)
if WeatherValues then
    local weatherConnections = {}
    
    local function handleWeatherUpdate(weatherName, isPlaying)
        if activeWeathers[weatherName] == isPlaying then return end
        activeWeathers[weatherName] = isPlaying
        
        local endTime = WeatherValues:GetAttribute(weatherName .. "_EndTime") or 0
        if isPlaying then
            if not SAFE_WEATHER[weatherName] then
                local remaining = math.max(0, endTime - os.time())
                executeLeave(weatherName, remaining, USER_CONFIG.WeatherWebhook, "<@" .. USER_CONFIG.MyUserId .. ">")
                return
            else
                local body = string.format("**Weather:** %s\n⏳ Ends: <t:%d:R>\n📅 Exact: <t:%d:F>", weatherName, endTime, endTime)
                local mention = "<@" .. USER_CONFIG.MyUserId .. ">"
                if weatherName == "Sunburst" then mention = mention .. " <@&" .. USER_CONFIG.SunburstRole .. ">" end
                sendWebhook(USER_CONFIG.WeatherWebhook, "🌦 Safe Weather Started", body, 0x00BFFF, mention)
            end
        else
            if SAFE_WEATHER[weatherName] then
                sendWebhook(USER_CONFIG.WeatherWebhook, "🌦 Safe Weather Ended", "**Weather:** " .. weatherName .. " has ended.", 0x7F8C8D, nil)
            end
        end
        evaluateEventState()
    end
    
    local function watchWeather(weatherName)
        local attr = weatherName .. "_Playing"
        if weatherConnections[attr] then return end
        
        weatherConnections[attr] = WeatherValues:GetAttributeChangedSignal(attr):Connect(function()
            handleWeatherUpdate(weatherName, WeatherValues:GetAttribute(attr) or false)
        end)
        
        if WeatherValues:GetAttribute(attr) then handleWeatherUpdate(weatherName, true) end
    end
    
    local function scanWeatherAttributes()
        for attr in pairs(WeatherValues:GetAttributes()) do
            local wName = attr:match("^(.*)_Playing$")
            if wName and typeof(WeatherValues:GetAttribute(attr)) == "boolean" then 
                watchWeather(wName) 
            end
        end
    end
    
    scanWeatherAttributes()
    task.spawn(function()
        while isScriptRunning do 
            task.wait(5) 
            scanWeatherAttributes() 
        end
    end)
end

local function isSafeMoon(w) 
    return w and (string.find(string.lower(w), "blood") or string.find(string.lower(w), "mega")) 
end
local function isSpecialMoonToAvoid(w) return w and not isSafeMoon(w) and (string.find(string.lower(w), "gold") or string.find(string.lower(w), "rainbow")) end

local lastPhase, lastWeather = nil, nil
local function checkTimeCycle()
    local phase, weather = Workspace:GetAttribute("ActivePhase"), Workspace:GetAttribute("ActiveWeather")
    if not phase or not weather or (phase == lastPhase and weather == lastWeather) then return end
    lastPhase, lastWeather = phase, weather

    if phase == "Night" then
        local specialAvoid = isSpecialMoonToAvoid(weather)
        if specialAvoid or (USER_CONFIG.DebugMode and not isSafeMoon(weather)) then
            executeLeave(specialAvoid and weather or "Normal Night", 120, USER_CONFIG.PhaseWebhook, "<@" .. USER_CONFIG.MyUserId .. ">")
            return
        end
    end

    isSafePhaseActive = (phase == "Night" and isSafeMoon(weather))
    evaluateEventState()

    local title, color, mention, icon = "🌗 Phase Changed", 0xF1C40F, nil, "🌗"
    if phase == "Day" then icon, title = "☀️", "☀️ Day Time"
    elseif phase == "Sunset" then icon, title, color = "🌇", "🌇 Sunset", 0xE67E22
    elseif phase == "Night" then
        icon = "🌙"
        if string.find(string.lower(weather), "blood") then title, color, mention = "🩸🌕 BLOOD MOON HAS BEGUN!", 0xC70039, "<@&" .. USER_CONFIG.BloodMoonRole .. ">"
        elseif string.find(string.lower(weather), "mega") then title, color = "🔵🌕 MEGA MOON HAS BEGUN!", 0x3498DB
        elseif string.find(string.lower(weather), "rainbow") then title, color = "🌈🌕 RAINBOW MOON HAS BEGUN!", 0x9B59B6
        elseif string.find(string.lower(weather), "gold") then title, color = "🟡🌕 GOLD MOON HAS BEGUN!", 0xF1C40F
        else title, color = "🌙 Night Begins", 0x2C3E50 
        end
    end
    sendWebhook(USER_CONFIG.PhaseWebhook, title, string.format("**Phase:** %s %s\n**Weather/Moon:** %s", icon, phase, weather), color, mention)
end

Workspace:GetAttributeChangedSignal("ActivePhase"):Connect(checkTimeCycle)
Workspace:GetAttributeChangedSignal("ActiveWeather"):Connect(checkTimeCycle)
if Workspace:GetAttribute("ActivePhase") then checkTimeCycle() end


-- ============================================================================
-- FRUIT PROCESSING & DYNAMIC THRESHOLD
-- ============================================================================
local function removeKeptFruitState(fruitId)
    if not fruitId then return end
    if keptFruitCache[fruitId] then
        keptFruitCache[fruitId] = nil
        keptCount -= 1
        for i, f in ipairs(keptFruitList) do
            if f.FruitId == fruitId then table.remove(keptFruitList, i) break end
        end
    end
    pendingVerification[fruitId] = nil
end

local function getDynamicThreshold(currentKept)
    local firstPhaseLimit = USER_CONFIG.DynamicPhase1Limit

    if currentKept <= firstPhaseLimit then
        return USER_CONFIG.Phase1TargetWeight
    else
        return USER_CONFIG.Phase2TargetWeight
    end
end

local function processFruit(plantId, fruitId, isBaseline)
    if not plantId or not fruitId then return false end
    local fruit = resolveFruitInstance(plantId, fruitId)
    if not fruit then return true end 
    
    local name = fruit:GetAttribute("CorePartName")
    if not name then return false end 
    
    local ok, weight = pcall(function()
        return tonumber(FruitVisualizerController:CalculateFruitWeight(fruit) or (FruitVisualizerController.CalculatePlantWeight and FruitVisualizerController:CalculatePlantWeight(fruit)) or 0)
    end)
    if not ok then weight = 0 end
    
    local fruitData = {
        PlantId = plantId, FruitId = fruitId, Name = name,
        Weight = weight, Mutation = fruit:GetAttribute("Mutation") or "None", 
        Timestamp = isBaseline and 0 or os.time(), 
        IsBaseline = isBaseline
    }

    local isKept = false
    local targetWeight = getDynamicThreshold(keptCount)
    isKept = (weight >= targetWeight)
    
    if not isKept then 
        sharedActionQueue:push(fruitData)
    else
        if not keptFruitCache[fruitId] then
            keptFruitCache[fruitId] = true
            keptCount += 1
            table.insert(keptFruitList, fruitData)
            if not isBaseline then
                table.insert(keptFruitTimestamps, os.time())
                webhookQueue:push(fruitData)
            end
        end
    end
    
    return true
end

local function setupPlant(plant)
    if plantConnections[plant] then return end
    plantConnections[plant] = {}
    
    local plantId = plant:GetAttribute("PlantId") or plant.Name
    if plantId then
        plantLookupCache[plantId] = plant
    end
    
    task.spawn(function()
        local fruitsFolder = plant:FindFirstChild("Fruits")
        if not fruitsFolder then fruitsFolder = plant:WaitForChild("Fruits", 15) end
        if not fruitsFolder then 
            local conn
            conn = plant.ChildAdded:Connect(function(child)
                if child.Name == "Fruits" then
                    conn:Disconnect()
                    setupPlant(plant)
                end
            end)
            table.insert(plantConnections[plant], conn)
            return 
        end
        
        for _, fruit in ipairs(fruitsFolder:GetChildren()) do enqueueFruit(plant, fruit, true) end
        table.insert(plantConnections[plant], fruitsFolder.ChildAdded:Connect(function(fruit) enqueueFruit(plant, fruit, false) end))
        
        table.insert(plantConnections[plant], fruitsFolder.ChildRemoved:Connect(function(fruit) 
            local id = fruit:GetAttribute("FruitId")
            if id then removeKeptFruitState(id) end 
        end))
    end)
end

local function cleanupPlant(plant)
    local plantId = plant:GetAttribute("PlantId") or plant.Name
    if plantId then
        plantLookupCache[plantId] = nil
    end

    if plantConnections[plant] then 
        for _, c in ipairs(plantConnections[plant]) do c:Disconnect() end
        plantConnections[plant] = nil 
    end
    local fFolder = plant:FindFirstChild("Fruits")
    if fFolder then 
        for _, f in ipairs(fFolder:GetChildren()) do 
            local id = f:GetAttribute("FruitId")
            if id then removeKeptFruitState(id) end 
        end 
    end
end

for _, plant in ipairs(myPlot.Plants:GetChildren()) do setupPlant(plant) end
local plantAddedConn = myPlot.Plants.ChildAdded:Connect(setupPlant)
local plantRemovedConn = myPlot.Plants.ChildRemoved:Connect(cleanupPlant)


-- ============================================================================
-- HELPER FUNCTIONS FOR PLACEMENT TRASH MANAGEMENT
-- ============================================================================
local function GetSavedFruitDataFromTool(tool)
    local attr = tool:GetAttribute("SavedFruitsFSON") or tool:GetAttribute("SavedFruitsJSON")
    if not attr then return nil end
    
    local success, decoded = pcall(function() return HttpService:JSONDecode(attr) end)
    if not success or type(decoded) ~= "table" then return nil end
    
    local fruitsData = {}
    for _, fruit in ipairs(decoded) do
        if fruit.SizeMultiplier then
            local weight = 9 * fruit.SizeMultiplier
            local name = fruit.Name or fruit.Type or fruit.FruitType 
            table.insert(fruitsData, {Weight = weight, Name = name})
        end
    end
    return fruitsData
end

local function PlantMatchesWhitelistAndWeightFilter(tool, operator, value, placeAll)
    local plantName = tool:GetAttribute("PlantName")
    if not IsFruitAllowed(plantName) then 
        return false 
    end
    
    if placeAll then return true end
    
    local fruitsData = GetSavedFruitDataFromTool(tool)
    
    if not fruitsData or #fruitsData == 0 then
        return MatchesWeightCondition(0, operator, value)
    end
    
    for _, data in ipairs(fruitsData) do
        if MatchesWeightCondition(data.Weight, operator, value) then
            return true
        end
    end
    
    return false
end

-- ============================================================================
-- ULTRA-COMPACT UI (230 x 235 Base)
-- ============================================================================
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "AdminPanel"; screenGui.ResetOnSpawn = false; screenGui.Parent = playerGui
local frame = Instance.new("Frame"); frame.Size = UDim2.fromOffset(230, 235); frame.Position = UDim2.fromScale(0.02, 0.25);
frame.BackgroundColor3 = Color3.fromRGB(35, 35, 35); frame.Active = true; frame.Draggable = true; frame.Parent = screenGui;
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 6)
local titleBar = Instance.new("Frame"); titleBar.Size = UDim2.new(1, 0, 0, 25); titleBar.BackgroundColor3 = Color3.fromRGB(45, 45, 45);
titleBar.BorderSizePixel = 0; titleBar.Parent = frame; Instance.new("UICorner", titleBar).CornerRadius = UDim.new(0, 6)

local title = Instance.new("TextLabel"); title.BackgroundTransparency = 1;
title.Size = UDim2.new(1, -50, 1, 0); title.Position = UDim2.fromOffset(8, 0); title.Font = Enum.Font.GothamBold; title.Text = "Auto-Farm v92"; title.TextSize = 12;
title.TextXAlignment = Enum.TextXAlignment.Left; title.TextColor3 = Color3.new(1, 1, 1); title.Parent = titleBar
local minimize = Instance.new("TextButton"); minimize.Size = UDim2.fromOffset(18, 18);
minimize.Position = UDim2.new(1, -40, 0, 3.5); minimize.BackgroundColor3 = Color3.fromRGB(90, 90, 90); minimize.Text = "-"; minimize.Font = Enum.Font.GothamBold;
minimize.TextColor3 = Color3.new(1, 1, 1); minimize.TextSize = 14; minimize.Parent = titleBar; Instance.new("UICorner", minimize).CornerRadius = UDim.new(0, 4)
local close = Instance.new("TextButton");
close.Size = UDim2.fromOffset(18, 18); close.Position = UDim2.new(1, -20, 0, 3.5); close.BackgroundColor3 = Color3.fromRGB(170, 50, 50); close.Text = "X";
close.Font = Enum.Font.GothamBold; close.TextColor3 = Color3.new(1, 1, 1); close.TextSize = 11; close.Parent = titleBar;
Instance.new("UICorner", close).CornerRadius = UDim.new(0, 4)

local content = Instance.new("Frame"); content.BackgroundTransparency = 1; content.Position = UDim2.fromOffset(0, 25);
content.Size = UDim2.new(1, 0, 1, -25); content.Parent = frame

-- --- TOP ROW BUTTONS ---
local autoToggleBtn = Instance.new("TextButton"); autoToggleBtn.Size = UDim2.fromOffset(24, 24);
autoToggleBtn.Position = UDim2.fromOffset(10, 6); autoToggleBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50); autoToggleBtn.Text = "▶️"; autoToggleBtn.Font = Enum.Font.GothamBold;
autoToggleBtn.TextSize = 11; autoToggleBtn.TextColor3 = Color3.new(1, 1, 1); autoToggleBtn.Parent = content;
Instance.new("UICorner", autoToggleBtn).CornerRadius = UDim.new(0, 4)

local autoMaintenanceBtn = Instance.new("TextButton")
autoMaintenanceBtn.Size = UDim2.fromOffset(24, 24)
autoMaintenanceBtn.Position = UDim2.fromOffset(39, 6)
autoMaintenanceBtn.BackgroundColor3 = isAutoMaintenance and Color3.fromRGB(50, 150, 50) or Color3.fromRGB(170, 50, 50)
autoMaintenanceBtn.Text = "🔧"
autoMaintenanceBtn.Font = Enum.Font.GothamBold
autoMaintenanceBtn.TextSize = 11
autoMaintenanceBtn.TextColor3 = Color3.new(1, 1, 1)
autoMaintenanceBtn.Parent = content
Instance.new("UICorner", autoMaintenanceBtn).CornerRadius = UDim.new(0, 4)

local autoSellBtn = Instance.new("TextButton")
autoSellBtn.Size = UDim2.fromOffset(24, 24)
autoSellBtn.Position = UDim2.fromOffset(68, 6)
autoSellBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
autoSellBtn.Text = "💰"
autoSellBtn.Font = Enum.Font.GothamBold
autoSellBtn.TextSize = 11
autoSellBtn.TextColor3 = Color3.new(1, 1, 1)
autoSellBtn.Parent = content
Instance.new("UICorner", autoSellBtn).CornerRadius = UDim.new(0, 4)

-- --- SECOND ROW BUTTONS ---
local optimizeBtn = Instance.new("TextButton");
optimizeBtn.Size = UDim2.fromOffset(24, 24);
optimizeBtn.Position = UDim2.fromOffset(10, 35); optimizeBtn.BackgroundColor3 = Color3.fromRGB(50, 100, 170);
optimizeBtn.Text = "⚡"; optimizeBtn.Font = Enum.Font.GothamBold;
optimizeBtn.TextSize = 11; optimizeBtn.TextColor3 = Color3.new(1, 1, 1); optimizeBtn.Parent = content;
Instance.new("UICorner", optimizeBtn).CornerRadius = UDim.new(0, 4)

local lockBtn = Instance.new("TextButton")
lockBtn.Size = UDim2.fromOffset(24, 24)
lockBtn.Position = UDim2.fromOffset(39, 35)
lockBtn.BackgroundColor3 = Color3.fromRGB(200, 150, 50)
lockBtn.Text = "🔒"
lockBtn.Font = Enum.Font.GothamBold
lockBtn.TextSize = 11
lockBtn.TextColor3 = Color3.new(1, 1, 1)
lockBtn.Parent = content
Instance.new("UICorner", lockBtn).CornerRadius = UDim.new(0, 4)

local unlockBtn = Instance.new("TextButton")
unlockBtn.Size = UDim2.fromOffset(24, 24)
unlockBtn.Position = UDim2.fromOffset(68, 35)
unlockBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
unlockBtn.Text = "🔓"
unlockBtn.Font = Enum.Font.GothamBold
unlockBtn.TextSize = 11
unlockBtn.TextColor3 = Color3.new(1, 1, 1)
unlockBtn.Parent = content
Instance.new("UICorner", unlockBtn).CornerRadius = UDim.new(0, 4)

-- --- THIRD ROW BUTTONS (ECLIPSE AUTOMATION) ---
local eclipseScanBtn = Instance.new("TextButton")
eclipseScanBtn.Size = UDim2.fromOffset(24, 24)
eclipseScanBtn.Position = UDim2.fromOffset(10, 64)
eclipseScanBtn.BackgroundColor3 = Color3.fromRGB(50, 100, 170)
eclipseScanBtn.Text = "🌘"
eclipseScanBtn.Font = Enum.Font.GothamBold
eclipseScanBtn.TextSize = 11
eclipseScanBtn.TextColor3 = Color3.new(1, 1, 1)
eclipseScanBtn.Parent = content
Instance.new("UICorner", eclipseScanBtn).CornerRadius = UDim.new(0, 4)

local autoEclipseBtn = Instance.new("TextButton")
autoEclipseBtn.Size = UDim2.fromOffset(24, 24)
autoEclipseBtn.Position = UDim2.fromOffset(39, 64)
autoEclipseBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)
autoEclipseBtn.Text = "⚡"
autoEclipseBtn.Font = Enum.Font.GothamBold
autoEclipseBtn.TextSize = 11
autoEclipseBtn.TextColor3 = Color3.new(1, 1, 1)
autoEclipseBtn.Parent = content
Instance.new("UICorner", autoEclipseBtn).CornerRadius = UDim.new(0, 4)


-- Compact Round Square Status Indicators (~18px)
local harvestIndicator = Instance.new("Frame")
harvestIndicator.Size = UDim2.fromOffset(16, 16)
harvestIndicator.Position = UDim2.fromOffset(172, 20)
harvestIndicator.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
harvestIndicator.Parent = content
Instance.new("UICorner", harvestIndicator).CornerRadius = UDim.new(0, 4)

local shovelIndicator = Instance.new("Frame")
shovelIndicator.Size = UDim2.fromOffset(16, 16)
shovelIndicator.Position = UDim2.fromOffset(194, 20)
shovelIndicator.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
shovelIndicator.Parent = content
Instance.new("UICorner", shovelIndicator).CornerRadius = UDim.new(0, 4)

local function createStatusLabel(yPos)
    local lbl = Instance.new("TextLabel"); lbl.Size = UDim2.new(1, -20, 0, 15);
    lbl.Position = UDim2.new(0, 10, 0, yPos); lbl.BackgroundTransparency = 1; lbl.Font = Enum.Font.GothamMedium; lbl.TextSize = 11; lbl.TextColor3 = Color3.fromRGB(220, 220, 220);
    lbl.TextXAlignment = Enum.TextXAlignment.Left; lbl.Parent = content
    return lbl
end

local stateLbl = createStatusLabel(94)
local keptLbl = createStatusLabel(110)
local trashLbl = createStatusLabel(126)

weightFilterInput = Instance.new("TextBox")
weightFilterInput.Size = UDim2.new(1, -20, 0, 22)
weightFilterInput.Position = UDim2.fromOffset(10, 146)
weightFilterInput.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
weightFilterInput.Text = ""
weightFilterInput.PlaceholderText = "Weight Filter (e.g., >=100)"
weightFilterInput.Font = Enum.Font.GothamMedium
weightFilterInput.TextSize = 11
weightFilterInput.TextColor3 = Color3.new(1, 1, 1)
weightFilterInput.Parent = content
Instance.new("UICorner", weightFilterInput).CornerRadius = UDim.new(0, 4)

-- --- BOTTOM ROW BUTTONS ---
local removeTrashBtn = Instance.new("TextButton")
removeTrashBtn.Size = UDim2.fromOffset(102, 24)
removeTrashBtn.Position = UDim2.fromOffset(10, 173)
removeTrashBtn.BackgroundColor3 = Color3.fromRGB(170, 100, 50)
removeTrashBtn.Text = "🗑️"
removeTrashBtn.Font = Enum.Font.GothamBold
removeTrashBtn.TextSize = 11
removeTrashBtn.TextColor3 = Color3.new(1, 1, 1)
removeTrashBtn.Parent = content
Instance.new("UICorner", removeTrashBtn).CornerRadius = UDim.new(0, 4)

local placeTrashBtn = Instance.new("TextButton")
placeTrashBtn.Size = UDim2.fromOffset(102, 24)
placeTrashBtn.Position = UDim2.fromOffset(118, 173)
placeTrashBtn.BackgroundColor3 = Color3.fromRGB(50, 100, 170)
placeTrashBtn.Text = "📦"
placeTrashBtn.Font = Enum.Font.GothamBold
placeTrashBtn.TextSize = 11
placeTrashBtn.TextColor3 = Color3.new(1, 1, 1)
placeTrashBtn.Parent = content
Instance.new("UICorner", placeTrashBtn).CornerRadius = UDim.new(0, 4)

local trashState = {
    removeActive = false,
    removeCancelling = false,
    placeActive = false,
    placeCancelling = false
}

local RemoveTrashFilter = {
    operator = nil,
    value = nil
}

-- --- ECLIPSE SCANNER & AUTOMATION BEHAVIORS ---
local function performEclipseScan()
    local plantsFolder = myPlot and myPlot:FindFirstChild("Plants")
    if not plantsFolder then return end

    local currentPlants = {}
    local tempStats = { Total = 0, Waiting = 0, Growing = 0, Ready = 0, OldestAge = -1, YoungestAge = 9999999 }
    local oldestReady, youngestPlant = nil, nil

    for _, plant in ipairs(plantsFolder:GetChildren()) do
        if plant:GetAttribute("SeedName") == "Eclipse Bloom" then
            local pId = plant:GetAttribute("PlantId") or plant.Name
            currentPlants[pId] = true

            local fruitsFolder = plant:FindFirstChild("Fruits")
            local fruit = fruitsFolder and fruitsFolder:GetChildren()[1]

            local fId, age, maxAge, growthPct, status, ready
            if not fruit then
                age = 0; maxAge = 1; growthPct = 0; status = "Waiting"; ready = false
                tempStats.Waiting += 1
            else
                fId = fruit:GetAttribute("FruitId")
                age = fruit:GetAttribute("Age") or 0
                maxAge = fruit:GetAttribute("MaxAge") or 1
                if maxAge == 0 then maxAge = 1 end
                growthPct = math.floor((age / maxAge) * 100)

                if age >= maxAge then
                    status = "Ready"; ready = true
                    tempStats.Ready += 1
                    if age > tempStats.OldestAge then
                        tempStats.OldestAge = age
                        oldestReady = pId
                    end
                elseif growthPct >= 50 then
                    status = "Growing"; ready = false
                    tempStats.Growing += 1
                else
                    status = "Growing"; ready = false
                    tempStats.Growing += 1
                end

                if age < tempStats.YoungestAge then
                    tempStats.YoungestAge = age
                    youngestPlant = pId
                end
            end

            tempStats.Total += 1
            dashboardCache.EclipseBlooms[pId] = {
                PlantId = pId, FruitId = fId, Age = age, MaxAge = maxAge,
                GrowthPercent = growthPct, Status = status, Ready = ready,
                LastUpdated = os.time(), LastScan = os.time()
            }
        end
    end

    for pId in pairs(dashboardCache.EclipseBlooms) do
        if not currentPlants[pId] then
            dashboardCache.EclipseBlooms[pId] = nil
        end
    end

    GlobalEclipseState.Total = tempStats.Total
    GlobalEclipseState.Waiting = tempStats.Waiting
    GlobalEclipseState.Growing = tempStats.Growing
    GlobalEclipseState.Ready = tempStats.Ready
    GlobalEclipseState.OldestReady = oldestReady
    GlobalEclipseState.Youngest = youngestPlant
    GlobalEclipseState.LastScan = os.time()
    GlobalEclipseState.LastUpdate = os.time()

    saveDashboardCache(dashboardCache)
    triggerDashboardUpdate = true
end

eclipseScanBtn.MouseButton1Click:Connect(performEclipseScan)

autoEclipseBtn.MouseButton1Click:Connect(function()
    isAutoEclipseActive = not isAutoEclipseActive
    autoEclipseBtn.BackgroundColor3 = isAutoEclipseActive and Color3.fromRGB(50, 150, 50) or Color3.fromRGB(170, 50, 50)

    if isAutoEclipseActive then
        eclipseAutomationStartTime = os.time()
        eclipseEventsTriggered = 0
        performEclipseScan()
    end
end)

-- --- BUTTON BEHAVIORS ---
autoMaintenanceBtn.MouseButton1Click:Connect(function()
    isAutoMaintenance = not isAutoMaintenance
    autoMaintenanceBtn.BackgroundColor3 = isAutoMaintenance and Color3.fromRGB(50, 150, 50) or Color3.fromRGB(170, 50, 50)
    CheckAndRunMaintenance()
end)

autoSellBtn.MouseButton1Click:Connect(function()
    isAutoSelling = not isAutoSelling
    autoSellBtn.BackgroundColor3 = isAutoSelling and Color3.fromRGB(50, 150, 50) or Color3.fromRGB(170, 50, 50)
end)

lockBtn.MouseButton1Click:Connect(function()
    lockBtn.Text = "..."
    task.spawn(function()
        local bp = player:FindFirstChildOfClass("Backpack")
        local char = player.Character
        local queue = {}
        for _, container in ipairs({bp, char}) do
            if container then
                for _, item in ipairs(container:GetChildren()) do
                    if item:GetAttribute("HarvestedFruit") then
                        local id = item:GetAttribute("Id")
                        if id and item:GetAttribute("IsFavorite") ~= true then
                            table.insert(queue, id)
                        end
                    end
                end
            end
        end
        
        local BATCH = 10
        local i = 1
        while i <= #queue do
            local bEnd = math.min(i + BATCH - 1, #queue)
            for j = i, bEnd do
                pcall(function() Networking.Backpack.SetFruitFavorite:Fire(queue[j], true) end)
            end
            task.wait(0.02)
            i = bEnd + 1
        end
        lockBtn.Text = "🔒"
    end)
end)

unlockBtn.MouseButton1Click:Connect(function()
    unlockBtn.Text = "..."
    task.spawn(function()
        local bp = player:FindFirstChildOfClass("Backpack")
        local char = player.Character
        local queue = {}
        for _, container in ipairs({bp, char}) do
            if container then
                for _, item in ipairs(container:GetChildren()) do
                    if item:GetAttribute("HarvestedFruit") then
                        local id = item:GetAttribute("Id")
                        if id and item:GetAttribute("IsFavorite") == true then
                            table.insert(queue, id)
                        end
                    end
                end
            end
        end
        
        local BATCH = 10
        local i = 1
        while i <= #queue do
            local bEnd = math.min(i + BATCH - 1, #queue)
            for j = i, bEnd do
                pcall(function() Networking.Backpack.SetFruitFavorite:Fire(queue[j], false) end)
            end
            task.wait(0.02)
            i = bEnd + 1
        end
        unlockBtn.Text = "🔓"
    end)
end)

removeTrashBtn.MouseButton1Click:Connect(function()
    if trashState.removeCancelling then return end 
    
    if trashState.removeActive then
        trashState.removeCancelling = true
        removeTrashBtn.BackgroundColor3 = Color3.fromRGB(150, 120, 40)
        return
    end
    
    local rawText = weightFilterInput.Text
    local filterText = rawText:match("^%s*(.-)%s*$")
    local removeAll = false
    
    if filterText == "" then
        removeAll = true
    else
        local successParse, op, val = ParseWeightCondition(filterText)
        if not successParse then
            warn("Invalid weight filter. Aborting Remove Trash.")
            weightFilterInput.Text = "Invalid Filter!"
            task.delay(1.5, function()
                if weightFilterInput.Text == "Invalid Filter!" then
                    weightFilterInput.Text = rawText
                end
            end)
            return
        end
        RemoveTrashFilter.operator = op
        RemoveTrashFilter.value = val
    end
    
    trashState.removeActive = true
    trashState.removeCancelling = false
    removeTrashBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)

    task.spawn(function()
        local success, err = pcall(function()
            local plantsFolder = myPlot:FindFirstChild("Plants")
            if not plantsFolder then return end
            
            local allPlants = plantsFolder:GetChildren()
            
            for _, plant in ipairs(allPlants) do
                if trashState.removeCancelling then break end
                
                local pId = plant:GetAttribute("PlantId") or plant.Name
                if pId then
                    local hasMatchingFruit = false
                    local plantName = plant:GetAttribute("PlantName")
                    
                    if removeAll then
                        if IsFruitAllowed(plantName) then
                            hasMatchingFruit = true
                        end
                    else
                        local fruitsFolder = plant:FindFirstChild("Fruits")
                        local fruits = fruitsFolder and fruitsFolder:GetChildren() or {}
                        
                        if #fruits > 0 then
                            for _, fruit in ipairs(fruits) do
                                local fruitName = fruit:GetAttribute("CorePartName")
                                
                                if IsFruitAllowed(fruitName) then
                                    local ok, weight = pcall(function()
                                        return tonumber(FruitVisualizerController:CalculateFruitWeight(fruit) or (FruitVisualizerController.CalculatePlantWeight and FruitVisualizerController:CalculatePlantWeight(fruit)) or 0)
                                    end)
                                    if not ok then weight = 0 end
                                    
                                    if MatchesWeightCondition(weight, RemoveTrashFilter.operator, RemoveTrashFilter.value) then
                                        hasMatchingFruit = true
                                        break
                                    end
                                end
                            end
                        else
                            if IsFruitAllowed(plantName) then
                                if MatchesWeightCondition(0, RemoveTrashFilter.operator, RemoveTrashFilter.value) then
                                    hasMatchingFruit = true
                                end
                            end
                        end
                    end
                    
                    if hasMatchingFruit then
                        local successRemove = false
                        
                        while not successRemove and plant.Parent do
                            if trashState.removeCancelling then break end
                            
                            Networking.PotPlacement.PickUpPottedPlant:Fire(pId)
                            task.wait(USER_CONFIG.TrashRemoveDelay)
                            
                            if not plant.Parent then
                                successRemove = true
                            end
                        end
                    end
                end
            end
        end)
        
        if not success then warn("Remove Trash Operation Failed:", err) end
        
        trashState.removeActive = false
        trashState.removeCancelling = false
        removeTrashBtn.BackgroundColor3 = Color3.fromRGB(170, 100, 50)
    end)
end)

placeTrashBtn.MouseButton1Click:Connect(function()
    if trashState.placeCancelling then return end 
    
    if trashState.placeActive then
        trashState.placeCancelling = true
        placeTrashBtn.BackgroundColor3 = Color3.fromRGB(150, 120, 40)
        return
    end
    
    local rawText = weightFilterInput.Text
    local filterText = rawText:match("^%s*(.-)%s*$")
    local placeAll = false
    
    if filterText == "" then
        placeAll = true
    else
        local successParse, op, val = ParseWeightCondition(filterText)
        if not successParse then
            warn("Invalid weight filter. Aborting.")
            weightFilterInput.Text = "Invalid Filter!"
            task.delay(1.5, function()
                if weightFilterInput.Text == "Invalid Filter!" then
                    weightFilterInput.Text = rawText
                end
            end)
            return
        end
        RemoveTrashFilter.operator = op
        RemoveTrashFilter.value = val
    end
    
    trashState.placeActive = true
    trashState.placeCancelling = false
    placeTrashBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)

    task.spawn(function()
        local success, err = pcall(function()
            local col2 = workspace:FindFirstChild("Gardens") 
                and workspace.Gardens:FindFirstChild("Plot1") 
                and workspace.Gardens.Plot1:FindFirstChild("Visual") 
                and workspace.Gardens.Plot1.Visual:FindFirstChild("PlantAreaColumn2")

            if not col2 then
                warn("❌ PlantAreaColumn2 cannot be found. Aborting placement.")
                return
            end

            local groundY = getPlayerGroundHeight()
            local targetPos = Vector3.new(col2.Position.X, groundY, col2.Position.Z)

            local keepPlacing = true
            while keepPlacing do
                if trashState.placeCancelling then break end
                
                local tool = nil
                
                for _, t in ipairs(player.Backpack:GetChildren()) do
                    if t:GetAttribute("PottedPlant") and PlantMatchesWhitelistAndWeightFilter(t, RemoveTrashFilter.operator, RemoveTrashFilter.value, placeAll) then tool = t; break end
                end
                
                if not tool and player.Character then
                    for _, t in ipairs(player.Character:GetChildren()) do
                        if t:GetAttribute("PottedPlant") and PlantMatchesWhitelistAndWeightFilter(t, RemoveTrashFilter.operator, RemoveTrashFilter.value, placeAll) then tool = t; break end
                    end
                end

                if not tool then
                    keepPlacing = false
                    break
                end
                
                local toolId = tool:GetAttribute("Id")
                if not toolId then
                    task.wait(0.5)
                    continue
                end
                
                local successPlace = false
                while not successPlace and tool.Parent do
                    if trashState.placeCancelling then break end
                    
                    Networking.PotPlacement.PlacePottedPlant:Fire(targetPos, 0, toolId)
                    task.wait(USER_CONFIG.TrashPlaceDelay)
                    
                    if tool.Parent ~= player.Backpack and tool.Parent ~= player.Character then
                        successPlace = true
                    end
                end
            end
        end)
        
        if not success then warn("Place Trash Operation Failed:", err) end
        
        trashState.placeActive = false
        trashState.placeCancelling = false
        placeTrashBtn.BackgroundColor3 = Color3.fromRGB(50, 100, 170)
    end)
end)

task.spawn(function()
    while isScriptRunning do
        stateLbl.Text = "Status: " .. getCurrentFarmState()
        trashLbl.Text = "Trash Queue: " .. sharedActionQueue:count()
        keptLbl.Text = string.format("Kept: %d / %d", keptCount, targetKeptLimit)
        task.wait(0.3) 
    end
end)

local function SetAutoFarm(state)
    isAutoFarming = state
    autoToggleBtn.BackgroundColor3 = isAutoFarming and Color3.fromRGB(50, 150, 50) or Color3.fromRGB(170, 50, 50)
    if isAutoFarming then
        notifiedLimitReached = false
    end
end

autoToggleBtn.MouseButton1Click:Connect(function()
    SetAutoFarm(not isAutoFarming)
    CheckAndRunMaintenance()
end)

optimizeBtn.MouseButton1Click:Connect(runGlobalOptimizationSweep)
runGlobalOptimizationSweep()

local expandedSize = frame.Size;
local minimized = false
minimize.MouseButton1Click:Connect(function()
    minimized = not minimized; content.Visible = not minimized
    frame.Size = minimized and UDim2.fromOffset(expandedSize.X.Offset, 25) or expandedSize
    minimize.Text = minimized and "+" or "-"
end)

close.MouseButton1Click:Connect(function()
    isAutoFarming = false; isScriptRunning = false 
    plantAddedConn:Disconnect(); plantRemovedConn:Disconnect()
    for plant in pairs(plantConnections) do cleanupPlant(plant) end
    screenGui:Destroy()
end)

-- ============================================================================
-- CONSUMER THREADS (COMPETING CONSUMER ARCHITECTURE)
-- ============================================================================

-- Worker 1: Harvest Engine
task.spawn(function()
    while isScriptRunning do
        if (isAutoFarming or (isEventActive and USER_CONFIG.EnableEventAutoCleanup)) and not isMaintaining then
            local data = sharedActionQueue:pop() 
            if data then
                local instance = resolveFruitInstance(data.PlantId, data.FruitId)
                if instance and instance.Parent and not pendingVerification[data.FruitId] then
                    local fruitName = instance:GetAttribute("CorePartName")
                    if not IsFruitAllowed(fruitName) then
                        -- Discard unlisted
                    else
                        pendingVerification[data.FruitId] = true
                        
                        TweenService:Create(harvestIndicator, TweenInfo.new(0.1, Enum.EasingStyle.Linear), {BackgroundColor3 = Color3.fromRGB(50, 150, 50)}):Play()
                        
                        pcall(function() Networking.Garden.CollectFruit:Fire(data.PlantId, data.FruitId or "") end)
                        
                        task.spawn(function()
                            pcall(function() task.wait(USER_CONFIG.VerificationDelay) end)
                            pendingVerification[data.FruitId] = nil
                            if isScriptRunning then
                                if resolveFruitInstance(data.PlantId, data.FruitId) then 
                                    sharedActionQueue:push(data) 
                                else 
                                    totalHarvested += 1 
                                end
                            end
                        end)
                        task.wait(USER_CONFIG.HarvestInterval)
                        TweenService:Create(harvestIndicator, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {BackgroundColor3 = Color3.fromRGB(100, 100, 100)}):Play()
                    end
                end
            else
                task.wait(0.1)
            end
        else task.wait(0.1) end
    end
end)

-- Worker 2: Shovel Engine
task.spawn(function()
    while isScriptRunning do
        if (isAutoFarming or (isEventActive and USER_CONFIG.EnableEventAutoCleanup)) and not isMaintaining then
            local data = sharedActionQueue:pop() 
            if data then
                local instance = resolveFruitInstance(data.PlantId, data.FruitId)
                if instance and instance.Parent and not pendingVerification[data.FruitId] then
                    local fruitName = instance:GetAttribute("CorePartName")
                    if not IsFruitAllowed(fruitName) then
                        -- Discard unlisted
                    else
                        pendingVerification[data.FruitId] = true
                        local tool = getShovelTool()
                        if tool then
                            TweenService:Create(shovelIndicator, TweenInfo.new(0.1, Enum.EasingStyle.Linear), {BackgroundColor3 = Color3.fromRGB(50, 150, 50)}):Play()
                            
                            pcall(function() Networking.Shovel.UseShovel:Fire(data.PlantId, data.FruitId, tool:GetAttribute("Shovel"), tool) end)
                            
                            task.spawn(function()
                                pcall(function() task.wait(USER_CONFIG.VerificationDelay) end)
                                pendingVerification[data.FruitId] = nil
                                if isScriptRunning then
                                    if resolveFruitInstance(data.PlantId, data.FruitId) then 
                                        sharedActionQueue:push(data) 
                                    else 
                                        totalShoveled += 1 
                                    end
                                end
                            end)
                            task.wait(USER_CONFIG.ShovelInterval)
                            TweenService:Create(shovelIndicator, TweenInfo.new(0.15, Enum.EasingStyle.Linear), {BackgroundColor3 = Color3.fromRGB(100, 100, 100)}):Play()
                        else
                            pendingVerification[data.FruitId] = nil
                            sharedActionQueue:push(data)
                            task.wait(0.5) 
                        end
                    end
                end
            else
                task.wait(0.1)
            end
        else task.wait(0.1) end
    end
end)

-- Worker 3: Webhook Dashboard Engine
task.spawn(function()
    while isScriptRunning do
        if webhookQueue:count() > 0 then
            local batchedFruits = {}
            while webhookQueue:count() > 0 do table.insert(batchedFruits, webhookQueue:pop()) end
            if #batchedFruits > 0 then
                for _, f in ipairs(batchedFruits) do 
                    table.insert(dashboardTextBuffer, 1, string.format("• %s (%.2fkg) [%s]", f.Name, f.Weight, f.Mutation)) 
                end
                while #dashboardTextBuffer > 20 do table.remove(dashboardTextBuffer, #dashboardTextBuffer) end
            end
            triggerDashboardUpdate = true
        end
        
        if triggerDashboardUpdate then
            updateAnalyticsDashboard(table.concat(dashboardTextBuffer, "\n"))
            triggerDashboardUpdate = false
        end
        task.wait(USER_CONFIG.DashboardUpdateInterval)
    end
end)

-- Worker 4: Main Coordinator & Kept Limit Tracking
task.spawn(function()
    local wasProcessing = false
    while isScriptRunning do
        if keptCount >= targetKeptLimit and isAutoFarming then
            SetAutoFarm(false)
            if not notifiedLimitReached then
                notifiedLimitReached = true
                local msg = string.format("Account: %s\nKept Fruits: %d/%d\n\nThe automation has stopped because the configured kept fruit limit has been reached.", player.Name, keptCount, targetKeptLimit)
                sendWebhook(USER_CONFIG.DashboardWebhook, "🛑 Kept Fruit Limit Reached", msg, 0xE74C3C, "<@" .. USER_CONFIG.MyUserId .. "> Kept fruit limit reached.")
            end
        end

        if isEventActive and USER_CONFIG.EnableEventAutoCleanup then task.wait(1)
        elseif isAutoFarming then
            local totalTasks = sharedActionQueue:count() + fruitProcessingQueue:count()
            if totalTasks > 0 then
                if not wasProcessing then cycleStartTime = os.time() end
                wasProcessing = true
            elseif wasProcessing and totalTasks == 0 then
                wasProcessing = false
                totalCycles += 1
                table.insert(cycleHistory, os.time() - cycleStartTime)
                if #cycleHistory > 100 then table.remove(cycleHistory, 1) end
                
                CheckAndRunMaintenance()
            end
        end
        task.wait(0.5)
    end
end)

-- Worker 5: Fruit Processing
task.spawn(function()
    while isScriptRunning do
        if fruitProcessingQueue:count() > 0 then
            local processed = 0
            while fruitProcessingQueue:count() > 0 and processed < 75 do
                local data = fruitProcessingQueue:pop()
                if data then 
                    local success = processFruit(data.PlantId, data.FruitId, data.isBaseline) 
                    
                    if not success then
                        task.delay(0.5, function()
                            if isScriptRunning then fruitProcessingQueue:push(data) end
                        end)
                    end
                end
                processed += 1
            end
            task.wait(fruitProcessingQueue:count() > 0 and 0 or 0.1)
        else task.wait(0.1) end
    end
end)

-- Worker 6: Auto-Sell Engine
task.spawn(function()
    while isScriptRunning do
        if isAutoSelling then
            pcall(function() 
                if Networking.NPCS and Networking.NPCS.SellAllFruits then
                    Networking.NPCS.SellAllFruits:Fire()
                elseif Networking.NPCS and Networking.NPCS.SellAll then
                    Networking.NPCS.SellAll:Fire()
                end
            end)
        end
        task.wait(1)
    end
end)

-- Worker 7: Auto Eclipse Automation Engine
task.spawn(function()
    while isScriptRunning do
        if isAutoEclipseActive then
            local eclipseActive = false
            for wName, isActive in pairs(activeWeathers) do
                if isActive and string.find(string.lower(wName), "eclipse") then
                    eclipseActive = true
                    break
                end
            end

            if not eclipseActive then
                local oldestReadyId = nil
                local oldestAge = -1

                for pId, data in pairs(dashboardCache.EclipseBlooms) do
                    if data.Ready and data.FruitId then
                        if data.Age > oldestAge then
                            oldestAge = data.Age
                            oldestReadyId = pId
                        end
                    end
                end

                if oldestReadyId then
                    local data = dashboardCache.EclipseBlooms[oldestReadyId]
                    
                    pcall(function() Networking.Garden.CollectFruit:Fire(data.PlantId, data.FruitId) end)
                    eclipseEventsTriggered += 1

                    data.Ready = false
                    data.Age = 0
                    data.Status = "Waiting"
                    data.FruitId = nil
                    GlobalEclipseState.Ready -= 1
                    GlobalEclipseState.Waiting += 1
                    GlobalEclipseState.LastUpdate = os.time()
                    
                    triggerDashboardUpdate = true
                    saveDashboardCache(dashboardCache)

                    task.wait(5)
                else
                    isAutoEclipseActive = false
                    autoEclipseBtn.BackgroundColor3 = Color3.fromRGB(170, 50, 50)

                    local duration = os.time() - eclipseAutomationStartTime
                    local mins = math.floor(duration / 60)
                    local secs = duration % 60
                    local durationStr = string.format("%dm %ds", mins, secs)

                    local embedDesc = string.format(
                        "**Ready Remaining**\n0\n\n" ..
                        "**Growing**\n%d\n\n" ..
                        "**Waiting**\n%d\n\n" ..
                        "**Total Plants**\n%d\n\n" ..
                        "**Automation Duration**\n%s\n\n" ..
                        "**Weather Events Triggered**\n%d\n\n" ..
                        "**Last Updated**\n%s",
                        GlobalEclipseState.Growing,
                        GlobalEclipseState.Waiting,
                        GlobalEclipseState.Total,
                        durationStr,
                        eclipseEventsTriggered,
                        os.date("%H:%M:%S")
                    )

                    sendWebhook(USER_CONFIG.DashboardWebhook, "🌘 Eclipse Bloom Automation Finished", embedDesc, 0x9B59B6, "<@" .. USER_CONFIG.MyUserId .. ">")
                end
            end
        end
        task.wait(2) 
    end
end)


-- Memory Diagnostics Worker
task.spawn(function()
    while isScriptRunning do
        task.wait(60)
        if USER_CONFIG.DebugMode then
            print("\n=== [MoonFinder] Diagnostics ===")
            print("Lua Heap:", math.floor(collectgarbage("count")), "KB")
            print(string.format("Process Queue: %d (Idx: %d-%d)", fruitProcessingQueue:count(), fruitProcessingQueue.first, fruitProcessingQueue.last))
            print(string.format("Shared Queue: %d (Idx: %d-%d)", sharedActionQueue:count(), sharedActionQueue.first, sharedActionQueue.last))
            print("Kept Fruits Count:", keptCount)
            local pCount = 0 for _ in pairs(pendingVerification) do pCount += 1 end
            print("Stuck Verifications:", pCount)
            print("=================================\n")
        end
    end
end)

-- ============================================================================
-- FRUIT MODULE (GROWTH ENGINE)
-- ============================================================================
game:GetService("MaterialService")
local v81 = {
 ["GrowData"] = {
  ["GrowTickTime"] = nil,
  ["GrowRate"] = 0.0047,
  ["BaseWeight"] = 9,
  ["GrowTickTime"] = NumberRange.new(4.8, 6)
 },
 ["InitFruit"] = function(p1, p2, p3) 
  game:GetService("MaterialService")
  local v4 = p3 or 1
  local v5 = Random.new(p2)
  local _ = p1.Base
  local v6, v7 = Color3.fromRGB(51, 136, 5)
  local v8, v9, v10 = v6:ToHSV()
  local v11 = v7 or 0.05
  local v12 = v8 + v5:NextNumber(-v11, v11)
  local v13 = math.clamp(v12, 0, 0.99)
  Color3.fromHSV(v13, v9, v10)
  local v14 = p1.Moon
  local v15 = p1.Leaves
  local v16 = p1.Anthers
  local v17 = Color3.fromRGB(255, 255, 255)
  if v5:NextInteger(1, 3) == 1 then
   v17 = v5:NextInteger(1, 2) == 1 and Color3.fromRGB(35, 55, 163) or Color3.fromRGB(34, 180, 248)
  end
  for _, v18 in v14:GetChildren() do
   v18.Color = v17
   v18.Parent = p1
  end
  v14:Destroy()
  for _, v19 in v15:GetChildren() do
   if v19:IsA("Model") then
    local v20 = v19:GetPivot()
    local v21 = CFrame.Angles
    local v22 = v5:NextNumber(-10, 10)
    local v23 = math.rad(v22)
    local v24 = v5:NextNumber(-10, 10)
    v19:PivotTo(v20 * v21(v23, 0, (math.rad(v24))))
    for _, v25 in v19:GetChildren() do
     v25.Parent = p1
    end
    v19:Destroy()
   else
    local v26 = v19:GetPivot()
    local v27 = CFrame.Angles
    local v28 = v5:NextNumber(-6, 6)
    local v29 = math.rad(v28)
    local v30 = v5:NextNumber(-20, 20)
    v19:PivotTo(v26 * v27(v29, 0, (math.rad(v30))))
    v19.Parent = p1
   end
  end
  for _, v31 in v16:GetChildren() do
   local v32 = v31:GetPivot()
   local v33 = CFrame.Angles
   local v34 = v5:NextNumber(-10, 10)
   local v35 = math.rad(v34)
   local v36 = v5:NextNumber(-15, 25)
   v31:PivotTo(v32 * v33(v35, 0, (math.rad(v36))))
   for _, v37 in v31:GetChildren() do
    v37.Parent = p1
   end
  end
  local v38 = v5:NextInteger(2, 4)
  local v39 = p1["1"]
  for v40 = 1, v38 do
   local v41 = script.Leaf:Clone()
   v41.Parent = p1
   local v42 = 45 + 360 / v38 * (v40 * v5:NextNumber(0.9, 1, 1))
   local v43 = v39.CFrame * CFrame.new(0, v39.Size.Y / 2.5, 0)
   local v44 = CFrame.Angles
   local v45 = math.rad(v42)
   local v46 = v5:NextNumber(97.5, 110)
   v41:PivotTo(v43 * v44(0, v45, (math.rad(v46))))
   v41.Name = 2
  end
  v16:Destroy()
  local v47 = v5:NextNumber(-0.1, 0.1)
  for _, v48 in p1:GetChildren() do
   local v49 = v48.Name
   if tonumber(v49) and v48.Color ~= Color3.fromRGB(255, 255, 255) then
    local v50, v51, v52 = v48.Color:ToHSV()
    v48.Color = Color3.fromHSV(v50 + v47, v51, v52)
   end
  end
  local v53 = v4 * 0.25 + 0.75
  p1:ScaleTo(v53 + v53 ^ 3 * 1e-6)
  p1:AddTag("InitializationComplete")
 end,
 ["BeginFruitGrowth"] = function(p_u_54) 
  local v_u_55 = p_u_54.PrimaryPart
  local v_u_56 = {}
  for _, v57 in p_u_54:QueryDescendants("BasePart") do
   local v58 = v57.Name
   local v59 = tonumber(v58)
   if v59 then
    local v60 = not v57:GetAttribute("DontShow")
    local v61 = {}
    for _, v62 in v57:GetChildren() do
     if v62:IsA("Decal") or v62:IsA("Texture") then
      local v63 = {
       ["decal"] = v62,
       ["originalTransparency"] = v62.Transparency
      }
      table.insert(v61, v63)
      if v60 then
       v62.Transparency = 1
      end
     end
    end
    local v64 = {
     ["part"] = v57,
     ["maxSize"] = v57.Size,
     ["centerOffset"] = v_u_55.CFrame:ToObjectSpace(v57.CFrame),
     ["partAge"] = v59,
     ["decals"] = v61
    }
    table.insert(v_u_56, v64)
    v57.CanCollide = false
    if v60 then
     v57.Transparency = 1
    end
   end
  end
  
  local connection
  local isFullyGrown = false

  local function v75() 
   if isFullyGrown then return end
   
   local v65 = p_u_54:GetAttribute("Age") or 0
   local v66 = p_u_54:GetAttribute("MaxAge") or 1
   
   if v65 >= v66 then
    isFullyGrown = true
    
    for _, v68 in v_u_56 do
      if not v68.part:GetAttribute("DontShow") then
      v68.part.Size = v68.maxSize
      v68.part.CFrame = v_u_55.CFrame * v68.centerOffset
      v68.part.Transparency = v68.part:GetAttribute("OG_Transparency") or 0
      v68.part.CanCollide = true
      
      for _, v73 in v68.decals do
       v73.decal.Transparency = v73.originalTransparency
      end
     end
    end
    
    if connection then
     connection:Disconnect()
     connection = nil
    end
   end
  end
  
  connection = p_u_54:GetAttributeChangedSignal("Age"):Connect(v75)
  v75()
 end,
 ["OnFullyGrown"] = function(p76) 
  local v77 = p76:GetAttribute("CorePartName")
  if v77 then
   local v78 = p76:FindFirstChild(v77)
   local v79 = v78 and game.ServerStorage:FindFirstChild("Collect_PROX_Apple")
   if v79 then  
    local v80 = v79:Clone()
    v80.Name = "ProximityPrompt"
    v80.Parent = v78
   end
  end
  p76:AddTag("PlantGenerated")
 end,
 ["Extras"] = {
  ["FruitType"] = "Corn",
  ["Harvestable"] = true
 }
}
return v81